'use client';
import { useEffect, useState } from 'react';
import { useApp } from './app-provider';
import { Field, Input, Money } from './fields';
import { BalanceSelector } from './balance-selector';
import { Button } from './ui/button';
import { Dialog, DialogContent } from './ui/dialog';
import { rupiah } from '@/lib/accounting';
import { balanceLabel } from '@/lib/wallet-balances';
import { todayInTimeZone } from '@/lib/period';
import { reconcileWallet, repairWalletCache, walletBalancePreview } from '@/lib/finance-store';
import type { BalanceKind } from '@/lib/types';

type Preview = Awaited<ReturnType<typeof walletBalancePreview>>;
export function WalletControls({ walletId, mode, onClose, onDone }: { walletId: string | null; mode: 'reconcile' | 'recalculate'; onClose: () => void; onDone: (message: string) => void }) {
 const { user, profile } = useApp();
 const [preview, setPreview] = useState<Preview | null>(null), [actual, setActual] = useState(0), [notes, setNotes] = useState(''), [confirm, setConfirm] = useState(false), [busy, setBusy] = useState(false), [error, setError] = useState(''), [balanceKind, setBalanceKind] = useState<BalanceKind>('personal');
 useEffect(() => {
  setPreview(null); setConfirm(false); setError(''); setNotes(''); setBalanceKind('personal');
  if (!walletId || !user) return;
  let active = true;
  walletBalancePreview(user.uid, walletId).then(result => { if (active) { setPreview(result); setActual(result.wallet.balanceSplitEnabled ? result.calculatedPersonal : result.calculated); } }).catch(e => { if (active) setError(e.message); });
  return () => { active = false; };
 }, [walletId, user, mode]);
 const split = Boolean(preview?.wallet.balanceSplitEnabled);
 const calculated = preview ? split ? balanceKind === 'business' ? preview.calculatedBusiness : preview.calculatedPersonal : preview.calculated : 0;
 const cached = preview ? split ? balanceKind === 'business' ? preview.cachedBusiness : preview.cachedPersonal : preview.cached : 0;
 const cacheMismatch = Boolean(preview && (preview.difference !== 0 || split && (preview.businessDifference !== 0 || preview.personalDifference !== 0)));
 const diff = actual - calculated;
 const compartment = split ? ` · saldo ${balanceLabel(balanceKind).toLowerCase()}` : '';
 function chooseBalance(kind: BalanceKind) { setBalanceKind(kind); setActual(preview ? kind === 'business' ? preview.calculatedBusiness : preview.calculatedPersonal : 0); setConfirm(false); }
 async function execute() {
  if (!user || !walletId || !preview) return;
  setBusy(true); setError('');
  try {
   if (mode === 'recalculate') {
    const result = await repairWalletCache(user.uid, walletId, preview.cached);
    onDone(result.warning || 'Saldo tersimpan diperbaiki berdasarkan ledger. Riwayat transaksi tidak diubah.');
   } else {
    const result = await reconcileWallet(user.uid, walletId, cached, actual, notes, todayInTimeZone(profile?.timeZone), balanceKind);
    onDone(result.warning || 'Penyesuaian saldo dicatat sebagai transaksi di riwayat.');
   }
   onClose();
  } catch (e) { setError((e as Error).message || 'Penyesuaian gagal.'); setConfirm(false); }
  finally { setBusy(false); }
 }
 return <Dialog open={Boolean(walletId)} onOpenChange={open => { if (!open) onClose(); }}><DialogContent title={mode === 'reconcile' ? 'Cocokkan saldo' : 'Hitung ulang saldo'}><div className="form-stack">
  {!preview && !error && <p role="status">Menghitung saldo dari seluruh transaksi…</p>}
  {preview && <>
   <div className="panel money-detail"><strong>{preview.wallet.name}</strong><div><span>Saldo total berdasarkan transaksi</span><strong>{rupiah(preview.calculated)}</strong></div><div><span>Saldo total tersimpan</span><strong>{rupiah(preview.cached)}</strong></div><div><span>Selisih total</span><strong>{rupiah(preview.difference)}</strong></div>
    {split && <>{(['personal', 'business'] as BalanceKind[]).map(kind => <div key={kind} className="form-stack"><strong>Saldo {balanceLabel(kind).toLowerCase()}</strong><div><span>Berdasarkan transaksi</span><strong>{rupiah(kind === 'business' ? preview.calculatedBusiness : preview.calculatedPersonal)}</strong></div><div><span>Tersimpan di aplikasi</span><strong>{rupiah(kind === 'business' ? preview.cachedBusiness : preview.cachedPersonal)}</strong></div><div><span>Selisih</span><strong>{rupiah(kind === 'business' ? preview.businessDifference : preview.personalDifference)}</strong></div></div>)}</>}
    <small>{preview.transactions} transaksi terkait · saldo awal total {rupiah(preview.wallet.openingBalance)}{split ? ` · pribadi ${rupiah(preview.wallet.openingBalance - (preview.wallet.openingBusinessBalance || 0))} · bisnis ${rupiah(preview.wallet.openingBusinessBalance || 0)}` : ''}</small>
   </div>
   {mode === 'reconcile' && <>
    <BalanceSelector wallet={preview.wallet} value={balanceKind} onChange={chooseBalance} label="Saldo yang dicocokkan"/>
    <Field label={split ? `Saldo ${balanceLabel(balanceKind).toLowerCase()} aktual` : 'Saldo aktual di bank / e-wallet'}><Money value={actual} onChange={value => { setActual(value); setConfirm(false); }}/></Field>
    <div className="notice">{diff === 0 ? 'Saldo aktual sama dengan saldo berdasarkan transaksi.' : `Saldo aktual ${diff < 0 ? 'lebih rendah' : 'lebih tinggi'} ${rupiah(Math.abs(diff))}. Penyesuaian ${diff < 0 ? 'mengurangi' : 'menambah'} saldo ${preview.wallet.name}${compartment}.`}</div>
    <Field label="Catatan opsional"><Input value={notes} onChange={e => setNotes(e.target.value)} placeholder="Misalnya biaya yang lupa dicatat"/></Field>
   </>}
   {cacheMismatch && mode === 'reconcile' && <div className="notice">Saldo tersimpan dan transaksi belum cocok. Samakan saldo lewat Hitung ulang saldo sebelum mencocokkan saldo aktual.</div>}
   {mode === 'recalculate' && cacheMismatch && <div className="notice">Perbaikan memperbarui saldo total menjadi {rupiah(preview.calculated)}{split ? `, pribadi ${rupiah(preview.calculatedPersonal)} dan bisnis ${rupiah(preview.calculatedBusiness)}` : ''}. Tidak ada transaksi lama yang diubah.</div>}
   {!confirm && (mode === 'recalculate' ? cacheMismatch : diff !== 0 && !cacheMismatch) && <Button onClick={() => setConfirm(true)}>{mode === 'reconcile' ? 'Buat penyesuaian' : 'Samakan saldo'}</Button>}
   {confirm && <div className="panel"><strong>Konfirmasi {mode === 'reconcile' ? 'Penyesuaian' : 'Penyamaan saldo'}</strong><p className="muted">Dompet: {preview.wallet.name}{mode === 'reconcile' ? `${compartment} · saldo terhitung ${rupiah(calculated)} · saldo aktual ${rupiah(actual)} · penyesuaian ${diff < 0 ? '-' : '+'}${rupiah(Math.abs(diff))}` : ` · saldo total ${rupiah(preview.cached)} → ${rupiah(preview.calculated)}${split ? ` · pribadi ${rupiah(preview.cachedPersonal)} → ${rupiah(preview.calculatedPersonal)} · bisnis ${rupiah(preview.cachedBusiness)} → ${rupiah(preview.calculatedBusiness)}` : ''}`}{notes ? ` · ${notes}` : ''}</p><div className="toolbar-row" style={{ marginTop: 14 }}><Button variant="secondary" onClick={() => setConfirm(false)} disabled={busy}>Batal</Button><Button onClick={() => void execute()} disabled={busy}>{busy ? 'Memproses…' : mode === 'reconcile' ? 'Konfirmasi Penyesuaian' : 'Konfirmasi Penyamaan saldo'}</Button></div></div>}
  </>}
  {error && <p role="alert" className="form-error">{error}</p>}
  <Button variant="secondary" onClick={onClose}>Tutup</Button>
 </div></DialogContent></Dialog>;
}
