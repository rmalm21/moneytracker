'use client';
import { useId } from 'react';
import { rupiah } from '@/lib/accounting';
import { balanceLabel, walletBalances } from '@/lib/wallet-balances';
import type { BalanceKind, Wallet } from '@/lib/types';

/** Choose which part of a wallet a transaction uses; ordinary wallets need no extra field. */
export function BalanceSelector({ wallet, value = 'personal', onChange, label = 'Gunakan saldo', showBalance = true, disabled = false }: {
  wallet?: Wallet;
  value?: BalanceKind;
  onChange: (kind: BalanceKind) => void;
  label?: string;
  showBalance?: boolean;
  disabled?: boolean;
}) {
  const groupId = useId();
  if (!wallet?.balanceSplitEnabled) return null;
  const balances = walletBalances(wallet);
  return <div className="field balance-selector">
    <span className="field-caption">{label}</span>
    <div className="balance-options" role="radiogroup" aria-label={label}>
      {(['personal', 'business'] as const).map(kind => <label
        key={kind}
        className={`balance-option ${value === kind ? 'is-selected' : ''} ${disabled ? 'is-disabled' : ''}`}
      >
        <input className="sr-only" type="radio" name={groupId} value={kind} checked={value === kind} disabled={disabled} onChange={() => onChange(kind)}/>
        <span>{balanceLabel(kind)}</span>
        {showBalance && <strong className={balances[kind] < 0 ? 'amount-negative' : undefined}>{rupiah(balances[kind])}</strong>}
      </label>)}
    </div>
  </div>;
}
