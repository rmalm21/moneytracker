'use client';
import { useEffect, useState } from 'react';
import { ArrowDown, ArrowUp, ArrowUpRight, BrainCircuit, CircleCheck, Clock3, Gauge, HandCoins, HeartPulse, Lightbulb, PinOff, RotateCcw, Sparkles, Sprout, UserRound, type LucideIcon } from 'lucide-react';
import { Dialog, DialogContent } from './ui/dialog';
import { Button } from './ui/button';

/** Sections of the Insight page that can be reordered or hidden (the score card always stays on top). */
export const defaultSections: { key: string; label: string; hint: string; icon: LucideIcon }[] = [
  { key: 'brief', label: 'Ringkasan', hint: '2–4 kalimat tentang keadaan keuanganmu', icon: Sparkles },
  { key: 'changed', label: 'Yang berubah', hint: 'Perubahan paling berarti dan penyebabnya', icon: ArrowUpRight },
  { key: 'actions', label: 'Prioritas sekarang', hint: '3 hal terpenting + yang kamu sematkan', icon: Lightbulb },
  { key: 'progress', label: 'Yang membaik', hint: 'Yang membaik dan sudah teratasi', icon: CircleCheck },
  { key: 'pressure', label: 'Arah & yang perlu dijaga', hint: 'Membaik atau memburuk, dan hal yang sedang berat', icon: Gauge },
  { key: 'details', label: 'Rincian', hint: 'Pengeluaran, arus uang, target & aset, skenario, data', icon: BrainCircuit },
  { key: 'health', label: 'Indikator skor', hint: '6 indikator: menabung, dana darurat, cicilan…', icon: HeartPulse },
  { key: 'profile', label: 'Profil Insight', hint: 'Profil risiko, target, prioritas', icon: UserRound },
  { key: 'wealth', label: 'Uang menganggur & investasi', hint: 'Dana menganggur, urutan penyaluran, rencana investasi', icon: Sprout },
  { key: 'paycheck', label: 'Rencana gajian berikutnya', hint: 'Pembagian gaji per pos', icon: HandCoins },
  { key: 'charts', label: 'Grafik siklus & porsi', hint: 'Pola per siklus dan porsi kebutuhan/keinginan', icon: Gauge },
  { key: 'timeline', label: 'Riwayat & keputusan', hint: 'Perubahan penting dan hasil keputusanmu', icon: Clock3 },
];
/**
 * Saved order with sections added in later versions put at their default place (after the section that comes
 * before them by default), so an existing layout keeps its order and new sections do not all land at the bottom.
 */
export function mergeOrder(saved: string[] | undefined) {
  const keys = defaultSections.map(d => d.key);
  const out = (saved || []).filter(k => keys.includes(k));
  if (!out.length) return keys;
  keys.forEach((key, i) => {
    if (out.includes(key)) return;
    const before = keys.slice(0, i).reverse().find(k => out.includes(k));
    out.splice(before ? out.indexOf(before) + 1 : 0, 0, key);
  });
  return out;
}

/** Sheet to reorder and show/hide Insight sections. */
export function InsightLayoutSheet({ open, onOpenChange, order, hidden, pinnedCount, onSave, onClearPins }: { open: boolean; onOpenChange: (open: boolean) => void; order: string[]; hidden: string[]; pinnedCount: number; onSave: (order: string[], hidden: string[]) => void; onClearPins: () => void }) {
  const [list, setList] = useState(order), [off, setOff] = useState(hidden);
  useEffect(() => { if (open) { setList(order); setOff(hidden); } }, [open]); // eslint-disable-line react-hooks/exhaustive-deps
  const move = (index: number, by: number) => setList(current => { const next = [...current]; const [item] = next.splice(index, 1); next.splice(Math.max(0, Math.min(next.length, index + by)), 0, item); return next; });
  const toggle = (key: string) => setOff(current => current.includes(key) ? current.filter(k => k !== key) : [...current, key]);
  return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent title="Atur tampilan Insight" className="insight-layout-dialog">
    <p className="ip-intro">Urutkan bagian dengan panah, dan matikan yang tidak perlu. Kartu saran bisa disematkan ke atas lewat ikon pin di tiap kartu.</p>
    <ol className="il-list">{list.map((key, index) => { const section = defaultSections.find(d => d.key === key)!; const shown = !off.includes(key); return <li key={key} className={shown ? '' : 'is-off'}>
      <span className="il-icon" aria-hidden="true"><section.icon size={17}/></span>
      <span className="il-text"><strong>{section.label}</strong><small>{section.hint}</small></span>
      <span className="il-moves"><button type="button" className="icon-btn" disabled={index === 0} aria-label={`Naikkan ${section.label}`} onClick={() => move(index, -1)}><ArrowUp size={16}/></button><button type="button" className="icon-btn" disabled={index === list.length - 1} aria-label={`Turunkan ${section.label}`} onClick={() => move(index, 1)}><ArrowDown size={16}/></button></span>
      <button type="button" role="switch" aria-checked={shown} aria-label={`Tampilkan ${section.label}`} className={`il-switch ${shown ? 'on' : ''}`} onClick={() => toggle(key)}><i/></button>
    </li>; })}</ol>
    <div className="il-extra">
      <button type="button" className="link-button" onClick={() => { setList(defaultSections.map(d => d.key)); setOff([]); }}><RotateCcw size={14}/> Kembalikan bawaan</button>
      {pinnedCount > 0 && <button type="button" className="link-button" onClick={onClearPins}><PinOff size={14}/> Lepas {pinnedCount} sematan</button>}
    </div>
    <div className="modal-actions"><Button variant="secondary" type="button" onClick={() => onOpenChange(false)}>Batal</Button><Button type="button" onClick={() => onSave(list, off)}>Simpan tampilan</Button></div>
  </DialogContent></Dialog>;
}
