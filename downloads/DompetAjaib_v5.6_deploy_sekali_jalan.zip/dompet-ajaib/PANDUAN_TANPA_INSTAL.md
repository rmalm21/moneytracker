# Deploy sekali jalan tanpa instal di laptop

Upload ZIP **DompetAjaib_v5.6_deploy_sekali_jalan.zip** ke Cloud Shell project **money-manage-32467**, lalu paste satu blok pada [DEPLOY_CLOUD_SHELL.md](DEPLOY_CLOUD_SHELL.md).

Konfigurasi Firebase, Node 24, dependensi, pemeriksaan, build, situs, dan aturan Firestore ditangani oleh skrip. Perbaikan aplikasi tetap versi **5.6**.

Capture UI merupakan pengujian terpisah. Skrip `CAPTURE_CLOUD_SHELL.sh` serta petunjuknya tersedia pada [DEPLOY_MANUAL_CLOUD_SHELL.md](DEPLOY_MANUAL_CLOUD_SHELL.md).
