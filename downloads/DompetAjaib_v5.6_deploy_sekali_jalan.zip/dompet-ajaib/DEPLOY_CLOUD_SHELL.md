# Deploy sekali jalan — Dompet Ajaib v5.6

Project pada Cloud Shell harus **money-manage-32467**, seperti pada foto. Skrip memakai akun Google yang sudah aktif di Cloud Shell.

1. Upload **DompetAjaib_v5.6_deploy_sekali_jalan.zip** melalui menu **Upload file** Cloud Shell. Simpan pada direktori home yang ditawarkan menu upload.
2. Salin seluruh blok berikut, paste ke terminal, lalu tekan **Enter** satu kali:

```bash
bash <<'DEPLOY'
set -e
DOMPET_DIR="$(mktemp -d /tmp/dompetajaib-deploy-XXXXXX)"
unzip -q "$HOME/DompetAjaib_v5.6_deploy_sekali_jalan.zip" -d "$DOMPET_DIR"
bash "$DOMPET_DIR/dompet-ajaib/DEPLOY_SEKALI_JALAN.sh"
DEPLOY
```

3. Tunggu proses selesai dan muncul **SELESAI — https://dompetajaib.web.app**. Buka alamat tersebut, muat ulang, lalu periksa versi **5.6** di Pengaturan.

Skrip otomatis menyiapkan Node 24 dan Firebase CLI, mengambil konfigurasi web app project tersebut, mengisi `.env.local`, mematikan emulator, memasang dependensi, menjalankan pemeriksaan, melakukan build, lalu mengunggah **situs dan aturan Firestore**. Login Firebase terpisah dan salin nilai konfigurasi secara manual tidak diperlukan. Jika project belum memiliki web app, skrip mendaftarkan web app Dompet Ajaib untuk memperoleh konfigurasi.

Skrip memakai token akses sementara dari akun Cloud Shell dan memperbaruinya sebelum setiap perintah Firebase. Token tidak ditulis ke file atau ditampilkan di terminal. Jika konfigurasi atau build gagal, proses berhenti sebelum deploy. Pesan error menunjukkan langkah yang gagal; perbaiki penyebabnya lalu jalankan blok yang sama lagi.

Paket memuat split saldo Pribadi/Bisnis, perbaikan edit pembayaran Split Bill, menu Lainnya pada kartu Utang/Piutang, dan ringkasan pelunasan dari catatan aktif. Laporan fitur ada di [PERBAIKAN_UTANG_PIUTANG.md](PERBAIKAN_UTANG_PIUTANG.md).

Pemeriksaan skrip menggunakan simulasi perintah Cloud Shell; deploy langsung ke akun Google lo belum dijalankan selama pengerjaan paket. Bukti pengujian ada di `validation/bukti-deploy-sekali-jalan/`. Panduan manual cadangan ada di [DEPLOY_MANUAL_CLOUD_SHELL.md](DEPLOY_MANUAL_CLOUD_SHELL.md).
