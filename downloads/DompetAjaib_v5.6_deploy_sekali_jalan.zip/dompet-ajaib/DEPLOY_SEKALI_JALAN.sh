#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"

DA_PROJECT='money-manage-32467'
DA_SITE='dompetajaib'
DA_CLI_VERSION='15.32.1'
DA_STEP='memeriksa Cloud Shell'
DA_TEMP=''
trap 'printf "\nDeploy berhenti saat %s. Periksa pesan error di atas lalu jalankan blok yang sama lagi.\n" "$DA_STEP" >&2' ERR
trap 'if [[ -n "$DA_TEMP" ]]; then rm -rf -- "$DA_TEMP"; fi' EXIT

command -v gcloud >/dev/null || { echo 'Jalankan dari Google Cloud Shell pada project money-manage-32467.' >&2; exit 1; }
[[ "$(gcloud config get-value project 2>/dev/null)" == "$DA_PROJECT" ]] || {
  echo 'Cloud Shell harus dibuka pada project money-manage-32467, seperti pada foto.' >&2
  exit 1
}
printf 'DOMPET AJAIB — DEPLOY SEKALI JALAN\nProject: %s\nAlamat: https://%s.web.app\n\n' "$DA_PROJECT" "$DA_SITE"
umask 077
DA_TEMP="$(mktemp -d /tmp/dompetajaib-tools-XXXXXX)"

DA_STEP='menyiapkan Node 24'
if ! command -v node >/dev/null || [[ "$(node -p 'process.versions.node.split(".")[0]')" != '24' ]]; then
  if [[ ! -s "${NVM_DIR:-$HOME/.nvm}/nvm.sh" ]]; then
    curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh -o "$DA_TEMP/install-nvm.sh"
    PROFILE=/dev/null bash "$DA_TEMP/install-nvm.sh"
  fi
  # nvm is a shell function; load it in this script rather than requiring a terminal restart.
  set +u
  . "${NVM_DIR:-$HOME/.nvm}/nvm.sh"
  nvm install 24
  nvm use 24
  set -u
fi

DA_STEP='menyiapkan Firebase CLI'
echo '[1/5] Menyiapkan Firebase CLI...'
npm install --prefix "$DA_TEMP/tools" --no-save --package-lock=false --no-audit --no-fund "firebase-tools@$DA_CLI_VERSION"

# Firebase CLI 15 supports a Cloud Shell access token. Refresh it before every
# command and pass it only in that command's environment, never in a file/argument.
fb() {
  local da_access_token
  da_access_token="$(gcloud auth print-access-token)"
  [[ -n "$da_access_token" ]] || { echo 'Akun Google Cloud Shell belum terautentikasi.' >&2; return 1; }
  FIREBASE_TOKEN="$da_access_token" node "$DA_TEMP/tools/node_modules/firebase-tools/lib/bin/firebase.js" \
    "$@" --project "$DA_PROJECT" --non-interactive
}

DA_STEP='mengambil konfigurasi Firebase'
echo '[2/5] Mengambil konfigurasi Firebase otomatis...'
fb apps:list WEB --json > "$DA_TEMP/apps.json"
if [[ "$(node scripts/cloud-shell-config.mjs app-count "$DA_TEMP/apps.json")" == '0' ]]; then
  fb apps:create WEB 'Dompet Ajaib' --json > "$DA_TEMP/new-app.json"
  fb apps:list WEB --json > "$DA_TEMP/apps.json"
fi
DA_APP_ID="$(node scripts/cloud-shell-config.mjs select-app "$DA_TEMP/apps.json" "$DA_PROJECT" "$DA_SITE")"
fb apps:sdkconfig WEB "$DA_APP_ID" --json > "$DA_TEMP/sdk.json"
node scripts/cloud-shell-config.mjs write-env "$DA_TEMP/sdk.json" "$DA_PROJECT" .env.local

DA_STEP='memasang dependensi aplikasi'
echo '[3/5] Memasang kebutuhan aplikasi...'
npm ci --no-audit --no-fund

DA_STEP='memeriksa dan membangun aplikasi'
echo '[4/5] Menjalankan pemeriksaan dan build...'
# The downloaded production configuration takes precedence over inherited demo settings.
unset NEXT_PUBLIC_FIREBASE_API_KEY NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN NEXT_PUBLIC_FIREBASE_PROJECT_ID
unset NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID NEXT_PUBLIC_FIREBASE_APP_ID
unset NEXT_PUBLIC_FIREBASE_EMULATOR_HOST
npm run typecheck
npm test
npm run build
test -s out/index.html
test -s out/sw.js

DA_STEP='mengunggah aturan Firestore dan situs'
echo '[5/5] Deploy aturan Firestore dan situs...'
# These releases need updated rules and Hosting, and introduce no new indexes.
fb deploy --only firestore:rules,hosting

printf '\nSELESAI — https://%s.web.app\nMuat ulang aplikasi, lalu pastikan Pengaturan menampilkan versi 5.6.\n' "$DA_SITE"
