import { effects } from './accounting.ts';
import type { BalanceKind, LedgerTx, Wallet } from './types';

export type WalletBalanceParts = { personal: number; business: number; total: number };
export type BalanceCacheDelta = { cachedBalance: number; cachedBusinessBalance: number };

/** Old transactions and forms without a selection always use the personal balance. */
export function validateBalanceKind(kind: unknown): BalanceKind {
  if (kind === undefined || kind === 'personal') return 'personal';
  if (kind === 'business') return 'business';
  throw Error('Jenis saldo harus Pribadi atau Bisnis.');
}

export function validateWalletBalanceKind(wallet: Pick<Wallet, 'balanceSplitEnabled'>, kind: unknown): BalanceKind {
  const selected = validateBalanceKind(kind);
  if (selected === 'business' && wallet.balanceSplitEnabled !== true) {
    throw Error('Aktifkan split saldo di dompet ini sebelum memakai saldo Bisnis.');
  }
  return selected;
}

export function balanceLabel(kind?: BalanceKind): string {
  return validateBalanceKind(kind) === 'business' ? 'Bisnis' : 'Pribadi';
}

/** cachedBalance remains the wallet's total; no separate personal cache is stored. */
export function walletBalances(wallet: Pick<Wallet, 'cachedBalance' | 'cachedBusinessBalance'>): WalletBalanceParts {
  const total = wallet.cachedBalance;
  const business = wallet.cachedBusinessBalance ?? 0;
  return { personal: total - business, business, total };
}

/** A ledger rebuild may only replace the cache it read before loading the ledger. */
export function sameWalletBalanceState(before: Wallet, current: Wallet): boolean {
  const stamp = (value: unknown) => JSON.stringify(value ?? null);
  return before.openingBalance === current.openingBalance
    && (before.openingBusinessBalance ?? 0) === (current.openingBusinessBalance ?? 0)
    && before.cachedBalance === current.cachedBalance
    && (before.cachedBusinessBalance ?? 0) === (current.cachedBusinessBalance ?? 0)
    && stamp(before.updatedAt) === stamp(current.updatedAt);
}

/** Validate Rupiah integers, including the derived part; negative balances are allowed. */
export function walletOpeningBalances(wallet: Pick<Wallet, 'openingBalance' | 'openingBusinessBalance'>): WalletBalanceParts {
  const total = wallet.openingBalance;
  const business = wallet.openingBusinessBalance ?? 0;
  const personal = total - business;
  if (![total, business, personal].every(Number.isSafeInteger)) {
    throw Error('Saldo awal Pribadi dan Bisnis harus berupa Rupiah bulat yang valid.');
  }
  return { personal, business, total };
}

/** Every cash effect keeps the existing total calculation and adds its balance allocation. */
export function balanceEffects(tx: LedgerTx): Record<string, WalletBalanceParts> {
  const result: Record<string, WalletBalanceParts> = {};
  for (const [walletId, total] of Object.entries(effects(tx))) {
    result[walletId] = { personal: 0, business: 0, total };
  }
  const add = (walletId: string | null, kind: BalanceKind | undefined, amount: number) => {
    if (!walletId) return;
    const part = result[walletId] ?? (result[walletId] = { personal: 0, business: 0, total: 0 });
    part[validateBalanceKind(kind)] += amount;
  };
  if (tx.type === 'transfer' || tx.type === 'fund_contribution') {
    const fee = tx.type === 'transfer' ? tx.transferFee || 0 : 0;
    add(tx.walletId, tx.balanceKind, -tx.amount - fee);
    add(tx.destinationWalletId, tx.destinationBalanceKind, tx.amount);
  } else {
    for (const [walletId, part] of Object.entries(result)) add(walletId, tx.balanceKind, part.total);
  }
  return result;
}

/** Rebuild both balances from opening amounts and the same ledger used by walletBalance. */
export function walletBalanceParts(wallet: Wallet, txs: LedgerTx[]): WalletBalanceParts {
  const result = walletOpeningBalances(wallet);
  for (const tx of txs) {
    const part = balanceEffects(tx)[wallet.id];
    if (!part) continue;
    result.personal += part.personal;
    result.business += part.business;
    result.total += part.total;
  }
  return result;
}

/** Includes same-wallet moves: a zero total can still change the business balance. */
export function balanceCacheDeltas(tx: LedgerTx, sign = 1): Record<string, BalanceCacheDelta> {
  const result: Record<string, BalanceCacheDelta> = {};
  for (const [walletId, part] of Object.entries(balanceEffects(tx))) {
    const cachedBalance = part.total * sign;
    const cachedBusinessBalance = part.business * sign;
    if (cachedBalance || cachedBusinessBalance) result[walletId] = { cachedBalance, cachedBusinessBalance };
  }
  return result;
}

/** Editing reverses the original transaction, then applies the new one to both caches. */
export function combineBalanceCacheDeltas(next: LedgerTx, previous?: LedgerTx): Record<string, BalanceCacheDelta> {
  const result = balanceCacheDeltas(next);
  if (previous) {
    for (const [walletId, delta] of Object.entries(balanceCacheDeltas(previous, -1))) {
      const current = result[walletId] ?? (result[walletId] = { cachedBalance: 0, cachedBusinessBalance: 0 });
      current.cachedBalance += delta.cachedBalance;
      current.cachedBusinessBalance += delta.cachedBusinessBalance;
    }
  }
  for (const [walletId, delta] of Object.entries(result)) {
    if (!delta.cachedBalance && !delta.cachedBusinessBalance) delete result[walletId];
  }
  return result;
}

/** A transfer can appear in both filters; with a wallet, match its own source/destination part. */
export function transactionMatchesBalance(tx: LedgerTx, kind: BalanceKind, walletId?: string): boolean {
  const selected = validateBalanceKind(kind);
  const sourceMatches = (!walletId || tx.walletId === walletId) && validateBalanceKind(tx.balanceKind) === selected;
  if (sourceMatches) return true;
  return (tx.type === 'transfer' || tx.type === 'fund_contribution')
    && Boolean(tx.destinationWalletId)
    && (!walletId || tx.destinationWalletId === walletId)
    && validateBalanceKind(tx.destinationBalanceKind) === selected;
}
