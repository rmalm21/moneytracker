import { collection, deleteField, doc, waitForPendingWrites, getDoc, getDocFromCache, getDocFromServer, getDocs, getDocsFromCache, getDocsFromServer, increment, limit, onSnapshot, orderBy, query, runTransaction, serverTimestamp, setDoc, startAfter, updateDoc, where, writeBatch, type DocumentData, type DocumentReference, type Query, type QueryDocumentSnapshot, type Unsubscribe } from 'firebase/firestore';
import { isCurrent, syncedCollections, watchSync, whenCurrent, type SyncedName } from './sync';
import { runTx, settle, isOffline, whenOnline } from './offline';
import { deletedTxIds, forgetTxDeleted, markTxDeleted, withoutDeleted } from './tombstones';
import { walletGroup } from './wallet-groups';
import type { User } from 'firebase/auth';
import { db } from './firebase';
import { validAmount, budgetWindow, budgetSpent, calendarCycle, newestFirst } from './accounting';
import type { BalanceKind, BalanceUpdate, WishItem, Budget, Category, Claim, Data, Debt, Fund, LedgerTx, ManualPayment, Profile, Receivable, Recurring, Wallet, Draft, TxType } from './types';
import { validateWalletUse, walletActions } from './wallet-capabilities';
import { advanceSchedule, scheduleDay } from './recurring';
import { balanceCacheDeltas, combineBalanceCacheDeltas, validateBalanceKind, validateWalletBalanceKind, walletBalanceParts, walletOpeningBalances, sameWalletBalanceState } from './wallet-balances';
import { mergeWalletSplitBalances, validateBackupBalances } from './backup-balances';

function cacheIncrements(delta:{cachedBalance:number;cachedBusinessBalance:number}) {
  return {cachedBalance:increment(delta.cachedBalance),cachedBusinessBalance:increment(delta.cachedBusinessBalance),updatedAt:serverTimestamp()};
}
async function checkBalanceWallet(uid:string,id:string,kind:BalanceKind|undefined,action:import('./wallet-capabilities').WalletAction){
  const snap=await readDoc(uid,'wallets',ref(uid,'wallets',id));if(!snap.exists())throw Error('Dompet tidak ditemukan.');
  const wallet=hydrate<Wallet>(snap);validateWalletBalanceKind(wallet,kind);validateWalletUse(wallet,action);
}

export const names = ['wallets','categories','budgets','transactions','claims','receivables','debts','funds','recurring','drafts','plannedTransactions','categorizationRules','financialNotes','cycleSnapshots','wishlist','splitBills','splitPeople','splitGroups'] as const;
/** Kept on the device like the rest, but read by their own pages only when opened (not at start-up). */
export const onDemand = new Set<string>(['splitBills','splitPeople','splitGroups']);
type Name = typeof names[number];
function database() { if (!db) throw Error('Konfigurasi Firebase belum tersedia.'); return db; }
export function userRef(uid:string) { return doc(database(),'users',uid); }
export function coll(uid:string,name:Name) { return collection(database(),'users',uid,name); }
export function ref(uid:string,name:Name,id:string) { return doc(database(),'users',uid,name,id); }
const hydrate = <T>(d:{id:string;data:()=>DocumentData}) => ({ id:d.id, ...d.data() }) as T;
/** Reads from the device copy once it matches the server (lib/sync.ts); asks the server only if that takes too long. */
export async function readLocalFirst(uid:string,collections:SyncedName[],target:Query){if(await whenCurrent(uid,collections)){try{return await getDocsFromCache(target)}catch{/* ask the server */}}return getDocs(target);}
/** Transactions a few days around a date (the duplicate check before saving a receipt): a small, bounded read, from the local cache when it is current. */
export async function transactionsAround(uid:string,date:string,days=2){const shift=(n:number)=>{const d=new Date(`${date}T00:00:00Z`);d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);};const snapshot=await readLocalFirst(uid,['transactions'],query(coll(uid,'transactions'),where('date','>=',shift(-days)),where('date','<=',shift(days)),limit(200)));return snapshot.docs.map(row=>hydrate<LedgerTx>(row));}
/** One document from the device copy when it is current, otherwise from the server. */
async function readDoc(uid:string,name:SyncedName,target:DocumentReference){if(isCurrent(uid,name)){try{const snap=await getDocFromCache(target);if(snap.exists())return snap}catch{/* ask the server */}}return getDoc(target);}
/** A note that these documents were deleted, so the user's other devices drop exactly them from their copy (lib/sync.ts). */
export async function noteDeleted(uid:string,items:Partial<Record<Name,string[]>>){markTxDeleted(items.transactions||[]);await dropFromDevice(uid,items);try{await settle(setDoc(doc(collection(database(),'users',uid,'deletions')),{items,at:serverTimestamp(),updatedAt:serverTimestamp()}))}catch{/* the daily count check still catches it */}}
/**
 * The device copy only follows documents that change, so a document deleted inside a server transaction would stay in
 * it (and come back on screen). Asking the server for it once (one read each) removes it from the copy, and every
 * screen reading the copy drops it at once.
 */
async function dropFromDevice(uid:string,items:Partial<Record<Name,string[]>>){await Promise.all(Object.entries(items).flatMap(([name,ids])=>(ids||[]).slice(0,200).map(id=>getDocFromServer(ref(uid,name as Name,id)).catch(()=>undefined))));}
/** Resolves when everything this device wrote (e.g. a delete made offline) has reached the cloud. */
export const whenSent=()=>waitForPendingWrites(database());
/**
 * On opening the app (and when the connection returns): deletes this device made are finished on the server.
 * First the device's own queue is sent (a delete may just be waiting there); then every transaction deleted here,
 * or deleted in the "Batalkan" window just before the app was closed, that the server still holds is deleted again.
 * Only a delete the server refuses (not a missing connection) lets the transaction show again.
 */
/**
 * Keeps the cloud free of what the app no longer shows (at most twice a day, on app open):
 *  - delete notes older than a week (other devices have long picked them up; a device away longer re-reads in full
 *    after its daily count check, lib/sync.ts);
 *  - drafts skipped under older versions (kept as "dismissed");
 *  - archived wallets, categories and pockets that nothing refers to any more (not a transaction, budget, schedule,
 *    plan, note, history or Split Bill), e.g. after their last transaction was deleted.
 * Returns how many documents were deleted.
 */
export async function tidyCloud(uid:string){
  if(isOffline())return 0;
  const key=`dompet-ajaib:tidy:${uid}`;try{const last=Number(localStorage.getItem(key)||0);if(Date.now()-last<12*36e5)return 0;}catch{/* runs anyway */}
  let removed=0;const {deleteDoc,Timestamp}=await import('firebase/firestore');
  try{
    const old=await getDocs(query(collection(database(),'users',uid,'deletions'),where('updatedAt','<',Timestamp.fromMillis(Date.now()-7*864e5)),limit(300)));
    for(let i=0;i<old.docs.length;i+=300){const b=writeBatch(database());old.docs.slice(i,i+300).forEach(row=>b.delete(row.ref));await b.commit();}removed+=old.size;
  }catch{/* next time */}
  try{
    const skipped=await getDocs(query(coll(uid,'drafts'),where('status','==','dismissed'),limit(300)));
    if(!skipped.empty){const b=writeBatch(database());skipped.docs.forEach(row=>b.delete(row.ref));await b.commit();await noteDeleted(uid,{drafts:skipped.docs.map(row=>row.id)});removed+=skipped.size;}
  }catch{/* next time */}
  try{
    // Only with a complete device copy: a reference the device does not have yet must never let a record go.
    const synced=syncedCollections.filter(name=>name!=='deletions') as SyncedName[];
    if(await whenCurrent(uid,synced,8000)){
      const texts:string[]=[];const archived:{name:'wallets'|'categories'|'funds';id:string}[]=[];
      // The profile refers to wallets and categories too (defaults, salary category, dashboard cards).
      const profile=await getDoc(userRef(uid));texts.push(JSON.stringify(profile.data()||{}));
      for(const name of names){let snap;try{snap=(synced as string[]).includes(name)?await getDocsFromCache(coll(uid,name)):await getDocs(coll(uid,name));}catch{return removed;}
        for(const row of snap.docs){const data=row.data();if((name==='wallets'||name==='categories'||name==='funds')&&data.isArchived===true)archived.push({name,id:row.id});texts.push(JSON.stringify(data));}}
      const all=texts.join('\n');
      const unused=archived.filter(item=>!all.includes(`"${item.id}"`));
      for(const item of unused){await deleteDoc(ref(uid,item.name,item.id));removed++;}
      const byName:Partial<Record<Name,string[]>>={};unused.forEach(item=>(byName[item.name]||=[]).push(item.id));if(unused.length)await noteDeleted(uid,byName);
    }
  }catch{/* next time */}
  try{localStorage.setItem(key,String(Date.now()));}catch{/* optional */}
  return removed;
}
export async function checkDeletedTransactions(uid:string){if(isOffline())return;
  try{await Promise.race([waitForPendingWrites(database()),new Promise((_,no)=>setTimeout(()=>no(Error('timeout')),15000))]);}catch{return;/* the queue is still busy: next time */}
  for(const id of deletedTxIds().slice(0,100)){
    try{const snap=await getDocFromServer(ref(uid,'transactions',id));
      if(!snap.exists())continue;
      await deleteTransaction(uid,id);
    }catch(error){if(isOffline()||/offline|network|unavailable/i.test(String((error as Error)?.message||'')))continue;forgetTxDeleted([id]);console.error('Transaksi belum bisa dihapus dari cloud',error);}
  }}
/** After deleting many documents at once (restore, reset): other devices compare counts and re-read those collections. */
export async function markDeleted(uid:string,...collections:Name[]){try{await settle(updateDoc(userRef(uid),Object.fromEntries(collections.map(name=>[`syncMarks.${name}`,serverTimestamp()]))))}catch{/* the daily count check still catches it */}}
const loginKey=(uid:string)=>`dompet-ajaib:last-login:${uid}`;
export async function initProfile(user:User) {
  const r=userRef(user.uid); let snapshot=await getDocFromCache(r).catch(()=>null);
  if (!snapshot?.exists()) snapshot=await getDoc(r);
  if (!snapshot.exists()) await settle(setDoc(r,{uid:user.uid,email:user.email||'',username:(user.email||'').split('@')[0],displayName:user.displayName||'',currency:'IDR',salaryCycleStartDay:24,monthlySalary:0,onboardingDone:false,hideReserved:true,theme:'light',dashboardWidgets:[],createdAt:serverTimestamp(),updatedAt:serverTimestamp(),lastLoginAt:serverTimestamp()}));
  // Last login is noted at most twice a day, not on every open.
  else { let last=0;try{last=Number(localStorage.getItem(loginKey(user.uid)))||0}catch{/* ignore */} if(Date.now()-last>12*36e5){await settle(updateDoc(r,{lastLoginAt:serverTimestamp()}));try{localStorage.setItem(loginKey(user.uid),String(Date.now()))}catch{/* ignore */}} }
}
export function subscribeProfile(uid:string,onValue:(value:Profile|null)=>void,onError:(e:Error)=>void):Unsubscribe { return onSnapshot(userRef(uid),s=>onValue(s.exists()?s.data() as Profile:null),onError); }
// Screens read the device copy that lib/sync.ts keeps current: opening a report or switching tabs costs no reads.
const local={source:'cache'} as const;
export function subscribePeriodTransactions(uid:string,start:string,end:string,onValue:(items:LedgerTx[])=>void,onError:(error:Error)=>void):Unsubscribe {
  return onSnapshot(query(coll(uid,'transactions'),where('date','>=',start),where('date','<',end)),local,snapshot=>onValue(withoutDeleted(snapshot.docs.map(row=>hydrate<LedgerTx>(row))).sort(newestFirst)),onError);
}
export function subscribeRelatedTransactions(uid:string,field:'receivableId'|'claimId'|'debtId'|'fundId',id:string,onValue:(items:LedgerTx[])=>void,onError:(error:Error)=>void):Unsubscribe {
 return onSnapshot(query(coll(uid,'transactions'),where(field,'==',id)),local,snapshot=>onValue(withoutDeleted(snapshot.docs.map(row=>hydrate<LedgerTx>(row))).sort(newestFirst)),onError);
}
export function subscribeData(uid:string,start:string,end:string,onPart:(key:Name,value:unknown[])=>void,onError:(e:Error)=>void,onSync?:(state:'syncing'|'synced'|'offline')=>void,asOf=new Date(),salaryDay=24):Unsubscribe {
  const all:Unsubscribe[]=[];
  const month=calendarCycle(asOf);
  const baseline=start<month.start?start:month.start;
  const baselineEnd=end>month.end?end:month.end;
  const union=new Map<string,LedgerTx>();let recent:LedgerTx[]=[];let cycle:LedgerTx[]=[];let calendar:LedgerTx[]=[];let custom:LedgerTx[]=[];
  let customRange='',customStop:Unsubscribe|undefined;
  const emit=()=>{ union.clear(); for(const t of [...recent,...cycle,...calendar,...custom]) union.set(t.id,t); onPart('transactions',withoutDeleted([...union.values()]).sort(newestFirst)); };
  // Status: unsent changes or a copy that is still catching up → syncing; no connection → offline.
  let pending=false,current=false,failed='';
  const report=()=>onSync?.(isOffline()?'offline':pending||!current?'syncing':'synced');
  all.push(watchSync(status=>{current=status.current;if(status.failed&&status.failed!==failed){failed=status.failed;onError(Object.assign(new Error('Sinkronisasi data gagal.'),{code:status.failed}))}report();}));
  window.addEventListener('online',report);window.addEventListener('offline',report);all.push(()=>{window.removeEventListener('online',report);window.removeEventListener('offline',report)});
  for(const name of names) {
    if(name==='transactions'||name==='categorizationRules'||onDemand.has(name)) continue;
    all.push(onSnapshot(coll(uid,name),local,s=>{
      const value=s.docs.map(d=>hydrate(d));
      // Wallets in the order arranged on the Dompet page, so "the first wallet" (a form's default) is the same one everywhere.
      if(name==='wallets')(value as Wallet[]).sort((a,b)=>(a.displayOrder??1e6)-(b.displayOrder??1e6)||a.name.localeCompare(b.name));
      onPart(name,value);
      if(name!=='budgets')return;
      const windows=(value as Budget[]).map(budget=>budgetWindow(budget,asOf,salaryDay));
      const earliest=windows.reduce((date,window)=>window.start<date?window.start:date,baseline);
      const latest=windows.reduce((date,window)=>window.end>date?window.end:date,baselineEnd);
      const key=`${earliest}:${latest}`;if(key===customRange)return;
      customStop?.();custom=[];customRange=key;emit();
      if(earliest<baseline||latest>baselineEnd)customStop=onSnapshot(query(coll(uid,'transactions'),where('date','>=',earliest),where('date','<',latest)),local,history=>{custom=history.docs.map(d=>hydrate<LedgerTx>(d));emit();},onError);
    },onError));
  }
  all.push(onSnapshot(query(coll(uid,'transactions'),orderBy('date','desc'),limit(60)),{...local,includeMetadataChanges:true},s=>{recent=s.docs.map(d=>hydrate<LedgerTx>(d));emit();pending=s.metadata.hasPendingWrites;report();},onError));
  all.push(onSnapshot(query(coll(uid,'transactions'),where('date','>=',start),where('date','<',end)),local,s=>{cycle=s.docs.map(d=>hydrate<LedgerTx>(d));emit();},onError));
  if(month.start!==start||month.end!==end)all.push(onSnapshot(query(coll(uid,'transactions'),where('date','>=',month.start),where('date','<',month.end)),local,s=>{calendar=s.docs.map(d=>hydrate<LedgerTx>(d));emit();},onError));
  return ()=>{all.forEach(stop=>stop());customStop?.();};
}
export async function saveProfile(uid:string,changes:Partial<Profile>) { await settle(updateDoc(userRef(uid),{...changes,updatedAt:serverTimestamp()})); }
/**
 * Kamus Pribadi: each alias is written as its own field (personalLexicon.aliases.<id>), so two devices editing different
 * words never overwrite each other; null removes an alias. `reset` empties the dictionary (financial data untouched).
 */
export async function saveLexicon(uid:string,changes:Record<string,import('./catat/personal').PersonalAlias|null>,options:{on?:boolean;reset?:boolean}={}) {
  const update:Record<string,unknown>={updatedAt:serverTimestamp()};
  if(options.reset) update.personalLexicon={on:options.on!==false,aliases:{}};
  else { if(options.on!==undefined) update['personalLexicon.on']=options.on; for(const [id,alias] of Object.entries(changes)) { if(!/^[a-z]+_[0-9a-z]+$/.test(id)) continue; update[`personalLexicon.aliases.${id}`]=alias===null?deleteField():alias; } }
  await settle(updateDoc(userRef(uid),update));
}
export async function saveWallet(uid:string,input:Partial<Wallet>&{name:string;openingBalance:number},id?:string) {
  if(!Number.isSafeInteger(input.openingBalance)) throw Error('Saldo awal harus berupa angka Rupiah yang valid.');
  if(input.openingBusinessBalance!==undefined)walletOpeningBalances({openingBalance:input.openingBalance,openingBusinessBalance:input.openingBusinessBalance} as Wallet);
  if(!id&&!input.balanceSplitEnabled&&input.openingBusinessBalance)throw Error('Aktifkan split saldo untuk mengisi saldo bisnis.');
  if(input.color&&!/^#[0-9a-fA-F]{6}$/.test(input.color))throw Error('Warna dompet tidak valid.');
  const account=input.accountNumber===undefined?undefined:input.accountNumber.replace(/\s+/g,' ').trim();if(account&&(account.length>40||!/^[0-9A-Za-z .\-]+$/.test(account)))throw Error('Nomor rekening hanya boleh berisi angka, huruf, spasi, titik, atau tanda hubung (maks. 40).');
  const r=id?ref(uid,'wallets',id):doc(coll(uid,'wallets'));
  if(!id) {await settle(setDoc(r,{...(account?{accountNumber:account}:{}),name:input.name.trim(),type:input.type||'bank',balanceSplitEnabled:input.balanceSplitEnabled===true,openingBusinessBalance:input.openingBusinessBalance||0,cachedBusinessBalance:input.openingBusinessBalance||0,openingBalance:input.openingBalance,cachedBalance:input.openingBalance,purpose:input.purpose||'',isReserved:input.isReserved||false,isSpendable:input.isSpendable??true,canPay:input.canPay??true,canReceive:input.canReceive??true,canTransferOut:input.canTransferOut??true,canTransferIn:input.canTransferIn??true,includeInNetWorth:input.includeInNetWorth??true,isArchived:false,group:input.group||walletGroup({type:input.type||'bank',isReserved:input.isReserved||false}),icon:input.icon||'💳',color:input.color||'#267e73',cardStyle:input.cardStyle||'soft',displayOrder:input.displayOrder??0,createdAt:serverTimestamp(),updatedAt:serverTimestamp()}));return r.id;}
  await runTx(database(),async trx=>{ const old=await trx.get(r);if(!old.exists()) throw Error('Dompet tidak ditemukan.'); const before=old.data() as Wallet;const split=input.balanceSplitEnabled??before.balanceSplitEnabled??false;const business=input.openingBusinessBalance??before.openingBusinessBalance??0;if(before.balanceSplitEnabled&&!split)throw Error('Split saldo yang sudah aktif tetap dipertahankan agar riwayat saldo konsisten.');if(!split&&business)throw Error('Aktifkan split saldo untuk mengisi saldo bisnis.');walletOpeningBalances({openingBalance:input.openingBalance,openingBusinessBalance:business} as Wallet);trx.update(r,{...(account!==undefined?{accountNumber:account}:{}),name:input.name.trim(),type:input.type||before.type,group:input.group||walletGroup(before),purpose:input.purpose??before.purpose,isReserved:input.isReserved??before.isReserved,isSpendable:input.isSpendable??before.isSpendable,canPay:input.canPay??before.canPay??true,canReceive:input.canReceive??before.canReceive??true,canTransferOut:input.canTransferOut??before.canTransferOut??true,canTransferIn:input.canTransferIn??before.canTransferIn??true,includeInNetWorth:input.includeInNetWorth??before.includeInNetWorth,isArchived:input.isArchived??before.isArchived,icon:input.icon??before.icon??'💳',color:input.color??before.color??'#267e73',cardStyle:input.cardStyle??before.cardStyle??'soft',displayOrder:input.displayOrder??before.displayOrder??0,balanceSplitEnabled:split,openingBusinessBalance:business,cachedBusinessBalance:increment(business-(before.openingBusinessBalance||0)),openingBalance:input.openingBalance,cachedBalance:increment(input.openingBalance-before.openingBalance),updatedAt:serverTimestamp()}); });await syncSnapshot(uid,'0000-01-01');return r.id;
}
export async function archiveOrDelete(uid:string,name:Name,id:string,data:Data) {
  if(name==='wallets') {const fields=['walletId','destinationWalletId'] as const;const used=(await Promise.all(fields.map(field=>readLocalFirst(uid,['transactions'],query(coll(uid,'transactions'),where(field,'==',id),limit(1)))))).some(snapshot=>!snapshot.empty)||data.funds.some(f=>f.linkedWalletId===id)||data.recurring.some(r=>r.walletId===id)||data.plannedTransactions.some(p=>p.walletId===id)||data.claims.some(c=>c.sourceWalletId===id)||data.receivables.some(c=>c.sourceWalletId===id);if(used){await settle(updateDoc(ref(uid,name,id),{isArchived:true,updatedAt:serverTimestamp()}));return 'archived';}}
  if(name==='categories') {const fieldHits=await Promise.all((['categoryId','subcategoryId','transferFeeCategoryId'] as const).map(field=>readLocalFirst(uid,['transactions'],query(coll(uid,'transactions'),where(field,'==',id),limit(1)))));const nested=(await loadAllTransactions(uid)).some(t=>t.splits?.some(line=>line.categoryId===id||line.subcategoryId===id));const used=fieldHits.some(snapshot=>!snapshot.empty)||nested||data.budgets.some(b=>b.categoryId===id||b.subcategoryId===id)||data.categories.some(c=>c.parentId===id)||data.recurring.some(r=>r.categoryId===id)||data.plannedTransactions.some(p=>p.categoryId===id||p.subcategoryId===id);if(used){await settle(updateDoc(ref(uid,name,id),{isArchived:true,updatedAt:serverTimestamp()}));return 'archived';}}
  if(name==='budgets'||name==='funds'||name==='recurring'||name==='wallets'||name==='categories') {if(name==='funds' && !(await readLocalFirst(uid,['transactions'],query(coll(uid,'transactions'),where('fundId','==',id),limit(1)))).empty){await settle(updateDoc(ref(uid,name,id),{isArchived:true,updatedAt:serverTimestamp()}));return 'archived';}const b=writeBatch(database());b.delete(ref(uid,name,id));await settle(b.commit());await noteDeleted(uid,{[name]:[id]});return 'deleted';}
  throw Error('Catatan ini hanya bisa diubah lewat transaksinya.');
}
export async function saveRecord<T extends Category|Budget|Fund|Recurring>(uid:string,name:'categories'|'budgets'|'funds'|'recurring',record:Partial<T>,id?:string) {
  const r=id?ref(uid,name,id):doc(coll(uid,name));
  const {id:_ignored,createdAt:_created,updatedAt:_updated,...fields}=record;
  if(name==='recurring'){
    const previous=id?await readDoc(uid,'recurring',r):null;
    if(id&&!previous?.exists())throw Error('Jadwal tidak ditemukan.');
    const schedule:DocumentData={...previous?.data(),...fields};
    const sourceKind=validateBalanceKind(schedule.balanceKind),destinationKind=validateBalanceKind(schedule.destinationBalanceKind);
    const selections:[unknown,BalanceKind][]=[[schedule.walletId,sourceKind]];
    if(schedule.type==='transfer'||schedule.type==='fund_contribution')selections.push([schedule.destinationWalletId,destinationKind]);
    for(const [walletId,kind] of selections){if(kind!=='business')continue;if(typeof walletId!=='string'||!walletId)throw Error('Pilih dompet untuk saldo Bisnis.');const snap=await readDoc(uid,'wallets',ref(uid,'wallets',walletId));if(!snap.exists())throw Error('Dompet tidak ditemukan.');validateWalletBalanceKind(hydrate<Wallet>(snap),kind);}
  }
  if(id)await settle(updateDoc(r,{...fields,updatedAt:serverTimestamp()}));else await settle(setDoc(r,{...fields,createdAt:serverTimestamp(),updatedAt:serverTimestamp()}));return r.id;
}
export async function saveDisplayOrder(uid:string,name:'categories'|'wallets'|'budgets'|'wishlist',ids:string[]){
 if(ids.length>400||new Set(ids).size!==ids.length)throw Error('Urutan tidak valid.');
 const field=name==='wallets'?'displayOrder':'sortOrder',known=new Map<string,unknown>();
 // Only the items whose position changed are written.
 try{(await getDocsFromCache(coll(uid,name))).docs.forEach(row=>known.set(row.id,row.get(field)))}catch{/* write them all */}
 const moved=ids.map((id,index)=>[id,index] as const).filter(([id,index])=>known.get(id)!==index);if(!moved.length)return;
 const batch=writeBatch(database());moved.forEach(([id,index])=>batch.update(ref(uid,name,id),{[field]:index,updatedAt:serverTimestamp()}));await settle(batch.commit());
}
export async function changeContextNote(uid:string,collectionName:'receivables'|'claims'|'debts'|'funds'|'wallets'|'splitBills',documentId:string,change:{kind:'add';text:string}|{kind:'edit';id:string;text:string}|{kind:'pin'|'delete';id:string}){
 const r=ref(uid,collectionName,documentId);await runTx(database(),async trx=>{const snap=await trx.get(r);if(!snap.exists())throw Error('Catatan terkait tidak ditemukan.');const entries=(snap.data().contextNotes||[]) as import('./types').ContextNote[];const now=new Date().toISOString();let next:typeof entries;
 if(change.kind==='add'){if(!change.text.trim())throw Error('Tulis isi catatan.');next=[...entries,{id:crypto.randomUUID(),text:change.text.trim(),createdAt:now}];}
 else{if(!entries.some(entry=>entry.id===change.id))throw Error('Catatan tidak ditemukan.');if(change.kind==='edit'){if(!change.text.trim())throw Error('Tulis isi catatan.');next=entries.map(entry=>entry.id===change.id?{...entry,text:change.text.trim(),updatedAt:now}:entry)}else if(change.kind==='pin')next=entries.map(entry=>entry.id===change.id?{...entry,pinned:!entry.pinned}:entry);else next=entries.filter(entry=>entry.id!==change.id);}
 trx.update(r,{contextNotes:next,updatedAt:serverTimestamp()});});
}
export function newTx(input:Partial<LedgerTx>&Pick<LedgerTx,'type'|'amount'|'walletId'>):LedgerTx {return {id:input.id||'',type:input.type,amount:input.amount,date:input.date||new Date().toLocaleDateString('en-CA'),time:input.time||'',walletId:input.walletId,balanceKind:input.balanceKind??'personal',destinationBalanceKind:input.destinationBalanceKind??'personal',destinationWalletId:input.destinationWalletId||null,categoryId:input.categoryId||null,subcategoryId:input.subcategoryId||null,merchant:input.merchant||'',description:input.description||'',notes:input.notes||'',tags:input.tags||[],claimId:input.claimId||null,debtId:input.debtId||null,receivableId:input.receivableId||null,fundId:input.fundId||null,recurringTransactionId:input.recurringTransactionId||null,draftId:input.draftId||null,adjustmentDirection:input.adjustmentDirection||'in',splits:input.splits||[],transferFee:input.transferFee||0,transferFeeCategoryId:input.transferFeeCategoryId||null,reconciliationReason:input.reconciliationReason||'',plannedId:input.plannedId||null,...(input.splitBillId?{splitBillId:input.splitBillId}:{}),...(input.ownShare!=null?{ownShare:input.ownShare}:{}),...(input.ownSplits?.length?{ownSplits:input.ownSplits}:{}),...(input.counterparty?{counterparty:input.counterparty}:{}),...(input.origin?{origin:input.origin}:{}),...(input.receipt?{receipt:input.receipt}:{})};}
export class SnapshotRefreshError extends Error {committed=true;constructor(){super('Transaksi sudah tercatat, tetapi laporan siklus belum berhasil diperbarui. Buka Riwayat Siklus lalu pilih Perbarui laporan. Jangan catat transaksi ini lagi.')}}
export async function syncSnapshot(uid:string,date:string){if(isOffline()){whenOnline(`snapshot:${uid}:${date}`,()=>syncSnapshot(uid,date));return}try{await (await import('./finance-store')).refreshCycleSnapshots(uid,date)}catch(error){console.error(error);throw new SnapshotRefreshError()}}
export function validateTx(tx:LedgerTx) {if(!validAmount(tx.amount))throw Error('Nominal harus lebih dari nol.');if(!tx.walletId)throw Error('Pilih dompet.');validateBalanceKind(tx.balanceKind);validateBalanceKind(tx.destinationBalanceKind);if((tx.type==='transfer'||tx.type==='fund_contribution')&&(!tx.destinationWalletId||tx.walletId===tx.destinationWalletId&&(tx.type!=='transfer'||(tx.balanceKind??'personal')===(tx.destinationBalanceKind??'personal'))))throw Error('Pilih dompet atau bagian saldo tujuan yang berbeda.');if(tx.type==='expense'&&!tx.categoryId&&!tx.splits?.length)throw Error('Pilih kategori pengeluaran.');if(tx.splits?.length){if(tx.type!=='expense')throw Error('Pembagian hanya untuk pengeluaran.');if(tx.splits.some(line=>!line.categoryId||!validAmount(line.amount)))throw Error('Setiap pembagian membutuhkan kategori dan nominal positif.');const sum=tx.splits.reduce((n,line)=>n+line.amount,0);if(sum!==tx.amount)throw Error(sum<tx.amount?`Pembagian masih kurang Rp${(tx.amount-sum).toLocaleString('id-ID')}.`:`Pembagian melebihi total transaksi Rp${(sum-tx.amount).toLocaleString('id-ID')}.`);}if(tx.transferFee&&tx.type!=='transfer'||tx.transferFee!==undefined&&(!Number.isSafeInteger(tx.transferFee)||tx.transferFee<0))throw Error('Biaya admin tidak valid.');if(tx.type==='transfer'&&tx.transferFee&&!tx.transferFeeCategoryId)throw Error('Pilih kategori biaya admin.');if((tx.type==='claim_payment'&&!tx.claimId)||(tx.type==='debt_payment'&&!tx.debtId)||(tx.type==='receivable_payment'&&!tx.receivableId)||(tx.type==='fund_contribution'&&!tx.fundId))throw Error('Pilih catatan terkait.');}
function relation(tx:LedgerTx,sign:number) { const side: {kind:'claims'|'receivables'|'debts'|'funds';id:string;delta:number}|null =
 (tx.type==='claim_payment'||tx.type==='claim_writeoff')&&tx.claimId?{kind:'claims',id:tx.claimId,delta:-tx.amount*sign}:
 tx.type==='receivable_payment'&&tx.receivableId?{kind:'receivables',id:tx.receivableId,delta:-tx.amount*sign}:
 tx.type==='debt_payment'&&tx.debtId?{kind:'debts',id:tx.debtId,delta:-tx.amount*sign}:
 tx.type==='fund_contribution'&&tx.fundId?{kind:'funds',id:tx.fundId,delta:tx.amount*sign}:null;
 return side;
}
const splitManaged='Transaksi ini adalah bagianmu di Split Bill (dibayar orang lain). Ubah lewat menu Split Bill.';
/**
 * V3.3 options: `opId` makes a create idempotent (a retried or double-tapped save finds the same document and does
 * nothing); `expect` is the state the confirmed preview was computed from (a settle "lunas", an edit of Rp19.000) and is
 * checked again inside the transaction, so a change made meanwhile on another device is never overwritten blindly.
 */
export type CommitExpect={kind:'receivables'|'debts'|'claims';id:string;remaining:number}|{kind:'transactions';id:string;amount:number};
export class StaleStateError extends Error{constructor(message:string){super(message);this.name='StaleStateError';}}
export async function upsertTransaction(uid:string,input:LedgerTx,editId?:string,options:{opId?:string;expect?:CommitExpect;useCurrentDraft?:boolean}={}) {
  validateTx(input);const r=editId?ref(uid,'transactions',editId):options.opId?ref(uid,'transactions',options.opId):doc(coll(uid,'transactions'));
  let previousDate=input.date,already=false;
  // Standalone additions use an offline-capable atomic batch. Edits and linked repayments use transactions for consistency checks.
  const linked=Boolean(relation(input,1)||input.draftId||input.plannedId||options.opId||options.expect);
  if(!editId&&!linked) {const actions=walletActions(input);const source=await readDoc(uid,'wallets',ref(uid,'wallets',input.walletId));if(!source.exists())throw Error('Dompet asal tidak ditemukan.');validateWalletUse(hydrate<Wallet>(source),actions.source);validateWalletBalanceKind(hydrate<Wallet>(source),input.balanceKind);if(actions.destination&&input.destinationWalletId){const destination=await readDoc(uid,'wallets',ref(uid,'wallets',input.destinationWalletId));if(!destination.exists())throw Error('Dompet tujuan tidak ditemukan.');validateWalletUse(hydrate<Wallet>(destination),actions.destination);validateWalletBalanceKind(hydrate<Wallet>(destination),input.destinationBalanceKind);}const batch=writeBatch(database());const {id:_batchId,...payload}=input;batch.set(r,{...payload,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});for(const [wallet,delta] of Object.entries(balanceCacheDeltas(input))) batch.update(ref(uid,'wallets',wallet),cacheIncrements(delta));const pending=batch.commit();if(typeof navigator!=='undefined'&&!navigator.onLine){void pending.catch(console.error);return r.id;}await pending;await syncSnapshot(uid,input.date);return r.id;}
  await runTx(database(),async trx=>{
    if(!editId&&options.opId){const prior=await trx.get(r);if(prior.exists()){already=true;return;}}
    if(options.expect){const e=options.expect;const snap=await trx.get(ref(uid,e.kind,e.id));if(!snap.exists())throw new StaleStateError('Catatan yang dirujuk sudah tidak ada. Cek lagi sebelum menyimpan.');const d=snap.data();
      if(e.kind==='transactions'){if(Number(d.amount)!==e.amount)throw new StaleStateError(`Transaksi ini sudah berubah (sekarang Rp${Number(d.amount).toLocaleString('id-ID')}). Cek lagi sebelum menyimpan.`);}
      else{const now=Number(e.kind==='debts'?d.outstandingAmount:d.remainingAmount);if(now!==e.remaining)throw new StaleStateError(`Sisanya sudah berubah (sekarang Rp${now.toLocaleString('id-ID')}). Cek lagi sebelum menyimpan.`);}}
    const oldSnap=editId?await trx.get(r):null; if(editId&&!oldSnap?.exists())throw Error('Transaksi tidak ditemukan.');
    const old=oldSnap?.exists()?hydrate<LedgerTx>(oldSnap):null;previousDate=old?.date||input.date;
    const draftRef=input.draftId?ref(uid,'drafts',input.draftId):null;
    const draftSnap=draftRef?await trx.get(draftRef):null;
    if(options.useCurrentDraft){if(!draftSnap?.exists()||draftSnap.data().status!=='pending'||draftSnap.data().mode!=='auto'){already=true;return;}const draft=hydrate<Draft>(draftSnap);input=newTx({type:draft.type,amount:draft.amount,date:draft.plannedDate,walletId:draft.walletId,balanceKind:draft.balanceKind,destinationBalanceKind:draft.destinationBalanceKind,destinationWalletId:draft.destinationWalletId,categoryId:draft.categoryId,description:draft.name,draftId:draft.id,recurringTransactionId:draft.recurringId});validateTx(input);}
    const actions=walletActions(input);const walletSnap=await trx.get(ref(uid,'wallets',input.walletId));if(!walletSnap.exists())throw Error('Dompet asal tidak ditemukan.');validateWalletUse(hydrate<Wallet>(walletSnap),actions.source,old,input);validateWalletBalanceKind(hydrate<Wallet>(walletSnap),input.balanceKind);
    if(actions.destination&&input.destinationWalletId){const target=await trx.get(ref(uid,'wallets',input.destinationWalletId));if(!target.exists())throw Error('Dompet tujuan tidak ditemukan.');validateWalletBalanceKind(hydrate<Wallet>(target),input.destinationBalanceKind);if(!(old?.destinationWalletId===input.destinationWalletId&&walletActions(old).destination===actions.destination))validateWalletUse(hydrate<Wallet>(target),actions.destination);}
    if(old?.type==='claim_writeoff')throw Error('Hapus transaksi penolakan lalu catat ulang bila perlu mengoreksi nominal.');
    // A Split Bill's payment keeps its link; its amount and the share that is not the user's own are changed on the bill.
    if(old?.splitBillId&&old.type==='expense'){if(!old.walletId)throw Error(splitManaged);if(input.type!=='expense'||input.amount!==old.amount)throw Error('Nominal transaksi ini diatur oleh Split Bill. Ubah lewat menu Split Bill.');if(input.walletId!==old.walletId||(input.balanceKind??'personal')!==(old.balanceKind??'personal'))throw Error('Dompet dan bagian saldo transaksi ini diatur oleh Split Bill. Ubah lewat menu Split Bill.');input={...input,splitBillId:old.splitBillId,ownShare:old.ownShare??null,...(old.ownSplits?.length?{ownSplits:old.ownSplits}:{})};}if(old&&(['claim_advance','receivable_issue','borrowing'].includes(old.type)||['claim_advance','receivable_issue','borrowing'].includes(input.type))) throw Error('Transaksi pembuka dicatat melalui menu terkait; ubah melalui catatannya.');
    const delta=combineBalanceCacheDeltas(input,old??undefined);
    const relations=[...(old?[relation(old,-1)]:[]),relation(input,1)].filter((v):v is NonNullable<typeof v>=>!!v);
    const related=new Map<string,{r:DocumentReference;kind:string;value:DocumentData;delta:number}>();
    for(const rel of relations){const key=rel.kind+'/'+rel.id;if(!related.has(key)){const rr=ref(uid,rel.kind,rel.id);const snap=await trx.get(rr);if(!snap.exists())throw Error('Catatan terkait tidak ditemukan.');related.set(key,{r:rr,kind:rel.kind,value:snap.data(),delta:0});}related.get(key)!.delta+=rel.delta;}
    // Paying back (or being paid back) a Split Bill share is marked with the bill: it is neither income nor new spending.
    const target=relation(input,1),targetValue=target?related.get(target.kind+'/'+target.id)?.value:undefined;
    {const bill=(input.type==='receivable_payment'||input.type==='debt_payment')&&typeof targetValue?.splitBillId==='string'?targetValue.splitBillId:'';if(bill)input={...input,splitBillId:bill,categoryId:null,subcategoryId:null};else if(old?.splitBillId&&old.type!=='expense')input={...input,splitBillId:null};}
    if(draftRef&&(!draftSnap?.exists()||!old&&draftSnap.data().status!=='pending'))throw Error('Transaksi ini sudah diproses atau tidak tersedia di daftar konfirmasi.');
    const plannedRef=input.plannedId?ref(uid,'plannedTransactions',input.plannedId):null;
    const plannedSnap=plannedRef?await trx.get(plannedRef):null;
    if(plannedRef&&(!plannedSnap?.exists()||!old&&plannedSnap.data().status!=='planned'))throw Error('Rencana sudah diproses atau tidak tersedia.');
    for(const [w,n] of Object.entries(delta))trx.update(ref(uid,'wallets',w),cacheIncrements(n));
    for(const item of related.values()) {const key=item.kind==='claims'||item.kind==='receivables'?'remainingAmount':item.kind==='debts'?'outstandingAmount':'currentAmount';const next=Number(item.value[key]||0)+item.delta;const cap=Number(item.value.amount??item.value.originalAmount??item.value.targetAmount??Infinity);if(next<0||next>cap&&item.kind!=='funds')throw Error('Pembayaran melebihi sisa tagihan.');const changes:Record<string,unknown>={[key]:next,updatedAt:serverTimestamp()};if(item.kind==='debts')changes.status=next===0?'paid':'open';if(item.kind==='receivables')changes.status=next===0?'paid':next<Number(item.value.originalAmount)?'partial':'open';if(item.kind==='claims')changes.status=input.type==='claim_writeoff'?'rejected':next===0?'paid':item.value.status==='paid'?'waiting':item.value.status;trx.update(item.r,changes);}
    const {id:_id,createdAt:_c,updatedAt:_u,...fields}=input;
    if(old?.draftId&&old.draftId!==input.draftId)trx.update(ref(uid,'drafts',old.draftId),{status:'pending',updatedAt:serverTimestamp()});if(draftRef&&(!old||old.draftId!==input.draftId))trx.update(draftRef,{status:'posted',updatedAt:serverTimestamp()});
    if(old?.plannedId&&old.plannedId!==input.plannedId)trx.update(ref(uid,'plannedTransactions',old.plannedId),{status:'planned',postedTransactionId:null,updatedAt:serverTimestamp()});if(plannedRef)trx.update(plannedRef,{status:'posted',postedTransactionId:r.id,updatedAt:serverTimestamp()});
    if(old)trx.update(r,{...fields,updatedAt:serverTimestamp()});else trx.set(r,{...fields,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});
  });if(already)return r.id;await syncSnapshot(uid,previousDate<input.date?previousDate:input.date);return r.id;
}
export async function deleteTransaction(uid:string,id:string,expect?:{amount:number}) {
  const r=ref(uid,'transactions',id);let removedDate='',droppedDraft='';
  // Offline, a plain transaction is deleted with a queued batch so the change survives closing the app.
  // Online, the transaction is read again inside the commit so concurrent deletes cannot reverse its balances twice.
  const current=await readDoc(uid,'transactions',r);
  if(!current.exists()){const server=await getDocFromServer(r).catch(()=>null);if(!server?.exists()){markTxDeleted([id]);return;}}
  const plain=current.exists()?hydrate<LedgerTx>(current):null;
  // V3.3: deleting what the preview showed, not something changed since on another device.
  if(expect&&plain&&plain.amount!==expect.amount)throw new StaleStateError(`Transaksi ini sudah berubah (sekarang Rp${plain.amount.toLocaleString('id-ID')}). Cek lagi sebelum menghapus.`);
  if(isOffline()&&plain&&!['claim_advance','receivable_issue','borrowing'].includes(plain.type)&&!(plain.splitBillId&&plain.type==='expense')&&!relation(plain,-1)&&!plain.draftId&&!plain.plannedId){
    const batch=writeBatch(database());
    // A wallet deleted since then has no balance to correct (updating it would fail the whole batch).
    for(const [wallet,delta] of Object.entries(balanceCacheDeltas(plain,-1))){const w=await readDoc(uid,'wallets',ref(uid,'wallets',wallet)).catch(()=>null);if(w?.exists())batch.update(w.ref,cacheIncrements(delta));}
    batch.delete(r);markTxDeleted([id]);
    try{await settle(batch.commit());}catch(error){forgetTxDeleted([id]);throw error;}
    await noteDeleted(uid,{transactions:[id]});await syncSnapshot(uid,plain.date);return;
  }
  await runTx(database(),async trx=>{const snap=await trx.get(r);if(!snap.exists())return;const old=hydrate<LedgerTx>(snap);removedDate=old.date;
    if(expect&&old.amount!==expect.amount)throw new StaleStateError(`Transaksi ini sudah berubah (sekarang Rp${old.amount.toLocaleString('id-ID')}). Cek lagi sebelum menghapus.`);
    if(['claim_advance','receivable_issue','borrowing'].includes(old.type))throw Error('Transaksi ini dibuat otomatis dari catatan utang, klaim, atau piutang. Ubah atau hapus lewat catatan tersebut.');
    if(old.splitBillId&&old.type==='expense')throw Error('Transaksi ini bagian dari Split Bill. Batalkan atau ubah lewat menu Split Bill.');
    const side=relation(old,-1);const rr=side?ref(uid,side.kind,side.id):null;const sideSnap=rr?await trx.get(rr):null;
    const draftRef=old.draftId?ref(uid,'drafts',old.draftId):null,draftSnap=draftRef?await trx.get(draftRef):null;
    const reverse=balanceCacheDeltas(old,-1),wallets=new Map(await Promise.all(Object.keys(reverse).map(async wallet=>[wallet,await trx.get(ref(uid,'wallets',wallet))] as const)));
    for(const [wallet,delta] of Object.entries(reverse)){const currentWallet=wallets.get(wallet);if(currentWallet?.exists())trx.update(currentWallet.ref,cacheIncrements(delta));}
    if(side&&rr&&sideSnap?.exists()){const obj=sideSnap.data();const key=side.kind==='claims'||side.kind==='receivables'?'remainingAmount':side.kind==='debts'?'outstandingAmount':'currentAmount';const next=Number(obj[key])+side.delta;trx.update(rr,{[key]:next,...(side.kind==='claims'?{status:next===0?'paid':['paid','rejected'].includes(obj.status)?'waiting':obj.status}:{}),...(side.kind==='debts'?{status:next===0?'paid':'open'}:{}),...(side.kind==='receivables'?{status:next===0?'paid':next<Number(obj.originalAmount)?'partial':'open'}:{}),updatedAt:serverTimestamp()});}
    // A deleted automatic entry is gone for good (its draft too: back to "pending" it would be recorded again at once); one to confirm goes back to Perlu dikonfirmasi.
    if(draftRef&&draftSnap?.exists()){if(draftSnap.data().mode==='auto'){trx.delete(draftRef);droppedDraft=draftRef.id;}else trx.update(draftRef,{status:'pending',updatedAt:serverTimestamp()});}if(old.plannedId)trx.update(ref(uid,'plannedTransactions',old.plannedId),{status:'planned',postedTransactionId:null,updatedAt:serverTimestamp()});trx.delete(r);
  });if(removedDate){await noteDeleted(uid,{transactions:[id],...(droppedDraft?{drafts:[droppedDraft]}:{})});await syncSnapshot(uid,removedDate);}
}
export async function createClaim(uid:string,claim:Omit<Claim,'id'|'remainingAmount'|'createdAt'|'updatedAt'>) {if(!validAmount(claim.amount))throw Error('Nominal tidak valid.');await checkBalanceWallet(uid,claim.sourceWalletId,claim.sourceBalanceKind,'pay');const r=doc(coll(uid,'claims'));const t=doc(coll(uid,'transactions'));const batch=writeBatch(database());batch.set(r,{...claim,remainingAmount:claim.amount,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});const {id:_c,...claimTx}=newTx({type:'claim_advance',amount:claim.amount,walletId:claim.sourceWalletId,balanceKind:claim.sourceBalanceKind,claimId:r.id,date:claim.submissionDate,description:claim.name});batch.set(t,{...claimTx,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});for(const [wallet,delta] of Object.entries(balanceCacheDeltas(claimTx as LedgerTx)))batch.update(ref(uid,'wallets',wallet),cacheIncrements(delta));await settle(batch.commit());await syncSnapshot(uid,claim.submissionDate);return r.id;}
export async function createReceivable(uid:string,item:Omit<Receivable,'id'|'remainingAmount'|'createdAt'|'updatedAt'>) {if(!validAmount(item.originalAmount))throw Error('Nominal tidak valid.');const r=doc(coll(uid,'receivables'));if(!item.sourceWalletId){await settle(setDoc(r,{...item,sourceWalletId:'',remainingAmount:item.originalAmount,createdAt:serverTimestamp(),updatedAt:serverTimestamp()}));return r.id;}await checkBalanceWallet(uid,item.sourceWalletId,item.sourceBalanceKind,'pay');const t=doc(coll(uid,'transactions'));const batch=writeBatch(database());batch.set(r,{...item,remainingAmount:item.originalAmount,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});const {id:_r,...receivableTx}=newTx({type:'receivable_issue',amount:item.originalAmount,walletId:item.sourceWalletId,balanceKind:item.sourceBalanceKind,receivableId:r.id,date:item.date,description:item.person});batch.set(t,{...receivableTx,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});for(const [wallet,delta] of Object.entries(balanceCacheDeltas(receivableTx as LedgerTx)))batch.update(ref(uid,'wallets',wallet),cacheIncrements(delta));await settle(batch.commit());await syncSnapshot(uid,item.date);return r.id;}
export async function createDebt(uid:string,item:Omit<Debt,'id'|'outstandingAmount'|'status'|'createdAt'|'updatedAt'>,creditWallet?:string,date?:string,balanceKind:BalanceKind='personal') {if(!validAmount(item.originalAmount))throw Error('Nominal tidak valid.');const r=doc(coll(uid,'debts'));const batch=writeBatch(database());batch.set(r,{...item,outstandingAmount:item.originalAmount,status:'open',createdAt:serverTimestamp(),updatedAt:serverTimestamp()});let borrowedOn='';if(creditWallet){await checkBalanceWallet(uid,creditWallet,balanceKind,'receive');const t=doc(coll(uid,'transactions'));const {id:_d,...debtTx}=newTx({type:'borrowing',amount:item.originalAmount,walletId:creditWallet,balanceKind,debtId:r.id,description:item.name,date});batch.set(t,{...debtTx,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});borrowedOn=debtTx.date;for(const [wallet,delta] of Object.entries(balanceCacheDeltas(debtTx as LedgerTx)))batch.update(ref(uid,'wallets',wallet),cacheIncrements(delta));}await settle(batch.commit());if(borrowedOn)await syncSnapshot(uid,borrowedOn);return r.id;}
export async function updateLinked(uid:string,name:'claims'|'debts'|'receivables',id:string,changes:Record<string,unknown>) {await settle(updateDoc(ref(uid,name,id),{...changes,updatedAt:serverTimestamp()}));await syncSnapshot(uid,'0000-01-01');}
export async function recalculateBalance(uid:string,wallet:Wallet) {
  if(isOffline())throw Error('Hubungkan internet dahulu untuk menghitung ulang saldo dari catatan lengkap.');
  const r=ref(uid,'wallets',wallet.id),before=await getDocFromServer(r);
  if(!before.exists())throw Error('Dompet tidak ditemukan.');
  const current=hydrate<Wallet>(before);
  const [a,b]=await Promise.all([getDocsFromServer(query(coll(uid,'transactions'),where('walletId','==',wallet.id))),getDocsFromServer(query(coll(uid,'transactions'),where('destinationWalletId','==',wallet.id)))]);
  const all=new Map<string,LedgerTx>();for(const snap of [...a.docs,...b.docs])all.set(snap.id,hydrate<LedgerTx>(snap));
  const n=walletBalanceParts(current,[...all.values()]);
  await runTransaction(database(),async trx=>{const latest=await trx.get(r);if(!latest.exists()||!sameWalletBalanceState(current,hydrate<Wallet>(latest)))throw new StaleStateError('Saldo berubah saat dihitung. Jalankan Hitung ulang saldo sekali lagi.');trx.update(r,{cachedBalance:n.total,cachedBusinessBalance:n.business,updatedAt:serverTimestamp()});});
  return n.total;
}
export async function exportData(uid:string) {const all:Record<string,unknown[]>={};for(const name of names){all[name]=[];let cursor:QueryDocumentSnapshot|undefined;while(true){const base=query(coll(uid,name),orderBy('__name__'),...(cursor?[startAfter(cursor)]:[]),limit(400));const snap=await getDocs(base);all[name].push(...snap.docs.map(d=>({id:d.id,...d.data()})));if(snap.size<400)break;cursor=snap.docs[snap.docs.length-1];}}return {format:'dompet-ajaib-v1',ownerUid:uid,exportedAt:new Date().toISOString(),data:all};}
export function validateBackup(backup:unknown) {const b=backup as {format?:string;data?:Record<string,unknown>};if(!b||b.format!=='dompet-ajaib-v1'||!b.data)throw Error('Format file cadangan tidak dikenali.');const counts:Record<string,number>={};const extra=new Set<Name>(['plannedTransactions','categorizationRules','financialNotes','cycleSnapshots','wishlist','splitBills','splitPeople','splitGroups']);const normalized={...b.data};for(const name of names){if(extra.has(name)&&normalized[name]===undefined)normalized[name]=[];if(!Array.isArray(normalized[name]))throw Error(`Data ${name} tidak valid.`);const ids=new Set<string>();for(const item of normalized[name] as unknown[]){if(!item||typeof item!=='object'||typeof (item as {id?:unknown}).id!=='string'||!/^[\w-]{1,100}$/.test((item as {id:string}).id))throw Error(`ID data ${name} tidak valid.`);const id=(item as {id:string}).id;if(ids.has(id))throw Error(`ID data ${name} ${id} terduplikasi.`);ids.add(id);}counts[name]=(normalized[name] as unknown[]).length;}const data=normalized as Record<Name,Array<{id:string;[key:string]:unknown}>>;validateBackupBalances(data);return {counts,data};}
export async function importData(uid:string,backup:unknown,mode:'merge'|'replace',allowCrossAccount=false) {const {data}=validateBackup(backup);forgetTxDeleted();const owner=(backup as {ownerUid?:string}).ownerUid;if(owner&&owner!==uid&&!allowCrossAccount)throw Error('File cadangan ini berasal dari akun lain. Centang persetujuan jika tetap ingin mengimpornya.');if(mode==='merge'){const existing=await getDocs(coll(uid,'wallets'));data.wallets=mergeWalletSplitBalances(data.wallets,existing.docs.map(row=>hydrate<Wallet>(row)));validateBackupBalances(data);}if(mode==='replace'){for(const name of names){const snap=await getDocs(coll(uid,name));for(let i=0;i<snap.docs.length;i+=400){const batch=writeBatch(database());for(const d of snap.docs.slice(i,i+400))batch.delete(d.ref);await settle(batch.commit());}}await markDeleted(uid,...names);}
  for(const name of names){const arr=data[name];const chunk=name==='transactions'?10:350;for(let i=0;i<arr.length;i+=chunk){const batch=writeBatch(database());for(const row of arr.slice(i,i+chunk)){const {id,createdAt,updatedAt,...fields}=row;batch.set(ref(uid,name,id),{...fields,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});}await settle(batch.commit());}}const wallets=await getDocs(coll(uid,'wallets'));for(const snap of wallets.docs)await recalculateBalance(uid,hydrate<Wallet>(snap));
}

export async function settleBudgets(uid:string,budgets:Budget[],salaryDay:number,now=new Date()) {
  for(const budget of budgets.filter(b=>b.rolloverEnabled)) {
    const current=budgetWindow(budget,now,salaryDay);
    if(!budget.lastSettledStart){await settle(updateDoc(ref(uid,'budgets',budget.id),{lastSettledStart:current.start,rolloverCarry:0,updatedAt:serverTimestamp()}));continue;}
    if(budget.lastSettledStart>=current.start)continue;
    let cursor=budget.lastSettledStart,carry=budget.rolloverCarry||0,steps=0;
    const categories=(await readLocalFirst(uid,['categories'],coll(uid,'categories'))).docs.map(x=>hydrate<Category>(x));
    while(cursor<current.start&&steps++<(budget.cycleType==='weekly'?160:36)){const next=budgetWindow(budget,new Date(cursor+'T12:00:00'),salaryDay).end;if(next<=cursor)throw Error('Periode sisa anggaran tidak dapat dihitung.');const snap=await readLocalFirst(uid,['transactions'],query(coll(uid,'transactions'),where('date','>=',cursor),where('date','<',next)));const tx=snap.docs.map(x=>hydrate<LedgerTx>(x));carry+=budget.amount-budgetSpent(budget,tx,categories);cursor=next;}
    if(cursor<current.start)throw Error('Riwayat anggaran terlalu panjang untuk dihitung sekaligus.');
    await runTx(database(),async trx=>{const r=ref(uid,'budgets',budget.id),snap=await trx.get(r);if(!snap.exists()||snap.data().lastSettledStart!==budget.lastSettledStart)return;trx.update(r,{rolloverCarry:carry,lastSettledStart:current.start,updatedAt:serverTimestamp()});});
  }
}
const splitRecord=(kind:string)=>`${kind==='debts'?'Utang':'Piutang'} ini dibuat oleh Split Bill. Ubah atau batalkan lewat menu Split Bill.`;
export async function editOpeningRecord(uid:string,kind:'claims'|'receivables'|'debts',id:string,changes:Record<string,unknown>,newAmount:number){
  if(!validAmount(newAmount))throw Error('Nominal harus lebih dari nol.');
  const relationKey=kind==='claims'?'claimId':kind==='receivables'?'receivableId':'debtId';
  const openingType=kind==='claims'?'claim_advance':kind==='receivables'?'receivable_issue':'borrowing';
  const found=await readLocalFirst(uid,['transactions'],query(coll(uid,'transactions'),where(relationKey,'==',id)));const first=found.docs.filter(s=>s.data().type===openingType&&!/\(tambahan\)$/.test(String(s.data().description||''))).sort((a,b)=>String(a.data().date).localeCompare(String(b.data().date)))[0]||found.docs.find(s=>s.data().type===openingType);
  await runTx(database(),async trx=>{const rr=ref(uid,kind,id),snapshot=await trx.get(rr);if(!snapshot.exists())throw Error('Catatan tidak ditemukan.');const old=snapshot.data();if(old.sourceType==='split_bill')throw Error(splitRecord(kind));const txSnap=first?await trx.get(first.ref):null;
    const key=kind==='claims'?'amount':'originalAmount',oldAmount=Number(old[key]),delta=newAmount-oldAmount,remainingKey=kind==='debts'?'outstandingAmount':'remainingAmount';
    const nextRemaining=Number(old[remainingKey])+delta;if(nextRemaining<0)throw Error('Nominal baru lebih kecil daripada pembayaran yang sudah diterima.');
    if(first&&!txSnap?.exists())throw Error('Transaksi pembuka tidak ditemukan. Coba lagi.');
    if(first&&txSnap){const t=txSnap.data() as LedgerTx;const txAmount=Number(t.amount)+delta;for(const [wallet,change] of Object.entries(combineBalanceCacheDeltas({...t,amount:txAmount},t)))trx.update(ref(uid,'wallets',wallet),cacheIncrements(change));if(txAmount<=0)throw Error('Nominal awal tidak bisa sekecil itu karena ada tambahan. Batalkan tambahannya dulu di Riwayat.');trx.update(first.ref,{amount:txAmount,updatedAt:serverTimestamp()});}
    trx.update(rr,{...changes,[key]:newAmount,[remainingKey]:nextRemaining,updatedAt:serverTimestamp()});
  });await syncSnapshot(uid,first?.data().date||'0000-01-01');
}
export async function deleteOpeningRecord(uid:string,kind:'claims'|'receivables'|'debts',id:string){
  const relationKey=kind==='claims'?'claimId':kind==='receivables'?'receivableId':'debtId',openingType=kind==='claims'?'claim_advance':kind==='receivables'?'receivable_issue':'borrowing';
  const found=await readLocalFirst(uid,['transactions'],query(coll(uid,'transactions'),where(relationKey,'==',id)));const openings=found.docs.filter(s=>s.data().type===openingType),opening=openings[0];
  await runTx(database(),async trx=>{const rr=ref(uid,kind,id),snap=await trx.get(rr);if(!snap.exists())return;if(snap.data().sourceType==='split_bill')throw Error(splitRecord(kind));const row=snap.data(),initial=Number(kind==='claims'?row.amount:row.originalAmount),remaining=Number(kind==='debts'?row.outstandingAmount:row.remainingAmount);if(remaining!==initial)throw Error('Catatan yang sudah memiliki pembayaran tidak dapat dihapus. Koreksi transaksi pembayarannya terlebih dahulu.');const snaps=[];for(const o of openings){const t=await trx.get(o.ref);if(!t.exists())throw Error('Transaksi pembuka tidak tersedia.');snaps.push(t);}for(const t of snaps){const tx=hydrate<LedgerTx>(t);for(const [wallet,delta] of Object.entries(balanceCacheDeltas(tx,-1)))trx.update(ref(uid,'wallets',wallet),cacheIncrements(delta));trx.delete(t.ref);}trx.delete(rr);});await noteDeleted(uid,{[kind]:[id],...(openings.length?{transactions:openings.map(o=>o.id)}:{})});await syncSnapshot(uid,opening?.data().date||'0000-01-01');
}
export async function loadAllTransactions(uid:string){if(await whenCurrent(uid,['transactions'])){try{return withoutDeleted((await getDocsFromCache(query(coll(uid,'transactions'),orderBy('date','desc')))).docs.map(d=>hydrate<LedgerTx>(d)))}catch{/* read from the server below */}}const result:LedgerTx[]=[];let cursor:QueryDocumentSnapshot|undefined;while(true){const q=query(coll(uid,'transactions'),orderBy('date','desc'),...(cursor?[startAfter(cursor)]:[]),limit(300));const snap=await getDocs(q);result.push(...snap.docs.map(d=>hydrate<LedgerTx>(d)));if(snap.size<300)break;cursor=snap.docs[snap.docs.length-1];}return withoutDeleted(result);}
export async function mergeCategory(uid:string,from:Category,to:Category){if(from.id===to.id||from.type!==to.type||Boolean(from.parentId)!==Boolean(to.parentId))throw Error('Pilih kategori tujuan dengan jenis dan tingkat yang sama.');
  const affected:{r:DocumentReference;field:'categoryId'|'subcategoryId'|'parentId'}[]=[];
  for(const name of ['transactions','budgets','categories'] as const)for(const field of (name==='categories'?['parentId']:['categoryId','subcategoryId']) as ('categoryId'|'subcategoryId'|'parentId')[]){const snaps=await getDocs(query(coll(uid,name),where(field,'==',from.id)));for(const row of snaps.docs)affected.push({r:row.ref,field});}
  for(let i=0;i<affected.length;i+=10){const batch=writeBatch(database());for(const item of affected.slice(i,i+10))batch.update(item.r,{[item.field]:to.id,updatedAt:serverTimestamp()});await settle(batch.commit());}
  // Budgets that cover several subcategories keep the list in subcategoryIds.
  const swap=(ids:string[]|undefined)=>ids?[...new Set(ids.map(id=>id===from.id?to.id:id))]:ids;
  const multi=await getDocs(query(coll(uid,'budgets'),where('subcategoryIds','array-contains',from.id)));for(let i=0;i<multi.docs.length;i+=300){const batch=writeBatch(database());for(const row of multi.docs.slice(i,i+300))batch.update(row.ref,{subcategoryIds:swap(row.data().subcategoryIds as string[]),updatedAt:serverTimestamp()});await settle(batch.commit());}
  const nested=(await loadAllTransactions(uid)).filter(tx=>tx.transferFeeCategoryId===from.id||tx.splits?.some(line=>line.categoryId===from.id||line.subcategoryId===from.id));
  for(let i=0;i<nested.length;i+=10){const batch=writeBatch(database());for(const tx of nested.slice(i,i+10))batch.update(ref(uid,'transactions',tx.id),{transferFeeCategoryId:tx.transferFeeCategoryId===from.id?to.id:tx.transferFeeCategoryId||null,splits:(tx.splits||[]).map(line=>({...line,categoryId:line.categoryId===from.id?to.id:line.categoryId,subcategoryId:line.subcategoryId===from.id?to.id:line.subcategoryId})),updatedAt:serverTimestamp()});await settle(batch.commit());}
  for(const name of ['plannedTransactions','recurring','drafts','financialNotes'] as const)for(const field of name==='plannedTransactions'?['categoryId','subcategoryId']:['categoryId']){const snaps=await getDocs(query(coll(uid,name),where(field,'==',from.id)));for(let i=0;i<snaps.docs.length;i+=300){const batch=writeBatch(database());for(const row of snaps.docs.slice(i,i+300))batch.update(row.ref,{[field]:to.id,updatedAt:serverTimestamp()});await settle(batch.commit());}}
  const history=await getDocs(coll(uid,'cycleSnapshots'));for(const snap of history.docs){const budgets=snap.data().budgetDefinitions as Budget[]|undefined;if(budgets?.some(b=>b.categoryId===from.id||b.subcategoryId===from.id||b.subcategoryIds?.includes(from.id)))await settle(updateDoc(snap.ref,{budgetDefinitions:budgets.map(b=>({...b,categoryId:b.categoryId===from.id?to.id:b.categoryId,subcategoryId:b.subcategoryId===from.id?to.id:b.subcategoryId,...(b.subcategoryIds?{subcategoryIds:swap(b.subcategoryIds)}:{})})),updatedAt:serverTimestamp()}));}
  // Everything now points at the target, so the merged category is deleted, not kept archived.
  const gone=writeBatch(database());gone.delete(ref(uid,'categories',from.id));await settle(gone.commit());await noteDeleted(uid,{categories:[from.id]});await syncSnapshot(uid,'0000-01-01');return affected.length+nested.length;
}

export async function createDueDrafts(uid:string,recurring:Recurring[],today=new Date().toLocaleDateString('en-CA')){
  for(const schedule of recurring.filter(r=>r.active&&r.nextDate&&r.nextDate<=today)){
    for(let count=0;count<12;count++){
      const advanced=await runTx(database(),async trx=>{
        const sr=ref(uid,'recurring',schedule.id),snapshot=await trx.get(sr);
        if(!snapshot.exists())return false;
        const actual=hydrate<Recurring>(snapshot),due=actual.nextDate;
        if(!actual.active||!due||due>today)return false;
        if(actual.endDate&&due>=actual.endDate){trx.update(sr,{active:false,updatedAt:serverTimestamp()});return false;}
        const pending=actual.pendingChange,changed=Boolean(pending&&due>=pending.from),amount=changed?pending!.amount:actual.amount;
        const next=advanceSchedule(due,actual.frequency,scheduleDay(actual)),mode=actual.mode||'reminder';
        const dr=ref(uid,'drafts',`${schedule.id}_${due}`),existing=await trx.get(dr);
        if(mode!=='reminder'&&!existing.exists())trx.set(dr,{recurringId:schedule.id,plannedDate:due,type:actual.type,amount,walletId:actual.walletId,balanceKind:actual.balanceKind??'personal',destinationBalanceKind:actual.destinationBalanceKind??'personal',destinationWalletId:actual.destinationWalletId||null,categoryId:actual.categoryId||null,name:actual.name,status:'pending',mode,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});
        trx.update(sr,{nextDate:next,...(changed?{amount,pendingChange:null}:{}),updatedAt:serverTimestamp()});return true;
      });
      if(!advanced)break;
    }
  }
}
export async function postAutoDrafts(uid:string,drafts:Draft[]){for(const draft of drafts.filter(d=>d.status==='pending'&&d.mode==='auto')){try{await upsertTransaction(uid,newTx({type:draft.type,amount:draft.amount,date:draft.plannedDate,walletId:draft.walletId,balanceKind:draft.balanceKind,destinationBalanceKind:draft.destinationBalanceKind,destinationWalletId:draft.destinationWalletId,categoryId:draft.categoryId,description:draft.name,draftId:draft.id,recurringTransactionId:draft.recurringId}),undefined,{useCurrentDraft:true});}catch(error){console.error('Transaksi otomatis perlu ditinjau:',error);}}}
/** A skipped draft is deleted for good: its schedule has already moved on, so nothing brings it back. */
export async function dismissDraft(uid:string,id:string){await runTx(database(),async trx=>{const r=ref(uid,'drafts',id),draft=await trx.get(r);if(!draft.exists()||draft.data().status!=='pending')throw Error('Transaksi ini sudah diproses.');trx.delete(r)});await noteDeleted(uid,{drafts:[id]});}

export async function rejectClaim(uid:string,id:string){const r=ref(uid,'claims',id),t=doc(coll(uid,'transactions'));await runTx(database(),async trx=>{const snap=await trx.get(r);if(!snap.exists())throw Error('Klaim tidak ditemukan.');const c=snap.data() as Claim;if(c.remainingAmount<=0)throw Error('Klaim sudah selesai.');const {id:_ignored,...event}=newTx({type:'claim_writeoff',amount:c.remainingAmount,walletId:c.sourceWalletId,balanceKind:c.sourceBalanceKind,claimId:id,description:`Klaim ditolak: ${c.name}`});trx.set(t,{...event,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});trx.update(r,{remainingAmount:0,status:'rejected',updatedAt:serverTimestamp()});});await syncSnapshot(uid,new Date().toLocaleDateString('en-CA'));}

/**
 * Adds starter categories as normal user-owned records. Ids are deterministic and every id
 * is read first, so running this twice (or on two devices at once) never creates duplicates
 * and never overwrites a category the user already has.
 */
export async function seedCategoryTemplates(uid:string,records:import('./category-templates').SeedRecord[]){
  if(!records.length)return 0;
  const version=(await import('./category-templates')).CATEGORY_TEMPLATE_VERSION;
  return runTx(database(),async trx=>{
    const refs=records.map(record=>ref(uid,'categories',record.id));
    const existing=await Promise.all(refs.map(r=>trx.get(r)));
    let created=0;
    records.forEach((record,index)=>{if(existing[index].exists())return;trx.set(refs[index],{...record.data,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});created++;});
    trx.set(userRef(uid),{defaultCategoryTemplateVersion:version,updatedAt:serverTimestamp()},{merge:true});
    return created;
  });
}

/** Settle part of a receivable or debt without moving money in any wallet (e.g. it was paid in cash that was never recorded). */
export async function settleWithoutWallet(uid:string,kind:'receivables'|'debts',id:string,amount:number,date:string,note=''){
  if(!validAmount(amount))throw Error('Nominal harus lebih dari nol.');
  await runTx(database(),async trx=>{const rr=ref(uid,kind,id),snap=await trx.get(rr);if(!snap.exists())throw Error('Catatan tidak ditemukan.');const row=snap.data();
    const key=kind==='debts'?'outstandingAmount':'remainingAmount',remaining=Number(row[key]);if(amount>remaining)throw Error(`Nominal melebihi sisa ${kind==='debts'?'utang':'piutang'} (Rp${remaining.toLocaleString('id-ID')}).`);
    const next=remaining-amount,original=Number(row.originalAmount);const payments=[...((row.manualPayments||[]) as ManualPayment[]),{id:crypto.randomUUID(),amount,date,...(note?{note}:{})}];
    trx.update(rr,{[key]:next,status:kind==='debts'?(next===0?'paid':'open'):(next===0?'paid':next<original?'partial':'open'),manualPayments:payments,updatedAt:serverTimestamp()});});
  await syncSnapshot(uid,date);
}
/**
 * "Perbarui saldo": set what is still owed on a debt or receivable to its real amount (interest or a fine added,
 * a discount given, a mistake corrected). The total owed moves by the same difference, so what was already paid stays
 * the same; no wallet changes. Every update is kept in `balanceUpdates` as history.
 */
export async function updateOwedBalance(uid:string,kind:'receivables'|'debts',id:string,amount:number,date:string,note='',options:{mode?:'add'|'reduce'|'set';walletId?:string;balanceKind?:BalanceKind}={}){
  const mode=options.mode||'set';
  if(!Number.isSafeInteger(amount)||amount<0||(mode!=='set'&&amount===0))throw Error(mode==='set'?'Isi sisa yang benar (Rp0 atau lebih).':'Isi nominal lebih dari nol.');
  const walletId=mode==='add'?options.walletId||'':'';
  await runTx(database(),async trx=>{const rr=ref(uid,kind,id),snap=await trx.get(rr);if(!snap.exists())throw Error('Catatan tidak ditemukan.');const row=snap.data();
    if(row.sourceType==='split_bill')throw Error(splitRecord(kind));
    const key=kind==='debts'?'outstandingAmount':'remainingAmount',current=Number(row[key]);
    const target=mode==='add'?current+amount:mode==='reduce'?current-amount:amount;
    if(target<0)throw Error(`Pengurangan melebihi sisa ${kind==='debts'?'utang':'piutang'} (${'Rp'+current.toLocaleString('id-ID')}).`);
    const delta=target-current;if(!delta)throw Error('Sisanya sudah sama.');
    const original=Number(row.originalAmount)+delta;if(original<=0)throw Error('Total setelah diperbarui harus lebih dari nol.');
    let transactionId='';
    if(walletId){
      // More money lent (piutang: out of the wallet) or borrowed (utang: into the wallet), recorded like the first loan.
      const walletSnap=await trx.get(ref(uid,'wallets',walletId));if(!walletSnap.exists())throw Error('Dompet tidak ditemukan.');
      const type:TxType=kind==='debts'?'borrowing':'receivable_issue';const t=doc(coll(uid,'transactions'));transactionId=t.id;
      const tx=newTx({type,amount,walletId,balanceKind:options.balanceKind,date,...(kind==='debts'?{debtId:id}:{receivableId:id}),description:`${String(kind==='debts'?row.name:row.person)} (tambahan)`,notes:note});
      validateWalletUse(hydrate<Wallet>(walletSnap),walletActions(tx).source);validateWalletBalanceKind(hydrate<Wallet>(walletSnap),options.balanceKind);
      const {id:_t,...payload}=tx;trx.set(t,{...payload,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});
      for(const [wallet,delta] of Object.entries(balanceCacheDeltas(tx)))trx.update(ref(uid,'wallets',wallet),cacheIncrements(delta));
    }
    const history=[...((row.balanceUpdates||[]) as BalanceUpdate[]),{id:crypto.randomUUID(),date,from:current,to:target,mode,...(note?{note}:{}),...(walletId?{walletId,transactionId,balanceKind:options.balanceKind??'personal'}:{}),at:new Date().toISOString()}];
    trx.update(rr,{[key]:target,originalAmount:original,status:kind==='debts'?(target===0?'paid':'open'):(target===0?'paid':target<original?'partial':'open'),balanceUpdates:history,updatedAt:serverTimestamp()});});
  await syncSnapshot(uid,date);
}
/** Undo the most recent "tambah / kurangi / atur sisa", including the wallet movement of an addition. */
export async function undoBalanceUpdate(uid:string,kind:'receivables'|'debts',id:string,updateId:string){
  let date='0000-01-01',removedTx='';
  await runTx(database(),async trx=>{const rr=ref(uid,kind,id),snap=await trx.get(rr);if(!snap.exists())throw Error('Catatan tidak ditemukan.');const row=snap.data();
    const list=(row.balanceUpdates||[]) as BalanceUpdate[];const last=list[list.length-1];if(!last||last.id!==updateId)throw Error('Hanya perubahan terakhir yang bisa dibatalkan.');date=last.date;
    const key=kind==='debts'?'outstandingAmount':'remainingAmount',delta=last.to-last.from,next=Number(row[key])-delta,original=Number(row.originalAmount)-delta;
    if(next<0||original<=0)throw Error('Sudah ada pembayaran setelah perubahan ini. Batalkan pembayarannya dulu.');
    const txSnap=last.transactionId?await trx.get(ref(uid,'transactions',last.transactionId)):null;
    if(txSnap?.exists()){const tx=hydrate<LedgerTx>(txSnap);for(const [wallet,change] of Object.entries(balanceCacheDeltas(tx,-1)))trx.update(ref(uid,'wallets',wallet),cacheIncrements(change));trx.delete(txSnap.ref);removedTx=txSnap.id;}
    trx.update(rr,{[key]:next,originalAmount:original,status:kind==='debts'?(next===0?'paid':'open'):(next===0?'paid':next<original?'partial':'open'),balanceUpdates:list.slice(0,-1),updatedAt:serverTimestamp()});});
  if(removedTx)await noteDeleted(uid,{transactions:[removedTx]});
  await syncSnapshot(uid,date);
}
/** Undo a settlement made without a wallet. */
export async function undoManualPayment(uid:string,kind:'receivables'|'debts',id:string,paymentId:string){
  let date='0000-01-01';
  await runTx(database(),async trx=>{const rr=ref(uid,kind,id),snap=await trx.get(rr);if(!snap.exists())throw Error('Catatan tidak ditemukan.');const row=snap.data();const list=(row.manualPayments||[]) as ManualPayment[];const payment=list.find(p=>p.id===paymentId);if(!payment)return;date=payment.date;
    const key=kind==='debts'?'outstandingAmount':'remainingAmount',next=Number(row[key])+payment.amount,original=Number(row.originalAmount);
    trx.update(rr,{[key]:next,status:kind==='debts'?(next===0?'paid':'open'):(next===0?'paid':next<original?'partial':'open'),manualPayments:list.filter(p=>p.id!==paymentId),updatedAt:serverTimestamp()});});
  await syncSnapshot(uid,date);
}
/** Wish list: create or update one item (money set aside is an earmark, no wallet changes). */
export async function saveWish(uid:string,record:Partial<WishItem>,id?:string){ const r=id?ref(uid,'wishlist',id):doc(coll(uid,'wishlist')); const {id:_i,createdAt:_c,updatedAt:_u,...fields}=record; if(id) await settle(updateDoc(r,{...fields,updatedAt:serverTimestamp()})); else await settle(setDoc(r,{...fields,createdAt:serverTimestamp(),updatedAt:serverTimestamp()})); return r.id; }
export async function deleteWish(uid:string,id:string){ const b=writeBatch(database()); b.delete(ref(uid,'wishlist',id)); await settle(b.commit()); await noteDeleted(uid,{wishlist:[id]}); }
/** Quick switches for how a wallet counts (Uang bebas / Aset bersih) without opening the wallet form.
 * Older wallets get their group written down first, so a switch never moves them to another group. */
export async function updateWalletFlags(uid:string,id:string,changes:Partial<Pick<Wallet,'isReserved'|'isSpendable'|'includeInNetWorth'|'group'>>){await settle(updateDoc(ref(uid,'wallets',id),{...changes,updatedAt:serverTimestamp()}));}
