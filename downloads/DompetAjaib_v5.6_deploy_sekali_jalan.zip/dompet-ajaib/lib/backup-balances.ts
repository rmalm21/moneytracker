import { validateBalanceKind } from './wallet-balances.ts';

type BackupRecord = { id: string; [field: string]: unknown };
type BackupCollections = Record<string, BackupRecord[]>;

/** Merging an older backup must keep allocations already used by retained business transactions. */
export function mergeWalletSplitBalances(incoming: BackupRecord[], existing: BackupRecord[]): BackupRecord[] {
  const current = new Map(existing.map(wallet => [wallet.id, wallet]));
  return incoming.map(wallet => {
    const previous = current.get(wallet.id);
    if (previous?.balanceSplitEnabled !== true || wallet.balanceSplitEnabled === true) return wallet;
    return {
      ...wallet,
      balanceSplitEnabled: true,
      openingBusinessBalance: previous.openingBusinessBalance ?? 0,
      cachedBusinessBalance: previous.cachedBusinessBalance ?? 0,
    };
  });
}

/** Validate split fields before restore deletes or overwrites any existing data.
 * Missing fields belong to older backups and retain the personal-balance default. */
export function validateBackupBalances(data: BackupCollections): void {
  const wallets = new Map(data.wallets.map(wallet => [wallet.id, wallet]));
  for (const wallet of data.wallets) {
    if (wallet.balanceSplitEnabled !== undefined && typeof wallet.balanceSplitEnabled !== 'boolean') {
      throw Error(`Split saldo dompet ${wallet.id} tidak valid.`);
    }
    for (const [businessField, totalField] of [
      ['openingBusinessBalance', 'openingBalance'],
      ['cachedBusinessBalance', 'cachedBalance'],
    ]) {
      const business = wallet[businessField] === undefined ? 0 : wallet[businessField];
      const total = wallet[totalField];
      if (!Number.isSafeInteger(business) || !Number.isSafeInteger(total)
        || !Number.isSafeInteger((total as number) - (business as number))) {
        throw Error(`Saldo Pribadi dan Bisnis dompet ${wallet.id} harus berupa Rupiah bulat yang valid.`);
      }
      if (business !== 0 && wallet.balanceSplitEnabled !== true) {
        throw Error(`Aktifkan split saldo dompet ${wallet.id} untuk menyimpan saldo Bisnis.`);
      }
    }
  }

  const check = (row: BackupRecord, field: string, walletField: string, label: string, usesWallet = true) => {
    const kind = validateBalanceKind(row[field]);
    if (kind !== 'business' || !usesWallet) return;
    const walletId = row[walletField];
    const wallet = typeof walletId === 'string' ? wallets.get(walletId) : undefined;
    if (!wallet || wallet.balanceSplitEnabled !== true) {
      throw Error(`Saldo Bisnis pada ${label} ${row.id} harus merujuk dompet dengan split saldo aktif.`);
    }
  };
  for (const name of ['transactions', 'recurring', 'drafts', 'plannedTransactions']) {
    for (const row of data[name] || []) {
      const shareWithoutWallet = name === 'transactions' && row.type === 'expense'
        && row.walletId === '' && typeof row.splitBillId === 'string' && row.splitBillId !== '';
      check(row, 'balanceKind', 'walletId', name, !shareWithoutWallet);
      check(row, 'destinationBalanceKind', 'destinationWalletId', name,
        row.type === 'transfer' || row.type === 'fund_contribution');
    }
  }
  for (const name of ['claims', 'receivables']) {
    for (const row of data[name] || []) {
      // A Piutang may describe money already owed, with no opening wallet movement.
      check(row, 'sourceBalanceKind', 'sourceWalletId', name,
        name === 'claims' || Boolean(row.sourceWalletId));
    }
  }
  for (const name of ['receivables', 'debts']) {
    for (const row of data[name] || []) {
      if (row.balanceUpdates === undefined) continue;
      if (!Array.isArray(row.balanceUpdates)) throw Error(`Riwayat perubahan ${name} ${row.id} tidak valid.`);
      for (const update of row.balanceUpdates) {
        if (!update || typeof update !== 'object') throw Error(`Riwayat perubahan ${name} ${row.id} tidak valid.`);
        check(update as BackupRecord, 'balanceKind', 'walletId', name);
      }
    }
  }
  for (const row of data.splitBills || []) {
    check(row, 'balanceKind', 'walletId', 'splitBills', row.payer === 'me' && row.status === 'active');
  }
}
