import fs from 'node:fs';
import { pathToFileURL } from 'node:url';

export function cliResult(text) {
  let payload;
  // Some CLI warnings precede the final --json envelope on stdout.
  const clean = text.replace(/\u001b\[[0-9;]*m/g, '');
  const envelopes = [...clean.matchAll(/\{\s*"status"\s*:\s*"(?:success|error)"/g)];
  const start = envelopes.at(-1)?.index;
  try { payload = JSON.parse(start === undefined ? clean : clean.slice(start)); }
  catch { throw Error('Firebase CLI tidak mengembalikan JSON yang valid.'); }
  if (payload.status !== 'success') throw Error('Firebase CLI belum berhasil mengambil konfigurasi project.');
  return payload.result;
}

export function webApps(result) {
  if (!Array.isArray(result)) throw Error('Daftar web app Firebase tidak valid.');
  return result.filter(app => app.platform === 'WEB' && app.appId && app.state !== 'DELETED');
}

export function chooseWebApp(apps, project, site, hostedConfig) {
  if (!apps.length) throw Error('Belum ada web app Firebase pada project ini.');
  if (hostedConfig?.projectId === project) {
    const deployed = apps.find(app => app.appId === hostedConfig.appId);
    if (deployed) return deployed.appId;
  }
  const normalize = value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const matching = apps.find(app => normalize(app.displayName) === normalize(site));
  return (matching || apps[0]).appId;
}

export function productionEnv(result, project, previous = '') {
  const config = result?.sdkConfig;
  if (!config || config.projectId !== project || !config.apiKey || !config.appId) {
    throw Error('Konfigurasi web app tidak lengkap atau bukan dari project money-manage-32467.');
  }
  if (config.projectId.startsWith('demo-')) throw Error('Konfigurasi demo tidak boleh dideploy.');
  const fields = {
    NEXT_PUBLIC_FIREBASE_API_KEY: config.apiKey,
    NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN: config.authDomain || `${project}.firebaseapp.com`,
    NEXT_PUBLIC_FIREBASE_PROJECT_ID: config.projectId,
    NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET: config.storageBucket || '',
    NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID: config.messagingSenderId || '',
    NEXT_PUBLIC_FIREBASE_APP_ID: config.appId,
    NEXT_PUBLIC_FIREBASE_EMULATOR_HOST: '',
  };
  for (const value of Object.values(fields)) {
    if (typeof value !== 'string' || /[\r\n]/.test(value)) throw Error('Nilai konfigurasi Firebase tidak valid.');
  }
  const keys = new Set(Object.keys(fields));
  const retained = previous.split(/\r?\n/).filter(line => {
    const key = line.match(/^\s*(?:export\s+)?([A-Z0-9_]+)\s*=/)?.[1];
    return !keys.has(key);
  });
  if (!/^\s*(?:export\s+)?NEXT_PUBLIC_AUTH_EMAIL_DOMAIN\s*=/m.test(previous)) retained.push('NEXT_PUBLIC_AUTH_EMAIL_DOMAIN=gmail.com');
  return [...retained, ...Object.entries(fields).map(([key, value]) => `${key}=${value}`)].join('\n').trim() + '\n';
}

async function main() {
  const [command, filename, project, target] = process.argv.slice(2);
  const result = cliResult(fs.readFileSync(filename, 'utf8'));
  if (command === 'app-count') {
    console.log(webApps(result).length);
  } else if (command === 'select-app') {
    const apps = webApps(result);
    let hostedConfig;
    if (apps.length > 1) {
      try {
        const response = await fetch(`https://${target}.web.app/__/firebase/init.json`, { signal: AbortSignal.timeout(10_000) });
        if (response.ok) hostedConfig = await response.json();
      } catch { /* An absent/unreachable deployed config does not prevent using this project's web app. */ }
    }
    console.log(chooseWebApp(apps, project, target, hostedConfig));
  } else if (command === 'write-env') {
    const previous = fs.existsSync(target) ? fs.readFileSync(target, 'utf8') : '';
    fs.writeFileSync(target, productionEnv(result, project, previous), { mode: 0o600 });
    fs.chmodSync(target, 0o600);
    console.log(`Konfigurasi produksi ${project} siap; emulator dimatikan.`);
  } else {
    throw Error('Perintah konfigurasi tidak dikenal.');
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main().catch(error => { console.error(error.message); process.exitCode = 1; });
}
