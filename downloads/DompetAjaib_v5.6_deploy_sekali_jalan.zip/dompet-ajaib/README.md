# Dompet Ajaib

Paket **v5.6** memperbaiki menu Lainnya pada kartu Utang/Piutang dan membuat ringkasan pelunasan hanya menghitung catatan aktif. Laporan terbaru ada di [PERBAIKAN_UTANG_PIUTANG.md](PERBAIKAN_UTANG_PIUTANG.md). Perbaikan edit tanggal pembayaran Split Bill dari v5.5 dan split saldo **Pribadi/Bisnis dalam satu dompet** dari v5.4 tetap disertakan. Untuk **deploy sekali jalan**, upload ZIP lalu paste satu blok di [DEPLOY_CLOUD_SHELL.md](DEPLOY_CLOUD_SHELL.md); konfigurasi Firebase diambil otomatis dari akun Cloud Shell dan [README_SPLIT_SALDO.md](README_SPLIT_SALDO.md) untuk penggunaan split saldo. Screenshot aplikasi belum berhasil diambil dalam lingkungan pengerjaan paket ini.

Aplikasi keuangan pribadi multiakun berbasis Next.js, TypeScript, Tailwind CSS, komponen UI berbasis Radix, Recharts, Firebase Authentication, Firestore, dan PWA (tanpa Firebase Storage: foto struk tidak pernah diunggah). Bahasa tampilan Indonesia, mata uang Rupiah.

## Kategori default & dompet awal

- **Pustaka kategori default** (versi template 1): 16 kategori pengeluaran dan 6 kategori pemasukan. Setiap kategori punya subkategori, emoji, dan warna. Subkategori memakai warna kategori utamanya kecuali diubah. Tidak ada kategori “Transfer”, karena transfer antardompet tetap bukan pemasukan atau pengeluaran. Klaim, piutang, dan utang tetap memakai alur transaksinya masing-masing.
- **Onboarding** menawarkan *Gunakan Kategori Default* (disarankan), *Pilih Sendiri*, atau *Mulai dari Kosong*, dan membuat dompet **Tunai** serta **Bank**. Contoh anggaran bersifat opsional.
- **Pengguna lama** tidak pernah ditimpa. Di menu Kategori tersedia **Ambil dari Template**, dan kategori yang serupa ditandai “Sudah ada”. Jika tetap dipilih, muncul pesan “Kategori serupa sudah ada.” dengan pilihan Batal, Lewati yang serupa, atau Tambahkan Tetap. Penyimpanan memakai ID tetap per template sehingga aman dijalankan ulang.
- Kategori default menjadi data biasa milik akun (`users/{uid}/categories`, dengan `templateKey` dan `templateVersion`). Semuanya bisa diganti nama, ikon, dan warna, diurutkan, dipindah, diarsipkan, dan ditambah subkategori.
- **Pemilih ikon**: pustaka emoji berkelompok, pencarian, ikon yang disarankan dari nama, dan ikon yang terakhir dipakai. **Pemilih warna**: 16 lingkaran warna bernama, pilihan “Ikuti kategori utama”, dan “Warna lainnya”.
- **Form transaksi**: pemilih kategori menampilkan kategori utama dulu, lalu subkategorinya, dengan pencarian dan pintasan *Sering dipakai* dari riwayat. Di ponsel tampil sebagai lembar dari bawah. Tidak ada kategorisasi otomatis.
- **Halaman Transaksi**: filter kategori hanya menampilkan kategori utama (sudah mencakup subkategorinya) dan mengikuti jenis transaksi. Ada ringkasan masuk/keluar/selisih, dan transaksi dikelompokkan per hari beserta totalnya.

## Pembaruan tampilan lanjutan

- Istilah dibuat lebih mudah dipahami: **Tujuan dana** (sebelumnya Dana tujuan), **Beranda**, **Periode**, “Catat otomatis”, “Tunggu konfirmasi”, “Samakan saldo”, “Aset bersih”, “Arus kas”, “cadangan”, dan istilah Indonesia lain sebagai pengganti inbox/draft/cache/budget/net worth/backup.
- Beranda: empat kartu angka di atas, **Catat cepat** menjadi satu baris memanjang yang bisa digeser, lalu kartu lain tersusun rapi dalam dua kolom.
- Transaksi (termasuk *Transaksi Terbaru* di Beranda) bisa diklik di bagian mana saja untuk membuka detail.
- Semua tombol teks memiliki bingkai kotak. Kartu yang ditekan lalu digeser akan terangkat dan mengikuti jari/kursor.
- Filter kategori di Transaksi hanya menampilkan kategori yang sesuai dengan jenis transaksi (pengeluaran atau pemasukan), tersusun dari kategori induk ke subkategori.
- Pilihan emoji kategori dan dompet diperbanyak. Ada animasi halus saat berpindah halaman, saat kartu muncul, saat bilah progres terisi, dan saat tombol ditekan.
- Menu Timeline dan Catatan Keuangan dihapus. Pengingat tetap bisa dibuat dari Arus Kas Mendatang dan Kalender Keuangan.

## Perbaikan tampilan & bug (versi repositori)

**Tampilan desktop dan mobile**
- Gaya ditulis ulang dan dirapikan. Semua warna memakai token tema sehingga mode terang/gelap, palet (termasuk Soft Peach) dan warna aksen sendiri tampil konsisten, termasuk tombol, pemberitahuan, label status, menu samping, dan kartu dompet berwarna.
- Kartu angka tidak lagi menempelkan label dengan nominal. Judul kembali tebal, dan ikon di tombol teks (mis. “Edit”) sejajar dengan teksnya.
- Dashboard desktop membuka rincian kartu secara otomatis dan tidak menyisakan ruang kosong. Di ponsel kartu tetap ringkas.
- Di ponsel, semua dialog tampil sebagai *bottom sheet*, tombol “Catat transaksi” di atas diringkas menjadi ikon, input memakai huruf 16px agar iOS tidak memperbesar layar, dan Kalender Keuangan menampilkan grid bulan ringkas.
- Daftar transaksi dibatasi 50 baris dengan tombol “Tampilkan lagi”. Transaksi pada tanggal yang sama diurutkan menurut jam, lalu waktu dicatat.
- Tanggal ditampilkan dalam format Indonesia, status klaim tidak lagi berbahasa Inggris, dan nominal negatif ditulis `-Rp75.000`.

**Bug yang diperbaiki**
- Dana Tujuan kini bisa memakai dompet tabungan/dicadangkan yang tidak dipakai membayar. Sebelumnya pilihan dompet salah memakai aturan “bisa membayar”.
- Dompet penerima dana pinjaman memakai aturan “bisa menerima uang”. Pilihan itu disembunyikan saat mengedit utang karena perubahannya memang tidak diterapkan.
- Mengedit Dana Tujuan tidak lagi menghapus catatan lamanya.
- Menyimpan pengingat tanpa nominal tidak lagi gagal, karena field opsional yang kosong kini dilewati Firestore.
- Laporan yang difilter per kategori hanya menghitung porsi kategori dari transaksi terbagi, sama dengan halaman Analisis.
- Snapshot siklus menghitung dompet lama yang belum punya field `includeInNetWorth`.
- Anggaran yang terlampaui tampil merah, anggaran yang hampir habis tampil kuning, dan anggaran tabungan yang terpenuhi berlabel “Tercapai”.
- Menekan Esc di dropdown hanya menutup dropdown itu, tidak lagi menutup seluruh formulir.
- Menu “Lainnya” tertutup setelah dipilih, saat klik di luar, atau saat Esc ditekan.
- Label dan gaya dropdown kini diterapkan ke tombol yang terlihat, sehingga dropdown status klaim tidak lagi melebar penuh.
- Tanggal gajian, tanggal mulai anggaran, dan ambang peringatan dibatasi ke rentang yang valid.
- Mengedit transaksi lama tidak lagi mengisi jam secara otomatis.
- Kolom kategori di CSV kini terisi untuk transaksi terbagi.
- Kode lama yang tidak dipakai (Dashboard lama, tampilan Dompet/Kategori/Anggaran/Piutang/Rutin/Analisis ganda) dihapus.

## Pembaruan 24 September 2026

- Menu ponsel membuka seluruh fitur melalui tombol **Lainnya**, serta tombol **Tambah** untuk mencatat cepat. Sidebar desktop dapat diringkas.
- Pilihan, tanggal, dan waktu memakai kontrol di dalam aplikasi. Tampilan serta bilah gulir mengikuti tema akun.
- Dashboard, transaksi, analisis, dan laporan mendukung rentang waktu yang sama. Grafik analisis dapat dikelompokkan harian, mingguan, bulanan, atau tahunan tanpa mengubah total transaksi.
- Pengaturan akun menyediakan pilihan zona waktu, dompet awal, tanggal gajian, ambang anggaran, urutan kartu, tema termasuk Soft Peach, mode terang/gelap/sistem, dan warna aksen.
- Pintasan **Catat cepat** dapat diatur nama, nominal, jenis, dompet, kategori, subkategori, ikon, serta urutannya. Siklus setiap anggaran dapat mengikuti gaji, bulan kalender, atau tanggal mulai sendiri.

### Penyempurnaan kontrol keuangan

- **Dompet**: pratinjau saldo ledger/cache dan rekonsiliasi saldo aktual melalui transaksi penyesuaian yang dapat dilacak.
- **Transaksi**: pembagian kategori, biaya transfer yang masuk pengeluaran, pencarian responsif yang tetap mengikuti filter.
- **Siklus gaji**: tutup siklus dan simpan snapshot historis; perbaikan transaksi lama memperbarui laporan, dengan pemulihan manual di Riwayat Siklus.
- **Perencanaan**: inbox transaksi rutin, rencana/komitmen tanpa perubahan saldo aktual, kalender keuangan, arus kas mendatang.
- **Analisis**: Uang Gue Sebenarnya, Mode Realistis per UID, anggaran spent/committed/available, timeline, catatan, aturan kategori, pemeriksaan data.
- Seluruh struktur baru disimpan pada subkoleksi `users/{uid}`; catatan lama tanpa field baru memakai nilai bawaan yang aman. Tidak ada migrasi yang menghapus data.

Untuk pembaruan link percobaan melalui browser tanpa memasang program di laptop, ikuti `PANDUAN_TANPA_INSTAL.md` dalam ZIP terbaru.

## Aktifkan Firebase

1. Di Firebase Console untuk project `money-manage-32467`, aktifkan **Authentication → Sign-in method → Email/Password**. Buat akun pengguna secara manual di **Authentication → Users** (misalnya `rama@gmail.com`). Tidak ada pendaftaran publik.
2. Aktifkan **Cloud Firestore** (Cloud Storage tidak dipakai). Pastikan site Firebase Hosting dengan ID `dompetajaib` tersedia.
3. Di **Authentication → Settings → Authorized domains**, pastikan `dompetajaib.web.app` dan domain pengembangan yang dipakai tersedia.
4. Salin `.env.example` menjadi `.env.local`, lalu isi keenam nilai `NEXT_PUBLIC_FIREBASE_*` dari **Project settings → Your apps → Web app**. Domain login pendek dapat diubah lewat `NEXT_PUBLIC_AUTH_EMAIL_DOMAIN`. Nilai Firebase web config boleh ada dalam bundel frontend; perlindungan data bertumpu pada autentikasi dan security rules.
5. Jalankan:

```bash
npm ci
npm run dev
```

Buka `http://localhost:3000`. Login dapat memakai `rama` untuk akun `rama@gmail.com`; email penuh juga bisa. Pada login pertama, buat dompet atau pilih contoh anggaran secara eksplisit.

## Uji lokal tanpa project Firebase

Aplikasi dapat dijalankan dengan [Firebase Emulator Suite](https://firebase.google.com/docs/emulator-suite) (butuh Java). Isi `.env.local` dengan nilai contoh apa pun (misalnya `NEXT_PUBLIC_FIREBASE_PROJECT_ID=demo-dompet`) dan tambahkan `NEXT_PUBLIC_FIREBASE_EMULATOR_HOST=127.0.0.1`, lalu jalankan `firebase emulators:start --only auth,firestore --project demo-dompet` bersama `npm run dev`. Jangan isi variabel emulator saat build untuk Firebase Hosting.

## Uji dan deploy

```bash
npm test
npm run typecheck
npm run build
npm install -g firebase-tools
firebase login
firebase use money-manage-32467
firebase deploy --only firestore,hosting
```

`next build` menghasilkan direktori `out/` untuk Firebase Hosting. `firebase.json` mengarah ke site `dompetajaib`. **Periksa isi `.env.local` sebelum build**, sebab variabel `NEXT_PUBLIC_*` disisipkan saat build. Deploy aturan Firestore bersama situs.

## Alur penting

- Tiap akun tersimpan di `users/{uid}/...`; Security Rules memeriksa UID dari Firebase Authentication. Pindah akun mengosongkan state dan menghentikan listener akun sebelumnya.
- Dropdown formulir tampil sebagai menu aplikasi; sidebar desktop dapat diringkas dan pilihannya diingat oleh browser. Tombol **Catat cepat** dapat ditambah, diubah, diurutkan, dan dihapus; susunannya tersimpan di profil akun.
- Pengeluaran mengurangi dompet dan anggaran; pemasukan menaikkan dompet; transfer antar dompet tidak dihitung sebagai pemasukan atau pengeluaran.
- Klaim dan piutang yang ditangani sebagai talangan mengurangi kas serta menambah tagihan. Ketika dibayar, kas naik dan tagihan turun. Pelunasan utang menurunkan kas dan kewajiban.
- Edit dan hapus transaksi memperbaiki dampak dompet dengan membalik transaksi lama. Transaksi pembuka klaim/piutang/utang diedit dari catatan induk agar nilai tetap konsisten.
- Dompet memiliki saldo awal serta saldo cache. Tombol **Hitung ulang** membangun ulang saldo dari seluruh ledger.
- Siklus gaji bisa 1–31; tanggal yang tidak ada pada bulan tertentu memakai tanggal terakhir bulan tersebut. Anggaran dapat memakai siklus gaji atau bulan kalender. Rollover dihitung saat siklus baru dibuka.
- Backup JSON dapat digabung atau mengganti data sesudah pratinjau dan konfirmasi. Backup dari UID lain memerlukan persetujuan khusus. CSV transaksi mencakup seluruh riwayat.
- Pengingat rutin dapat membuat draft saat aplikasi dibuka setelah tanggal jatuh tempo. Draft tidak mengubah saldo sebelum pengguna mengonfirmasi.
- Penambahan transaksi mandiri dapat masuk antrean offline Firestore. Edit dan pembayaran yang perlu verifikasi saldo/tagihan memerlukan koneksi.

## Batas pengujian saat ini

Untuk paket deploy sekali jalan v5.6, seluruh 700 kasus tes lokal lolos, termasuk sembilan tes otomasi Cloud Shell, tujuh regresi ringkasan Utang/Piutang, dan sembilan regresi edit pembayaran yang sudah lunas. Typecheck dan build juga lolos. Rincian dan batas pengujian ada di `PERBAIKAN_UTANG_PIUTANG.md` dan `validation/bukti-utang-piutang/`. Status split saldo sebelumnya ada di `VALIDASI_SPLIT_SALDO.md`. Uji browser/emulator, login sungguhan, pergantian akun, aturan akses lintas UID, serta deploy memerlukan konfigurasi dan akses Firebase project.

Grafik riwayat panjang memakai transaksi yang termuat pada layar; halaman Transaksi menyediakan tombol untuk memuat seluruh riwayat saat diperlukan. Proyeksi adalah simulasi berbasis pola dan asumsi pengguna. Riwayat aset bersih historis dan impor berukuran besar yang sepenuhnya atomik belum tersedia.

## Struktur

- `app/` — halaman utama, login, tema dan gaya.
- `components/` — dashboard, formulir, layar keuangan, analisis, pengaturan.
- `lib/accounting.ts` — aturan saldo, siklus, budget dan metrik.
- `lib/firestore.ts` — operasi keuangan atomik, listener, backup.
- `firestore.rules` — isolasi akses menurut UID.
- `public/` — manifest, icon, service worker.
- `tests/` — skenario konsistensi finansial.

Dokumentasi rujukan: [Next.js static export](https://nextjs.org/docs/app/guides/static-exports), [Firebase Hosting](https://firebase.google.com/docs/hosting/quickstart), [Firestore offline](https://firebase.google.com/docs/firestore/manage-data/enable-offline).

## Bantuan Gemini untuk Scan struk (opsional)

Isi `NEXT_PUBLIC_GEMINI_API_KEY` di `.env.local` sebelum `npm run build`. Saat aktif, hanya potongan struk (bukan foto utuh) dikirim ke Gemini (`gemini-3.5-flash-lite`, cadangan `gemini-3.1-flash-lite`) untuk dibaca; pembaca di perangkat tetap berjalan dan dipakai saat Gemini mati, offline, atau penuh. Pengguna bisa mematikannya di layar Scan struk.

Kunci ini ikut terbawa ke kode di browser, jadi **batasi kuncinya** di Google Cloud Console → APIs & Services → Credentials: *Application restrictions* = Websites (domain Hosting aplikasi), *API restrictions* = Generative Language API. Jangan pernah commit kunci ke git.
