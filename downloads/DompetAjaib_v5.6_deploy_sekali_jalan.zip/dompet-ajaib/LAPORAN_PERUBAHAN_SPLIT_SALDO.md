# Laporan perubahan split saldo v5.4

**Paket deploy sekali jalan:** upload ZIP `DompetAjaib_v5.6_deploy_sekali_jalan.zip` lalu paste satu blok pada [DEPLOY_CLOUD_SHELL.md](DEPLOY_CLOUD_SHELL.md). Konfigurasi Firebase diambil otomatis dari akun Cloud Shell. Sembilan tes otomasi dan seluruh 700 kasus tes lolos; bukti simulasi ada di `validation/bukti-deploy-sekali-jalan/`. Aplikasi tetap v5.6.

**Pembaruan v5.6:** menu Lainnya pada kartu Utang/Piutang diperbaiki untuk mode Lengkap dan Ringkas; ringkasan hanya menghitung catatan aktif. Seluruh 691 kasus tes, typecheck, dan build lolos. Rincian serta batas pemeriksaan visual ada di [PERBAIKAN_UTANG_PIUTANG.md](PERBAIKAN_UTANG_PIUTANG.md). Bukti pemeriksaan ada di `validation/bukti-utang-piutang/`.

**Pembaruan v5.5:** edit tanggal pembayaran Split Bill yang sudah lunas diperbaiki. Catatan asal tetap muncul dengan label Lunas; pembayaran utang dan klaim mendapat perbaikan yang sama. Semua 684 kasus tes, typecheck, dan build lolos. Rincian hasil dan cara memeriksa ada di [PERBAIKAN_EDIT_SPLIT_BILL.md](PERBAIKAN_EDIT_SPLIT_BILL.md). Laporan berikut mencatat fitur split saldo v5.4 yang tetap disertakan.

Fitur yang diminta: **satu dompet mempunyai saldo Pribadi dan Bisnis**. Total dompet adalah penjumlahan keduanya. Dompet tidak digandakan.

## Yang sudah berhasil diuji per poin

1. **Pembagian saldo awal.** Total Rp1.000.000 dengan bagian Bisnis Rp400.000 menghasilkan Pribadi Rp600.000. Diuji lewat fungsi perhitungan aplikasi.
2. **Pemasukan/pengeluaran sesuai bagian saldo.** Pemasukan Bisnis Rp200.000 dan pengeluaran Pribadi Rp100.000 menghasilkan total Rp1.100.000, Pribadi Rp500.000, Bisnis Rp600.000. Diuji lewat fungsi aplikasi.
3. **Transfer antar bagian dalam satu dompet.** Pindah Rp100.000 dari Pribadi ke Bisnis menghasilkan Pribadi Rp400.000 dan Bisnis Rp700.000; total tetap Rp1.100.000. Perhitungan biaya transfer, bila ada, mengikuti bagian asal dan juga diuji.
4. **Perhitungan edit/hapus.** Pembalikan pengaruh transaksi lama dan penerapan transaksi baru pada total serta bagian Bisnis diuji lewat fungsi. Ini belum membuktikan operasi penyimpanan Firestore ketika beberapa perangkat menulis bersamaan.
5. **Data lama dan backup.** Transaksi tanpa informasi split memakai Pribadi. Pembagian saldo pada backup, penggabungan backup, dan validasi nilainya diuji lewat fungsi.
6. **Filter bagian saldo.** Fungsi pencocokan transaksi dengan Pribadi/Bisnis, termasuk kedua sisi transfer, diuji. Render tabel/grafik/CSV di browser belum diverifikasi.
7. **Rencana Bisnis di Catat Otomatis.** Parser mempertahankan bagian Bisnis dari rencana, termasuk ketika dompet yang sama disebutkan kembali. Pengujian fungsi parser lolos.
8. **Typecheck dan build.** `npm run typecheck` dan `npm run build` lolos pada 6 Oktober 2026. Build mode produksi menghasilkan ekspor statis Next.js dan service worker `app-5.4`, memakai konfigurasi Firebase demo lokal. Build ini belum dideploy ke akun produksi.

Hasil suite terakhir, 6 Oktober 2026: **675 kasus, 675 lolos, 0 gagal**. `npm test` juga lolos untuk **50 berkas tes**, yaitu kumpulan tes yang sama. Dependensi NLP kini tersedia sehingga tes yang sebelumnya terhenti berhasil dijalankan. Ada tes yang menjalankan fungsi dan ada tes yang hanya memeriksa pola kode; enam tes penghapusan otomatis termasuk pemeriksaan pola kode. Kelulusan suite ini belum menggantikan validasi penyimpanan dan interaksi melalui browser.

Bukti mentah: [hasil-tes-lokal.tap](validation/bukti-lokal/hasil-tes-lokal.tap), [npm-test.txt](validation/bukti-lokal/npm-test.txt), dan [build.txt](validation/bukti-lokal/build.txt). Contoh input dan hasil perhitungan fungsi asli tersedia di [helper-walkthrough.json](validation/helper-walkthrough.json).

## Bagian tampilan yang diubah

| Bagian app | Perubahan yang ada dalam kode | Status tampilan |
|---|---|---|
| Tambah/ubah dompet | Toggle split, saldo awal total, saldo awal Bisnis, Pribadi turunan | Belum dicapture |
| Kartu/detail dompet | Total, Pribadi, dan Bisnis pada dompet yang sama | Belum dicapture |
| Beranda/ringkasan dompet | Rincian kedua bagian saldo | Belum dicapture |
| Form pemasukan/pengeluaran | Pilihan saldo Pribadi/Bisnis setelah memilih dompet split | Belum dicapture |
| Transfer/Pindah saldo | Saldo asal dan tujuan; boleh memakai dompet yang sama untuk bagian berbeda | Belum dicapture |
| Transaksi dan laporan | Filter Semua saldo/Pribadi/Bisnis; kolom saldo pada ekspor CSV | Belum dicapture |
| Form keuangan terkait | Pilihan saldo untuk scan, catat otomatis, rutin/rencana, klaim, utang/piutang, dan Split Bill | Belum diuji lewat browser |
| Pengaturan/mobile | Versi 5.4, penyesuaian ruang tindakan/rincian saldo | Belum dicapture |

## Status screenshot aplikasi

**Capture aplikasi sedang diselesaikan.** Dependensi aplikasi, typecheck, seluruh tes, dan build sudah selesai; pemasangan tool Firebase untuk capture masih menunggu izin jaringan. Hasil dan screenshot hanya akan dicantumkan sesudah pengujian aplikasi benar-benar berjalan. Gambar laporan PDF sebelumnya bukan screenshot app.

`CAPTURE_CLOUD_SHELL.sh` disiapkan agar Cloud Shell menjalankan app dengan Firebase emulator lalu mengambil screenshot langsung dari UI. Harness menargetkan 14 gambar: form dompet, kartu/detail, transaksi Bisnis/Pribadi, transfer internal, saldo sesudah transaksi, filter riwayat/laporan, hitung ulang, ringkasan, Beranda, dan mobile. Gambar hanya dibuat jika halaman tersebut benar-benar berhasil dibuka; kelulusan dicatat terpisah dari kondisi form yang belum disimpan. Script ini belum diuji end-to-end di lingkungan pengerjaan.

Hasil capture tersimpan di `validation/artifacts/`, termasuk galeri `screenshots.html`, manifest `screenshots.json`, hasil per poin `LAPORAN_CAPTURE.md`, dan log. Bundle unduhan: **`CAPTURE_DompetAjaib_v5.4.zip`**. Jika capture gagal, laporan akan menuliskan kegagalan dan jumlah gambar yang benar-benar ada.

## Yang masih perlu diselesaikan sebelum menganggap app lolos penuh

- Jalankan emulator/browser untuk membuktikan penyimpanan, aturan Firestore, edit/hapus, reload, dan tampilan.
- Uji perubahan bersamaan pada cache, penghapusan, draft rutin, dan restore banyak dompet di Firebase.
- Gunakan konfigurasi Firebase produksi saat akan deploy Firestore serta Hosting lewat `DEPLOY_CLOUD_SHELL.md`; build yang diverifikasi pada pemeriksaan ini menggunakan konfigurasi demo.

Deployment ke akun Google atau data produksi belum dilakukan selama pengerjaan.
