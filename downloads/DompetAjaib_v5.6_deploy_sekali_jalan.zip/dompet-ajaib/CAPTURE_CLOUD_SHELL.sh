#!/usr/bin/env bash
# Capture app asli dengan Firebase demo lokal. Tidak menjalankan deployment.
set -euo pipefail
cd "$(dirname "$0")"

ARTIFACT_DIR="$PWD/validation/artifacts"
TOOL_DIR="${DOMPET_CAPTURE_TOOL_DIR:-/tmp/dompet-v54-validation-tools}"
if [[ -d "$ARTIFACT_DIR" ]]; then
  mv "$ARTIFACT_DIR" "${ARTIFACT_DIR}-$(date +%Y%m%d-%H%M%S)-$$"
fi
if [[ -f CAPTURE_DompetAjaib_v5.4.zip ]]; then
  mv CAPTURE_DompetAjaib_v5.4.zip "CAPTURE_DompetAjaib_v5.4-previous-$(date +%Y%m%d-%H%M%S)-$$.zip"
fi
mkdir -p "$ARTIFACT_DIR"
typecheck_status=not-run
test_status=not-run
browser_status=not-run

finish_capture() {
  local status="$1"
  trap - EXIT
  if command -v node >/dev/null 2>&1 && command -v python3 >/dev/null 2>&1; then
    node validation/package-capture-report.mjs \
      "$typecheck_status" "$test_status" "$browser_status" "$status" || true
  fi
  printf '\nHasil dan log: %s\n' "$ARTIFACT_DIR"
  if [[ -f CAPTURE_DompetAjaib_v5.4.zip ]]; then
    printf 'Unduh dengan: cloudshell download CAPTURE_DompetAjaib_v5.4.zip\n'
  fi
  exit "$status"
}
trap 'finish_capture "$?"' EXIT

cat <<'TEXT'
DOMPET AJAIB v5.4 — SCREENSHOT APP DAN LAPORAN OTOMATIS

App dijalankan dengan Auth/Firestore emulator project demo-split.
Tidak memakai akun Firebase asli, tidak mengubah .env.local, dan tidak deploy.
Script mengunduh dependency app, Firebase CLI, dan Chromium untuk pengujian.
TEXT

if ! command -v node >/dev/null 2>&1 || [[ "$(node -p 'Number(process.versions.node.split(".")[0])')" -lt 24 ]]; then
  printf '\nPakai Node 24 terlebih dahulu: nvm install 24 && nvm use 24\n' >&2
  exit 1
fi
if ! command -v java >/dev/null 2>&1; then
  printf '\nJava 21 belum tersedia. Jalankan: sudo apt-get update && sudo apt-get install -y openjdk-21-jre-headless\n' >&2
  exit 1
fi
java_major="$(java -version 2>&1 | awk -F'"' 'NR==1 {split($2,v,"."); print v[1]}')"
if [[ ! "$java_major" =~ ^[0-9]+$ ]] || [[ "$java_major" -lt 21 ]]; then
  printf '\nFirebase emulator memerlukan Java 21. Versi Java yang aktif:\n' >&2
  java -version >&2
  printf 'Pasang Java 21 dan aktifkan lewat: sudo update-alternatives --config java\n' >&2
  exit 1
fi

printf '\n1/5 Memasang dependency aplikasi...\n'
npm ci --no-audit --no-fund 2>&1 | tee "$ARTIFACT_DIR/install-app.log"
npm run predev 2>&1 | tee "$ARTIFACT_DIR/copy-ocr.log"

printf '\n2/5 Memasang tool capture terpisah...\n'
npm install --prefix "$TOOL_DIR" --no-save --package-lock=false --no-audit --no-fund \
  firebase-tools playwright 2>&1 | tee "$ARTIFACT_DIR/install-tools.log"
"$TOOL_DIR/node_modules/.bin/playwright" install --with-deps chromium \
  2>&1 | tee "$ARTIFACT_DIR/install-browser.log"

printf '\n3/5 Memeriksa tipe dan menjalankan tes...\n'
if npm run typecheck > "$ARTIFACT_DIR/typecheck.log" 2>&1; then
  typecheck_status=passed
else
  typecheck_status=failed
  printf 'Typecheck gagal; rincian disimpan. Capture tetap dicoba.\n'
fi
if node --test --test-isolation=none --test-reporter=tap tests/*.test.mjs \
    > "$ARTIFACT_DIR/unit-tests.tap" 2>&1; then
  test_status=passed
else
  test_status=failed
  printf 'Ada tes gagal; rincian disimpan. Capture tetap dicoba.\n'
fi

printf '\n4/5 Menjalankan app demo dan mengambil screenshot UI...\n'
export PLAYWRIGHT_PACKAGE="$TOOL_DIR/node_modules/playwright"
export FIREBASE_CLI="$TOOL_DIR/node_modules/.bin/firebase"
export CHROMIUM_PATH
CHROMIUM_PATH="$(node - "$PLAYWRIGHT_PACKAGE" <<'NODE'
const playwright = require(process.argv[2]);
process.stdout.write(playwright.chromium.executablePath());
NODE
)"
if node validation/run-local-validation.mjs 2>&1 | tee "$ARTIFACT_DIR/capture.log"; then
  browser_status=passed
else
  browser_status=failed
fi

printf '\n5/5 Mengemas screenshot, laporan per poin, dan log...\n'
if [[ "$typecheck_status" != passed || "$test_status" != passed || "$browser_status" != passed ]]; then
  exit 1
fi
