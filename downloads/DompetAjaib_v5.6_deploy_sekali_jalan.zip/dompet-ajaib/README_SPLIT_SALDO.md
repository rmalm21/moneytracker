# Split saldo Pribadi & Bisnis

Satu dompet atau rekening bisa mempunyai dua bagian saldo: **Pribadi** dan **Bisnis**. Dompet tetap satu, dengan saldo total yang merupakan penjumlahan kedua bagian. Nomor rekening, pengaturan dompet, dan riwayatnya tetap terkait dengan dompet yang sama.

## Mengaktifkan

1. Buka **Dompet & rekening**, lalu tambah dompet atau pilih **Ubah** pada dompet yang sudah ada.
2. Aktifkan **Pisahkan saldo pribadi & bisnis**.
3. Isi **Saldo awal total**, lalu bagian **Saldo awal bisnis**. Saldo awal pribadi adalah total dikurangi bagian bisnis.
4. Simpan. Kartu, daftar ringkas, detail dompet, dan widget Saldo Dompet menampilkan total beserta kedua bagian saldo.

Contoh saldo awal total Rp1.000.000 dan saldo awal bisnis Rp400.000 menghasilkan Pribadi Rp600.000 dan Bisnis Rp400.000.

Saldo awal adalah titik awal perhitungan riwayat. Untuk membagi saldo dompet lama saat ini, pertahankan saldo awal dan gunakan **Pindah saldo** setelah mengaktifkan split. Pembagian yang sudah aktif dipertahankan agar riwayat kedua bagian tetap tersimpan.

## Transaksi dan pindah saldo

Setelah memilih dompet dengan split aktif, pilih bagian saldo yang dipakai. Pemasukan menambah bagian yang dipilih; pengeluaran menguranginya. Jalur pencatatan lain juga membawa pilihan saldo saat tersedia, termasuk scan struk, catat otomatis, klaim, pinjaman, utang/piutang, jadwal rutin, rencana, dan Split Bill.

Pada transfer, pilih saldo asal dan tujuan. Dompet asal dan tujuan boleh sama apabila bagian saldonya berbeda. Tombol **Pindah saldo** di detail dompet membuka transfer Pribadi ke Bisnis; arah tersebut dapat diganti di formulir.

Contoh Pribadi Rp600.000 dan Bisnis Rp400.000: pindah Rp100.000 dari Pribadi ke Bisnis menghasilkan Pribadi Rp500.000 dan Bisnis Rp500.000. Total tetap Rp1.000.000. Pemindahan ini bukan pemasukan atau pengeluaran. Biaya admin pada transfer keluar mengikuti bagian saldo asal dan tetap dihitung sebagai pengeluaran.

Mengubah atau menghapus transaksi menghitung kembali pengaruh transaksi tersebut pada bagian saldo asal dan tujuan. **Hitung ulang saldo** membangun ulang total dan bagian saldo dari saldo awal serta seluruh ledger. **Cocokkan saldo** menyediakan pilihan bagian saldo untuk penyesuaian.

## Riwayat, laporan, dan data lama

- Transaksi lama yang tidak mempunyai pilihan bagian saldo dianggap memakai **Pribadi**. Mengaktifkan split tidak mengubah riwayat lama menjadi transaksi bisnis.
- Filter **Saldo** pada Transaksi, Laporan keuangan, Analisis, dan Laporan tahunan menyediakan Semua saldo, Pribadi, dan Bisnis. Transfer antar dua bagian muncul pada kedua filter; laporan menghitung biaya admin hanya pada saldo asal.
- Filter saldo dapat digabungkan dengan filter dompet pada riwayat dan laporan per periode. Kolom CSV **Saldo asal** dan **Saldo tujuan** mempertahankan informasi pembagian saat diekspor.
- Total aset, saldo total dompet, serta kantong tetap menggunakan total dompet sehingga saldo tidak dihitung dua kali. Ringkasan posisi keuangan dan anggaran berjalan tetap mengikuti seluruh data seperti sebelumnya.
- **Bunga saldo otomatis** tetap dihitung dari saldo total dompet dan dikreditkan ke saldo Pribadi. Setelahnya bunga dapat dialokasikan ke Bisnis memakai Pindah saldo.
- Backup dan sinkronisasi menyimpan pilihan saldo bersama dompet serta transaksi. Dompet tanpa split tetap memakai alur pencatatan sebelumnya.

## Verifikasi untuk pengembang

Jalankan `npm run typecheck`, `npm test`, dan `npm run build` setelah memasang dependensi proyek. Pengujian split saldo perlu mencakup kompatibilitas transaksi lama, alokasi saldo awal, pemasukan/pengeluaran tiap bagian, transfer dalam dompet yang sama, transfer antar dompet, biaya admin, edit/hapus transaksi, perhitungan ulang cache, dan filter kedua endpoint transfer.

Pemeriksaan UI: buat dompet dengan total Rp1.000.000 dan bisnis Rp400.000, catat pemasukan bisnis serta pengeluaran pribadi, pindahkan saldo, lalu periksa detail dompet, widget, riwayat, laporan, dan CSV. Total dompet harus selalu sama dengan Pribadi ditambah Bisnis.
