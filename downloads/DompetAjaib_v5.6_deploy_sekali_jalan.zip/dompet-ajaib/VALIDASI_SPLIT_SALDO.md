# Status validasi split saldo

**Paket deploy sekali jalan:** upload ZIP `DompetAjaib_v5.6_deploy_sekali_jalan.zip` lalu paste satu blok pada [DEPLOY_CLOUD_SHELL.md](DEPLOY_CLOUD_SHELL.md). Konfigurasi Firebase diambil otomatis dari akun Cloud Shell. Sembilan tes otomasi dan seluruh 700 kasus tes lolos; bukti simulasi ada di `validation/bukti-deploy-sekali-jalan/`. Aplikasi tetap v5.6.

**Pembaruan v5.6:** menu Lainnya pada kartu Utang/Piutang diperbaiki untuk mode Lengkap dan Ringkas; ringkasan hanya menghitung catatan aktif. Seluruh 691 kasus tes, typecheck, dan build lolos. Rincian serta batas pemeriksaan visual ada di [PERBAIKAN_UTANG_PIUTANG.md](PERBAIKAN_UTANG_PIUTANG.md). Bukti pemeriksaan ada di `validation/bukti-utang-piutang/`.

**Pembaruan v5.5:** seluruh 684 kasus tes, typecheck, dan build lolos, termasuk sembilan regresi untuk edit pembayaran yang sudah lunas. Laporan terbaru: [PERBAIKAN_EDIT_SPLIT_BILL.md](PERBAIKAN_EDIT_SPLIT_BILL.md). Bukti pemeriksaan v5.5 ada di `validation/bukti-edit-split-bill/`. Bagian di bawah mencatat validasi split saldo v5.4.

Paket ini berisi kode sumber Dompet Ajaib dengan saldo Pribadi dan Bisnis dalam satu dompet. Panduan fitur ada di [README_SPLIT_SALDO.md](README_SPLIT_SALDO.md).

## Pemeriksaan yang selesai

675 kasus pengujian lolos pada pemeriksaan 6 Oktober 2026, tanpa kegagalan. Dependensi aplikasi sudah berhasil dipasang. Pemeriksaan mencakup perhitungan saldo, transfer dalam satu dompet dan antar dompet, biaya admin, edit/hapus, rekonstruksi ledger, kompatibilitas dan penggabungan backup, filter saldo, serta regresi fitur keuangan yang sudah ada. Rencana transaksi bisnis juga mempertahankan bagian saldo ketika dicatat melalui Catat Otomatis, termasuk saat dompetnya disebutkan kembali.

Perintah yang digunakan: `node --test --test-isolation=none tests/*.test.mjs` (Node 24). Hasil lengkap: **675 kasus, 675 lolos, 0 gagal, 0 dilewati**. Perintah resmi `npm test` juga lolos: **50 berkas tes, 50 lolos, 0 gagal**. Keduanya menjalankan kumpulan tes yang sama; angka 50 bukan tambahan 50 kasus.

**`npm run typecheck` lolos. `npm run build` juga lolos**, menghasilkan ekspor statis Next.js dan service worker dengan cache `app-5.4`. Build dijalankan dalam mode produksi dengan konfigurasi Firebase demo lokal; ini membuktikan aplikasi dapat dibangun, bukan deployment ke akun produksi. Log build tersedia di [validation/bukti-lokal/build.txt](validation/bukti-lokal/build.txt).

Bukti hasil tes lengkap tersedia di [validation/bukti-lokal/hasil-tes-lokal.tap](validation/bukti-lokal/hasil-tes-lokal.tap) dan [validation/bukti-lokal/npm-test.txt](validation/bukti-lokal/npm-test.txt). Pemeriksaan sintaks sebelumnya mencakup 215 berkas TypeScript/JSX; typecheck dan build di atas sekarang juga telah selesai.

Perbaikan tambahan dalam paket terbaru:

- Hitung ulang dan perbaikan cache memeriksa apakah dompet berubah selama ledger dibaca, agar tidak menimpa transaksi yang masuk bersamaan.
- Penghapusan online menggunakan transaksi Firestore agar penghapusan bersamaan tidak membalik saldo dua kali.
- Draft rutin dan posting otomatis menggunakan pilihan saldo dari jadwal/draft terbaru saat commit.
- Restore dan penggabungan kategori membatasi batch transaksi untuk memenuhi batas pembacaan aturan Firestore ketika memakai banyak dompet bisnis.
- Perubahan bagian saldo pada pengeluaran yang dikelola Split Bill dilakukan melalui Split Bill.
- Versi aplikasi di Pengaturan menjadi 5.4; tampilan bagian saldo dan tombol tindakan dompet disesuaikan untuk layar sempit.

## Pemeriksaan yang belum selesai

**Pengujian browser dan Firebase lokal belum selesai.** Typecheck, seluruh tes, dan build sudah lolos. Hambatan pemasangan dependensi aplikasi pada pemeriksaan sebelumnya sudah teratasi; tes NLP yang sebelumnya terhenti kini termasuk dalam 675 kasus yang lolos. Tool Firebase untuk capture masih menunggu pemasangan; belum ada klaim kelulusan UI atau screenshot app pada pemeriksaan ini.

Paket belum dideploy atau terhubung ke data akun sungguhan selama pengerjaan. Perintah verifikasi aplikasi:

```bash
npm ci
npm run typecheck
npm test
npm run build
```

Harness Firebase demo dan browser sudah disiapkan; hasil akhirnya masih menunggu pengujian. Ikuti [validation/README.md](validation/README.md) untuk menjalankan pengujian UI dan aturan Firestore dengan emulator lokal. Harness mencakup split saldo, transfer dengan biaya, edit/hapus, migrasi dompet lama, filter, perbaikan cache, reload, serta tampilan desktop/mobile.

Paket terbaru juga menyertakan [LAPORAN_PERUBAHAN_SPLIT_SALDO.md](LAPORAN_PERUBAHAN_SPLIT_SALDO.md), [DEPLOY_CLOUD_SHELL.md](DEPLOY_CLOUD_SHELL.md), dan `CAPTURE_CLOUD_SHELL.sh`. Script capture menargetkan screenshot UI app dengan data demo, kemudian mengemas laporan per poin dan log. Bukti capture akan dicatat setelah gambar dan hasil pengujian benar-benar tersedia.

Deploy aturan Firestore dari paket ini bersama aplikasi, sesuai panduan README utama. Data lama tanpa informasi split tetap dibaca sebagai saldo Pribadi.
