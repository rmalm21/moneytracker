# Perbaikan edit pembayaran Split Bill — v5.5

Keluhan: pembayaran piutang Rp21.142 sudah melunasi Split Bill. Saat pengguna membuka pembayaran tersebut di Transaksi untuk mengganti tanggal, kolom Piutang menampilkan “Pilih opsi” dan tombol Simpan terhalang.

Penyebabnya ada pada form: daftar pilihan hanya memuat catatan dengan sisa tagihan lebih dari nol. Catatan yang sudah lunas tetap ada di data, tetapi hilang dari pilihan, termasuk catatan asal transaksi yang sedang diedit.

## Yang diperbaiki

1. **Piutang asal tetap dipilih ketika pembayaran diedit**, termasuk piutang Split Bill yang sudah lunas. Pilihan tersebut berlabel **Lunas**.
2. **Tanggal dan informasi pembayaran dapat dikoreksi** tanpa memilih piutang lain atau membuat pembayaran baru. Untuk perubahan tanggal saja, piutang tetap lunas dan saldo dompet tetap sama.
3. **Pembayaran utang dan pencairan klaim** mendapat perbaikan yang sama untuk catatan asal yang sudah lunas.
4. **Pembayaran baru tetap hanya menawarkan catatan yang belum lunas.** Catatan lunas lainnya tidak ditambahkan ke daftar pilihan.
5. **Versi menjadi 5.5**, termasuk nama cache service worker ketika dibangun, agar browser/PWA memuat pembaruan.

Tidak diperlukan migrasi data. Tidak perlu menghapus pembayaran atau membuat piutang pengganti. Fitur saldo Pribadi/Bisnis dari v5.4 tetap disertakan.

## Hasil pemeriksaan

Suite lengkap: **684 kasus, 684 lolos, 0 gagal, 0 dilewati**. **Typecheck dan build lolos**; service worker hasil build memakai cache `app-5.5`. Build memakai konfigurasi Firebase demo dan tidak dideploy.

Sembilan regresi baru pada `tests/payment-edit.test.mjs` menjalankan form, dropdown, dan fungsi penyimpanan aplikasi yang asli:

- Tiga pemeriksaan mempertahankan pilihan catatan asal yang lunas untuk piutang, utang, dan klaim.
- Tiga pemeriksaan memastikan pembayaran baru, termasuk preset, tidak menawarkan catatan lunas.
- Kasus Rp21.142: mengganti tanggal ke kemarin melalui callback form berhasil menyimpan ke transaksi yang sama. Hubungan piutang dan Split Bill tetap ada, status Split Bill tetap Lunas, serta saldo total/Bisnis Mandiri tetap sama. Pembaruan laporan dijadwalkan dari tanggal koreksi.
- Nominal yang melebihi tagihan ditolak tanpa perubahan tersimpan.
- Pengurangan nominal pembayaran menghasilkan sisa piutang yang benar dan mengurangi saldo hanya sebesar selisihnya.

Pengujian komponen merender dropdown asli dan menjalankan callback form dengan state hook simulasi; transport Firestore menggunakan penyimpanan dalam memori. Ini bukan pengujian browser, Firebase Emulator, atau data produksi. Log mentah ada di `validation/bukti-edit-split-bill/`.

## Cara menerapkan dan memeriksa

Ikuti [DEPLOY_CLOUD_SHELL.md](DEPLOY_CLOUD_SHELL.md), yang sudah memakai ZIP v5.5. Konfigurasi Firebase produksi harus diisi sebelum build. ZIP berisi sumber aplikasi dan tidak memuat konfigurasi akun, dependensi, atau build demo.

Sesudah deploy:

1. Buka aplikasi, muat ulang, lalu pastikan Pengaturan menampilkan **5.5**.
2. Buka **Transaksi**, cari **Piutang dibayar** yang melunasi Split Bill, lalu pilih **Edit**.
3. Kolom **Piutang** harus sudah terisi nama peserta dengan label **Lunas**.
4. Ganti **Tanggal** ke kemarin, lalu **Simpan**.
5. Periksa tanggal transaksi, status Lunas di Split Bill, dan saldo dompet. Untuk perubahan tanggal saja, nominal dan saldo harus tetap sama.

Paket ini belum dideploy ke situs live selama pengerjaan.
