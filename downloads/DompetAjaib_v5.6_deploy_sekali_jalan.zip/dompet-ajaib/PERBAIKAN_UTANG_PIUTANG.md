# Perbaikan Utang dan Piutang — v5.6

## 1. Menu Lainnya pada kartu

Kartu kaca membentuk lapisan tampilan tersendiri. Menaikkan lapisan dropdown saja tidak cukup: kartu berikutnya tetap bisa menutupinya. Aturan CSS sekarang menaikkan kartu yang memiliki menu Lainnya terbuka ke atas kartu lain.

Pada mode **Ringkas**, pembungkus kartu ikut dinaikkan dan mengizinkan menu keluar dari batas kartu selama menu terbuka. Ketika menu ditutup, pemotongan tepi kartu kembali seperti semula. Perubahan berlaku pada komponen kartu yang dipakai Utang dan Piutang, serta kartu kaca lain yang memakai menu yang sama.

## 2. Ringkasan hanya menghitung catatan aktif

- **Utang:** sisa utang, nominal awal pada “Sudah dibayar … dari …”, persentase pelunasan, dan cicilan bulanan dihitung dari utang dengan sisa lebih dari nol.
- **Piutang:** sisa piutang, nominal awal pada “Sudah kembali … dari …”, persentase pengembalian, jumlah orang, dan jumlah catatan dihitung dari piutang dengan sisa lebih dari nol. Jumlah catatan diberi label **catatan aktif**.
- Saat satu catatan lunas, nominal awal dan pembayaran catatan tersebut keluar dari ringkasan aktif. Jika semuanya sudah lunas, ringkasan menunjukkan **Rp0** tanpa progres pembayaran historis.
- Catatan yang sudah lunas dan riwayatnya tetap tersedia di **Arsip**. Tidak diperlukan migrasi data.

Contoh utang: catatan aktif berjumlah awal Rp1.500.000, sisa Rp900.000, dan terbayar Rp600.000. Adanya utang lama Rp99.000.000 yang sudah lunas tidak mengubah ringkasan: **Sudah dibayar Rp600.000 dari Rp1.500.000**, progres **40%**.

Paket v5.6 tetap memuat split saldo Pribadi/Bisnis dan perbaikan edit tanggal pembayaran Split Bill dari v5.5.

## Pemeriksaan

Tujuh tes regresi baru pada `tests/owed-summary.test.mjs` merender halaman Utang/Piutang dan komponen ringkasan asli dengan data uji. Kontrol yang tidak terkait dan langganan data disimulasikan. Pengujian mencakup:

1. Penambahan catatan lunas tidak mengubah ringkasan aktif Utang.
2. Semua utang lunas menghasilkan Rp0 tanpa progres historis.
3. Pelunasan satu utang langsung mengeluarkannya dari nominal awal dan pembayaran ringkasan.
4. Penambahan catatan lunas tidak mengubah ringkasan aktif Piutang.
5. Semua piutang lunas menghasilkan Rp0 tanpa progres historis.
6. Pelunasan satu piutang langsung mengeluarkannya dari ringkasan.
7. Jumlah orang dan catatan piutang hanya memakai catatan aktif, termasuk beberapa catatan milik orang yang sama.

Hasil suite lengkap: **691 kasus, 691 lolos, 0 gagal, 0 dilewati**. **Typecheck dan build lolos**, dengan service worker `app-5.6`. Build memakai konfigurasi Firebase demo.

Log pemeriksaan lengkap tersedia di `validation/bukti-utang-piutang/`. Pengujian komponen ini memakai render React di Node, bukan interaksi browser. Peluncuran Chromium untuk pemeriksaan visual terhalang pembatasan sandbox (`setsockopt: Operation not permitted`); menu belum diverifikasi secara visual atau dicapture. Paket belum dideploy ke situs live.

## Cara menerapkan dan memeriksa

Gunakan ZIP **DompetAjaib_v5.6_deploy_sekali_jalan.zip** dan ikuti [DEPLOY_CLOUD_SHELL.md](DEPLOY_CLOUD_SHELL.md). Setelah deploy:

1. Muat ulang aplikasi dan pastikan Pengaturan menampilkan **5.6**.
2. Buka Utang dengan sedikitnya dua kartu. Klik **Lainnya** pada kartu pertama; menu harus tampil di atas kartu berikutnya dan semua tombol dapat diklik. Ulangi di layar ponsel dan mode **Ringkas**.
3. Periksa ringkasan Utang/Piutang ketika ada campuran catatan aktif dan lunas. Nominal awal, “sudah dibayar/kembali”, persentase, dan jumlah catatan hanya berasal dari yang aktif.
4. Lunasi satu catatan uji. Ringkasan harus menghitung ulang catatan aktif yang tersisa dan menambahkan catatan yang lunas ke Arsip.
5. Jika semua catatan lunas, sisa harus Rp0 dan progres historis tidak muncul.
