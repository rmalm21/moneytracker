# Deploy Dompet Ajaib v5.6 lewat Google Cloud Shell

Semua langkah berjalan di browser. Target dari konfigurasi ZIP ini adalah project **`money-manage-32467`**, site Hosting **`dompetajaib`**, dan alamat **https://dompetajaib.web.app**. Gunakan akun Google yang punya akses deploy ke project tersebut.

Paket v5.6 memperbaiki lapisan menu Lainnya pada kartu Utang/Piutang dan membatasi ringkasan pada catatan aktif. Perbaikan edit pembayaran Split Bill dari v5.5 tetap disertakan. Seluruh 691 kasus tes, typecheck, dan build sudah lolos. Build lokal memakai konfigurasi Firebase demo; pemeriksaan visual browser terhalang sandbox, sementara uji Firebase Emulator dan deploy produksi belum dilakukan. Rincian ada di `PERBAIKAN_UTANG_PIUTANG.md`.

Salin setiap blok perintah ke terminal, lalu tekan **Enter**. Tunggu perintah selesai sebelum menjalankan blok berikutnya.

## 1. Upload dan ekstrak ZIP terbaru

Buka [Google Cloud Shell](https://shell.cloud.google.com/), lalu pilih **Upload file** dari menu tiga titik di terminal. Upload `DompetAjaib_v5.6_deploy_sekali_jalan.zip` ke direktori home.

Salin perintah berikut ke terminal. Jika nama ZIP unduhan berbeda, sesuaikan `ZIP_NAME`.

```bash
ZIP_NAME=DompetAjaib_v5.6_deploy_sekali_jalan.zip
DEPLOY_DIR="$HOME/dompet-ajaib-v56-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$DEPLOY_DIR"
unzip "$HOME/$ZIP_NAME" -d "$DEPLOY_DIR"
cd "$DEPLOY_DIR/dompet-ajaib"
```

Direktori baru memastikan file v5.6 tidak bercampur dengan hasil build sebelumnya. Biarkan terminal tetap berada di folder ini untuk semua langkah berikut.

## 2. Pakai Node 24 dan login Firebase

```bash
nvm install 24
nvm use 24
node --version
npm install -g firebase-tools
firebase login --no-localhost
firebase projects:list
```

Ikuti link login yang ditampilkan terminal dan pilih akun Google pemilik project. Pastikan `money-manage-32467` muncul pada daftar project. Node harus menampilkan `v24...`; tes proyek memakai dukungan TypeScript bawaan Node.

Jika `nvm` tidak ditemukan, pasang sekali, lalu ulangi langkah Node dan Firebase di atas:

```bash
curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash
. "$HOME/.nvm/nvm.sh"
```

## Opsional: ambil screenshot aplikasi sebelum deploy

Jalankan skrip capture dari folder proyek untuk menguji tampilan aplikasi di Cloud Shell:

Periksa `java -version`. Jika Java 21 belum tersedia, pasang dan pilih versinya:

```bash
sudo apt-get update
sudo apt-get install -y openjdk-21-jre-headless
sudo update-alternatives --config java
java -version
```

Kemudian jalankan:

```bash
bash CAPTURE_CLOUD_SHELL.sh
```

Skrip capture split saldo sebelumnya tetap menghasilkan nama berkas `CAPTURE_DompetAjaib_v5.4.zip`. Skrip memakai akun demo pada Firebase Emulator, sehingga data yang tampak adalah skenario uji split saldo. Konfigurasi demo diterapkan hanya pada proses pengujian; `.env.local` tetap utuh. Skrip menyiapkan alat browser/emulator secara terpisah, membutuhkan Java 21 dan akses unduh npm/browser, lalu menjalankan skenario UI serta mengambil screenshot. Skrip ini sudah disiapkan tetapi belum terverifikasi saat dijalankan di lingkungan pengerjaan paket ini.

Setelah skrip sukses, screenshot, galeri `screenshots.html`, hasil per poin `LAPORAN_CAPTURE.md`, log, dan manifest berada di **`validation/artifacts/`**. Bundle juga dibuat saat gagal agar log bisa diperiksa; jumlah gambar dan status kegagalan dicatat. Unduh bundelnya:

```bash
cloudshell download CAPTURE_DompetAjaib_v5.4.zip
```

Alternatifnya, pilih **Download file** dari menu terminal Cloud Shell dan masukkan path file tersebut. Jika skrip capture gagal, lihat pesan terakhir dan log pada `validation/artifacts/`; capture yang gagal belum membuktikan alur UI lolos. Skrip tidak melakukan deploy. Lanjutkan konfigurasi produksi berikut setelah selesai.

## 3. Isi konfigurasi Firebase sebelum build

```bash
cp .env.example .env.local
cloudshell edit .env.local
```

Di editor, isi nilai dari [Firebase Console → Project settings → Your apps → Web app → Config](https://console.firebase.google.com/project/money-manage-32467/settings/general). Gunakan web app yang sudah dipakai aplikasi sebelumnya.

| Nilai pada `firebaseConfig` | Nama di `.env.local` |
| --- | --- |
| `apiKey` | `NEXT_PUBLIC_FIREBASE_API_KEY` |
| `authDomain` | `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` |
| `projectId` | `NEXT_PUBLIC_FIREBASE_PROJECT_ID` |
| `storageBucket` | `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` |
| `messagingSenderId` | `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` |
| `appId` | `NEXT_PUBLIC_FIREBASE_APP_ID` |

Format setiap baris adalah `NAMA_VARIABEL=nilai`, tanpa koma atau tanda kutip JavaScript. `projectId` harus `money-manage-32467`. `NEXT_PUBLIC_AUTH_EMAIL_DOMAIN=gmail.com` mempertahankan login dengan nama pendek untuk akun Gmail. `storageBucket` boleh kosong jika project tidak menggunakannya.

Alternatif untuk melihat konfigurasi web app melalui terminal:

```bash
firebase apps:sdkconfig WEB --project money-manage-32467
```

Jika ada beberapa web app, pilih app yang dipakai Dompet Ajaib. Tetap salin nilainya ke `.env.local` memakai tabel di atas.

Pastikan baris emulator **kosong**, supaya hasil build terhubung ke Firebase project yang asli:

```dotenv
NEXT_PUBLIC_FIREBASE_EMULATOR_HOST=
```

`NEXT_PUBLIC_GEMINI_API_KEY` bersifat opsional untuk pembacaan struk. Isi kunci yang sudah digunakan sebelumnya jika fitur itu dibutuhkan. Simpan `.env.local` dengan **Ctrl+S**. Nilai `NEXT_PUBLIC_*` dimasukkan ke aplikasi saat build; perubahan konfigurasi memerlukan build ulang.

## 4. Pasang dependensi, periksa, dan build

```bash
npm ci
npm run typecheck
npm test
npm run build
```

Jalankan baris di atas satu per satu dengan Enter. Tunggu sampai setiap perintah selesai dengan sukses; jika ada yang gagal, selesaikan error sebelum melanjutkan. Build menghasilkan folder **`out/`**, termasuk aset pembaca struk dan service worker versi 5.6. Pastikan hasilnya tersedia:

```bash
test -f out/index.html && test -f out/sw.js
```

Jika ada pesan error, selesaikan error tersebut sebelum lanjut ke deploy. Status pengujian yang sudah dilakukan selama pengerjaan tercatat pada `VALIDASI_SPLIT_SALDO.md`; pengujian di langkah ini memverifikasi lingkungan build milik lo.

## 5. Deploy aturan Firestore dan situs

Perintah berikut memperbarui alamat live dan aturan akses Firestore di project tujuan:

```bash
firebase deploy --only firestore,hosting --project money-manage-32467
```

Tunggu **Deploy complete!**, lalu buka **https://dompetajaib.web.app**. `firebase.json` sudah mengarah ke site `dompetajaib` dan folder `out/`; project ini sudah memiliki konfigurasi Firebase sehingga tidak perlu menjalankan `firebase init`.

Aturan Firestore harus ikut diperbarui karena transaksi v5.6 menyimpan pilihan saldo Pribadi/Bisnis. Skrip percobaan lama `COBA_TANPA_INSTAL.sh` dan `PERBARUI_LINK_COBA.sh` hanya mengunggah Hosting; gunakan perintah deploy di atas untuk pembaruan v5.6 ini.

Deploy mengunggah aturan, indeks, dan file aplikasi. Data dompet serta transaksi yang sudah tersimpan tetap berada di Firestore. Transaksi lama yang belum punya pilihan saldo dibaca sebagai Pribadi.

## Periksa setelah deploy

1. Buka Pengaturan dan pastikan versi **5.6**. Jika masih menampilkan versi lama, tutup aplikasi/PWA, buka lagi, lalu lakukan hard refresh di browser.
2. Login dengan akun yang sudah ada dan pastikan data lama muncul. Di Firebase Console, metode Authentication **Email/Password** harus aktif dan `dompetajaib.web.app` harus berada pada **Authentication → Settings → Authorized domains**.
3. Buat dompet uji dengan total **Rp1.000.000**, split aktif, dan saldo awal Bisnis **Rp400.000**. Kartu harus menampilkan Pribadi **Rp600.000** dan Bisnis **Rp400.000**.
4. Catat pemasukan Bisnis **Rp200.000**, lalu pengeluaran Pribadi **Rp100.000**. Total menjadi **Rp1.100.000**, Pribadi **Rp500.000**, dan Bisnis **Rp600.000**.
5. Pindah **Rp100.000** dari Pribadi ke Bisnis dalam dompet yang sama. Total tetap **Rp1.100.000**, Pribadi menjadi **Rp400.000**, dan Bisnis **Rp700.000**.
6. Periksa filter saldo pada Transaksi/Laporan, lalu reload aplikasi. Saldo dan pilihan bagian saldo harus tetap tersimpan.
7. Buka pembayaran Split Bill yang sudah lunas di Transaksi → Edit. Piutang asal harus sudah dipilih dengan label Lunas. Ubah tanggal ke kemarin dan Simpan. Tanggal berubah, status tetap Lunas, dan saldo tidak berubah.
8. Buka Utang dengan dua kartu atau lebih. Klik Lainnya pada kartu pertama: menu harus tampil di atas kartu berikutnya. Periksa juga mode Ringkas dan layar ponsel.
9. Periksa ringkasan Utang/Piutang dengan campuran catatan aktif dan lunas: nominal awal, sudah dibayar/kembali, persentase, dan jumlah catatan hanya berasal dari yang aktif. Jika semuanya lunas, sisa Rp0 tanpa progres historis; riwayatnya ada di Arsip.

## Jika mengalami kendala

- **`unzip` tidak menemukan ZIP:** jalankan `ls "$HOME"/*.zip`, lalu sesuaikan `ZIP_NAME` dan ulangi langkah ekstraksi.
- **Firebase `permission denied` saat deploy:** jalankan `firebase login --reauth --no-localhost` menggunakan akun yang punya akses ke `money-manage-32467`. Jika project tidak muncul pada `firebase projects:list`, pemilik project perlu memberikan akses akun tersebut.
- **`permission-denied` ketika menyimpan saldo/transaksi:** pastikan perintah deploy mencakup `firestore,hosting` dan project yang dipilih benar. Pastikan login aplikasi memakai akun Firebase yang valid.
- **Aplikasi menyatakan konfigurasi Firebase belum diisi:** periksa `apiKey`, `projectId`, dan `appId` pada `.env.local`, kemudian ulangi build dan deploy. Mengedit `.env.local` setelah build tidak mengubah bundel yang sudah dibuat.
- **`auth/unauthorized-domain`:** tambahkan `dompetajaib.web.app` ke daftar Authorized domains di Firebase Authentication.

Deploy live ke akun Google lo dilakukan lewat langkah di atas. Deploy tersebut belum dijalankan selama pengerjaan paket ini.
