/** Real browser + Firebase Emulator verification. Never connects to production Firebase.
 * Start the emulators and the app as documented in validation/README.md first.
 * Run: node validation/verify-split-saldo.mjs
 */
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
let playwright;
if (process.env.PLAYWRIGHT_PACKAGE) playwright = require(path.resolve(process.env.PLAYWRIGHT_PACKAGE));
else {
  try { playwright = require('playwright'); }
  catch { playwright = require('/opt/codex/runtimes/cua/lib/node_modules/playwright'); }
}
const { chromium } = playwright;
const base = process.env.E2E_APP_URL || 'http://127.0.0.1:3000';
assert(['127.0.0.1', 'localhost'].includes(new URL(base).hostname), 'E2E app must be localhost');
const project = 'demo-split';
const firestore = `http://127.0.0.1:8080/v1/projects/${project}/databases/(default)/documents`;
const artifacts = path.resolve('validation/artifacts');
await fs.mkdir(artifacts, { recursive: true });
const results = [], browserErrors = [], consoleErrors = [], screenshots = [];
let completed = false;
const stamp = Date.now();
const email = `split-${stamp}@example.test`, password = 'LocalTest123!';

function encode(value) {
  if (value === null) return { nullValue: null };
  if (typeof value === 'boolean') return { booleanValue: value };
  if (typeof value === 'number') return { integerValue: String(value) };
  if (typeof value === 'string') return { stringValue: value };
  if (Array.isArray(value)) return { arrayValue: { values: value.map(encode) } };
  return { mapValue: { fields: Object.fromEntries(Object.entries(value).map(([k, v]) => [k, encode(v)])) } };
}
function decode(value) {
  if ('integerValue' in value) return Number(value.integerValue);
  if ('doubleValue' in value) return value.doubleValue;
  if ('booleanValue' in value) return value.booleanValue;
  if ('stringValue' in value) return value.stringValue;
  if ('timestampValue' in value) return value.timestampValue;
  if ('nullValue' in value) return null;
  if ('arrayValue' in value) return (value.arrayValue.values || []).map(decode);
  if ('mapValue' in value) return decodeFields(value.mapValue.fields);
  return undefined;
}
const decodeFields = (fields = {}) => Object.fromEntries(Object.entries(fields).map(([k, v]) => [k, decode(v)]));
async function request(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer owner', ...options.headers } });
  const body = await response.json();
  if (!response.ok) throw Error(`${response.status} ${url}: ${JSON.stringify(body)}`);
  return body;
}
async function seed(relative, data) {
  return request(`${firestore}/${relative}`, { method: 'PATCH', body: JSON.stringify({ fields: Object.fromEntries(Object.entries(data).map(([k, v]) => [k, encode(v)])) }) });
}
async function rejectedWrite(relative, data) {
  const response = await fetch(`${firestore}/${relative}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${account.idToken}` }, body: JSON.stringify({ fields: Object.fromEntries(Object.entries(data).map(([k, v]) => [k, encode(v)])) }) });
  assert.equal(response.status, 403, `Security rules must reject ${relative}: ${await response.text()}`);
}
async function documents(collection) {
  const response = await request(`${firestore}/users/${uid}/${collection}?pageSize=1000`);
  return (response.documents || []).map(doc => ({ id: doc.name.split('/').at(-1), ...decodeFields(doc.fields) }));
}
async function poll(fn, description, timeout = 30000) {
  const deadline = Date.now() + timeout;
  let last;
  while (Date.now() < deadline) {
    try { const value = await fn(); if (value) return value; }
    catch (error) { last = error; }
    await new Promise(resolve => setTimeout(resolve, 200));
  }
  throw Error(`Timeout: ${description}${last ? ` (${last.message})` : ''}`);
}
function pass(name, details) { results.push({ name, details, passed: true }); console.log(`PASS ${name}`); }
function compact(text) { return text.replace(/\s/g, ''); }
async function balance(name, total, business) {
  const wallet = await poll(async () => {
    const w = (await documents('wallets')).find(row => row.name === name);
    return w?.cachedBalance === total && (w.cachedBusinessBalance || 0) === business && w;
  }, `${name} total=${total}, business=${business}`);
  assert.equal(total - (wallet.cachedBusinessBalance || 0), total - business);
  pass(`Persisted balance: ${name}`, { total, business, personal: total - business });
  return wallet;
}
const account = await request('http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/accounts:signUp?key=demo-key', {
  method: 'POST', body: JSON.stringify({ email, password, returnSecureToken: true }),
});
const uid = account.localId;
await seed(`users/${uid}`, { uid, email, username: `split${stamp}`, displayName: 'Split Saldo E2E', currency: 'IDR', salaryCycleStartDay: 24, monthlySalary: 0, onboardingDone: true, hideReserved: true, theme: 'light', dashboardWidgets: [], timeZone: 'Asia/Jakarta', analyticsPeriod: 'month' });
await seed(`users/${uid}/categories/expense-test`, { name: 'Belanja E2E', type: 'expense', parentId: null, isArchived: false, icon: '🛒', color: '#267e73', sortOrder: 0 });
await seed(`users/${uid}/categories/income-test`, { name: 'Usaha E2E', type: 'income', parentId: null, isArchived: false, icon: '💰', color: '#267e73', sortOrder: 0 });
await seed(`users/${uid}/wallets/legacy-test`, { name: 'Dompet Lama E2E', type: 'bank', group: 'operational', openingBalance: 500000, cachedBalance: 500000, purpose: '', isReserved: false, isSpendable: true, includeInNetWorth: true, isArchived: false, canPay: true, canReceive: true, canTransferIn: true, canTransferOut: true, displayOrder: 1, icon: '💳' });

let chromiumPath = process.env.CHROMIUM_PATH;
if (!chromiumPath) { try { await fs.access('/usr/bin/chromium'); chromiumPath = '/usr/bin/chromium'; } catch {} }
const browser = await chromium.launch({ ...(chromiumPath ? { executablePath: chromiumPath } : {}), headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 1440, height: 1100 }, locale: 'id-ID', timezoneId: 'Asia/Jakarta' });
// Tests must not contact a real Firebase project, analytics, fonts, or other external services.
await context.route('**/*', route => {
  const url = new URL(route.request().url());
  return ['127.0.0.1', 'localhost'].includes(url.hostname) || ['data:', 'blob:'].includes(url.protocol) ? route.continue() : route.abort();
});
const page = await context.newPage();
page.setDefaultTimeout(20000);
page.on('pageerror', error => browserErrors.push(error.message));
page.on('console', msg => { if (msg.type() === 'error') consoleErrors.push(msg.text()); });
const dialog = () => page.getByRole('dialog').last();
async function choose(scope, comboName, optionName) {
  await scope.getByRole('combobox', { name: comboName, exact: true }).click();
  await page.getByRole('option', { name: optionName, exact: false }).click();
}
async function chooseField(scope, fieldName, optionName) {
  const label = scope.locator('label.field').filter({ has: page.locator('span').filter({ hasText: new RegExp(`^${fieldName}$`) }) }).first();
  await label.getByRole('combobox').click();
  await page.getByRole('option', { name: optionName, exact: true }).click();
}
async function chooseBalance(scope, name, kind) {
  const group = scope.getByRole('radiogroup', { name, exact: true });
  const label = kind === 'business' ? 'Bisnis' : 'Pribadi';
  await group.getByText(label, { exact: true }).click();
  assert.equal(await group.getByRole('radio', { name: new RegExp(label) }).isChecked(), true);
}
async function navigate(view) {
  await page.goto(`${base}/?view=${view}`);
  if (view === 'wallets') await page.getByRole('heading', { name: 'Dompet & rekening' }).waitFor();
  if (view === 'transactions') await page.getByRole('heading', { name: 'Transaksi', exact: true }).waitFor();
  if (view === 'dashboard') await page.locator('.home-dash').waitFor();
  await page.locator('.view-skeleton').waitFor({ state: 'hidden' });
}
const html = text => String(text).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
async function writeCaptureManifest() {
  const manifest = { timestamp: new Date().toISOString(), project, appUrl: base, completed, source: 'Screenshot of the actual running app, with local Firebase demo data only', screenshots };
  await fs.writeFile(path.join(artifacts, 'screenshots.json'), JSON.stringify(manifest, null, 2));
  const gallery = `<!doctype html><html lang="id"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Screenshot perubahan Split Saldo</title><style>body{font-family:system-ui,sans-serif;max-width:1200px;margin:32px auto;padding:0 20px;background:#f7faf9;color:#15352e}article{background:white;padding:20px;margin:24px 0;border:1px solid #d7e5df;border-radius:12px}img{display:block;max-width:100%;height:auto;border:1px solid #d7e5df}p{line-height:1.6}code{overflow-wrap:anywhere}</style><h1>Screenshot perubahan Split Saldo</h1><p>Gambar berasal dari aplikasi yang berjalan dengan data demo Firebase lokal. Ini capture UI aplikasi, bukan mockup. Status pengujian keseluruhan: <strong>${completed ? 'selesai' : 'belum selesai'}</strong>. Hasil per langkah ada di <a href="results.json">results.json</a>.</p>${screenshots.map(shot => `<article><h2>${html(shot.title)}</h2><p>${html(shot.purpose)}</p><p><strong>Kondisi saat capture:</strong> ${html(shot.checkedStep)}</p><p><code>${html(shot.filename)}</code> · ${shot.viewport.width} × ${shot.viewport.height}</p><a href="${html(shot.filename)}"><img src="${html(shot.filename)}" alt="${html(shot.title)}" loading="lazy"></a></article>`).join('')}</html>`;
  await fs.writeFile(path.join(artifacts, 'screenshots.html'), gallery);
}
async function capture(filename, title, purpose, checkedStep) {
  await page.screenshot({ path: path.join(artifacts, filename), fullPage: true, animations: 'disabled' });
  screenshots.push({ filename, path: `validation/artifacts/${filename}`, title, purpose, checkedStep, viewport: page.viewportSize(), url: page.url(), capturedAt: new Date().toISOString(), passedStepsBeforeCapture: results.filter(result => result.passed).map(result => result.name) });
  await writeCaptureManifest();
  console.log(`CAPTURE ${filename}: ${title}`);
}
async function transaction(type, amount, kind, description, walletName = 'Satu Dompet E2E', destinationKind, transferFee = 0, shot) {
  await page.getByRole('button', { name: 'Catat transaksi', exact: true }).first().click();
  const form = dialog();
  await form.getByRole('tab', { name: type === 'Pemasukan' ? 'Masuk' : type === 'Pengeluaran' ? 'Keluar' : type, exact: true }).click();
  await form.locator('.tx-amount-input input').fill(String(amount));
  if (type === 'Pengeluaran' || type === 'Pemasukan') {
    await form.getByRole('button', { name: 'Pilih kategori', exact: true }).click();
    await dialog().getByRole('button', { name: type === 'Pengeluaran' ? /Belanja E2E/ : /Usaha E2E/ }).click();
  }
  await choose(form, type === 'Pemasukan' ? 'Masuk ke dompet' : 'Dari dompet', walletName);
  if (walletName === 'Satu Dompet E2E') {
    await chooseBalance(form, type === 'Pemasukan' ? 'Masuk ke saldo' : 'Gunakan saldo', kind);
  }
  if (type === 'Transfer') {
    await choose(form, 'Dompet tujuan', walletName);
    await chooseBalance(form, 'Saldo tujuan', destinationKind);
    assert.match(await form.textContent(), /dalam satu dompet/);
    if (transferFee) {
      await form.getByLabel('Biaya admin', { exact: true }).fill(String(transferFee));
      await chooseField(form, 'Kategori biaya', 'Belanja E2E');
    }
  }
  await form.getByLabel('Keterangan', { exact: true }).fill(description);
  if (shot) {
    const groupName = type === 'Pemasukan' ? 'Masuk ke saldo' : 'Gunakan saldo';
    await form.getByRole('radiogroup', { name: groupName, exact: true }).scrollIntoViewIfNeeded();
    await capture(shot.filename, shot.title, shot.purpose, 'Formulir terisi dan pilihan saldo sudah diperiksa; transaksi pada gambar ini belum disimpan.');
  }
  await form.getByRole('button', { name: 'Simpan', exact: true }).click();
  await form.waitFor({ state: 'hidden' });
  const saved = await poll(async () => (await documents('transactions')).find(tx => tx.description === description), `transaction ${description}`);
  assert.equal(saved.balanceKind || 'personal', kind);
  if (type === 'Transfer') { assert.equal(saved.destinationBalanceKind, destinationKind); assert.equal(saved.destinationWalletId, saved.walletId); }
  pass(`UI transaction: ${description}`, { type: saved.type, amount: saved.amount, kind: saved.balanceKind, destinationKind: saved.destinationBalanceKind });
  return saved;
}

try {
  await page.goto(`${base}/login/`);
  await page.getByLabel('Username atau email').fill(email);
  await page.getByLabel('Password', { exact: true }).fill(password);
  await page.getByRole('button', { name: 'Masuk', exact: true }).click();
  await page.getByRole('button', { name: 'Catat transaksi', exact: true }).first().waitFor();
  pass('UI login with local Firebase Auth');
  await navigate('wallets');
  await page.getByRole('button', { name: 'Tambah dompet', exact: true }).click();
  await dialog().getByLabel('Nama', { exact: true }).fill('Satu Dompet E2E');
  await dialog().getByLabel('Saldo awal', { exact: false }).fill('1000000');
  await dialog().getByLabel('Pisahkan saldo pribadi & bisnis', { exact: false }).check();
  await dialog().getByLabel('Saldo awal bisnis', { exact: false }).fill('400000');
  assert.equal(await dialog().getByLabel('Pisahkan saldo pribadi & bisnis', { exact: false }).isChecked(), true);
  assert.match(compact(await dialog().textContent()), /SaldoawalpribadiRp600\.000/);
  await capture('01-wallet-split-form.png', 'Form dompet: aktifkan saldo pribadi dan bisnis', 'Dompet tetap satu. Saldo awal total Rp1.000.000 dibagi pribadi Rp600.000 dan bisnis Rp400.000.', 'Opsi split aktif dan preview pribadi Rp600.000 diperiksa; dompet belum disimpan.');
  await dialog().getByRole('button', { name: 'Simpan', exact: true }).click();
  const split = await balance('Satu Dompet E2E', 1000000, 400000);
  assert.equal(split.balanceSplitEnabled, true);
  assert.equal((await documents('wallets')).length, 2, 'One split wallet plus one legacy wallet only');
  const card = page.getByRole('button', { name: 'Buka dompet Satu Dompet E2E', exact: true });
  await poll(async () => compact(await card.textContent()).includes('Rp600.000') && compact(await card.textContent()).includes('Rp400.000'), 'wallet personal/business visible');
  pass('Wallet displays total + both balances without creating extra wallets');
  await capture('02-wallet-created.png', 'Kartu dompet: total dan dua bagian saldo', 'Kartu menunjukkan saldo pribadi, saldo bisnis, dan total pada satu dompet.', 'Firestore menyimpan total Rp1.000.000 dan bisnis Rp400.000; UI pribadi Rp600.000 dan bisnis Rp400.000 sudah diperiksa.');
  await card.click();
  await dialog().locator('.wh-balance').waitFor();
  assert.match(compact(await dialog().textContent()), /Rp600\.000/);
  assert.match(compact(await dialog().textContent()), /Rp400\.000/);
  await dialog().getByRole('button', { name: 'Pindah saldo', exact: true }).waitFor();
  await capture('03-wallet-detail.png', 'Detail dompet dan tombol Pindah saldo', 'Rincian pribadi dan bisnis tampil bersama total, dengan aksi Pindah saldo dalam satu dompet.', 'Detail menampilkan kedua nominal; tombol Pindah saldo tersedia.');
  await page.keyboard.press('Escape');
  await dialog().waitFor({ state: 'hidden' });

  const income = await transaction('Pemasukan', 200000, 'business', 'Pemasukan bisnis E2E', 'Satu Dompet E2E', undefined, 0, { filename: '04-business-income-form.png', title: 'Form pemasukan: pilih saldo Bisnis', purpose: 'Pemasukan Rp200.000 dialokasikan ke bisnis, memakai dompet yang sama.' });
  await balance('Satu Dompet E2E', 1200000, 600000);
  const expense = await transaction('Pengeluaran', 100000, 'personal', 'Belanja pribadi E2E', 'Satu Dompet E2E', undefined, 0, { filename: '05-personal-expense-form.png', title: 'Form pengeluaran: pilih saldo Pribadi', purpose: 'Pengeluaran Rp100.000 memakai bagian pribadi dari dompet yang sama.' });
  await balance('Satu Dompet E2E', 1100000, 600000);
  await transaction('Transfer', 100000, 'personal', 'Pindah saldo E2E', 'Satu Dompet E2E', 'business', 0, { filename: '06-internal-balance-transfer-form.png', title: 'Pindah saldo Pribadi ke Bisnis dalam satu dompet', purpose: 'Dompet asal dan tujuan sama; Rp100.000 berpindah antarbagiannya, sehingga total tetap.' });
  await balance('Satu Dompet E2E', 1100000, 700000);
  const feeTransfer = await transaction('Transfer', 50000, 'business', 'Pindah saldo dengan biaya E2E', 'Satu Dompet E2E', 'personal', 5000);
  await balance('Satu Dompet E2E', 1095000, 645000);
  await navigate('transactions');
  await page.getByText('Pindah saldo dengan biaya E2E', { exact: true }).first().click();
  await dialog().locator('.tx-amount-input input').fill('60000');
  await dialog().getByRole('button', { name: 'Simpan perubahan', exact: true }).click();
  await balance('Satu Dompet E2E', 1095000, 635000);
  pass('Editing internal transfer with fee reverses both balance legs and retains fee on source');
  await page.getByText('Pindah saldo dengan biaya E2E', { exact: true }).first().click();
  await dialog().getByRole('button', { name: 'Hapus transaksi', exact: true }).click();
  await page.getByRole('alertdialog').getByRole('button', { name: 'Hapus', exact: true }).click();
  await balance('Satu Dompet E2E', 1100000, 700000);
  assert(!(await documents('transactions')).some(tx => tx.id === feeTransfer.id));
  pass('Deleting internal transfer with fee restores total and both balance parts');
  await navigate('wallets');
  await capture('07-wallet-after-transactions.png', 'Saldo sesudah pemasukan, pengeluaran, dan pindah saldo', 'Sesudah tiga transaksi: pribadi Rp400.000, bisnis Rp700.000, total Rp1.100.000.', 'Nominal total dan bisnis tersimpan telah diperiksa setelah semua operasi; edit dan hapus transfer dengan biaya mengembalikan saldo dengan benar.');
  await transaction('Pengeluaran', 50000, 'personal', 'Belanja dompet lama E2E', 'Dompet Lama E2E');
  await balance('Dompet Lama E2E', 450000, 0);
  await balance('Satu Dompet E2E', 1100000, 700000);
  await rejectedWrite(`users/${uid}/transactions/invalid-business`, { type: 'income', amount: 1000, walletId: 'legacy-test', balanceKind: 'business' });
  await rejectedWrite(`users/${uid}/transactions/invalid-kind`, { type: 'income', amount: 1000, walletId: split.id, balanceKind: 'invalid' });
  await rejectedWrite(`users/${uid}/wallets/${split.id}`, { ...decodeFields((await request(`${firestore}/users/${uid}/wallets/${split.id}`)).fields), balanceSplitEnabled: false, openingBusinessBalance: 0, cachedBusinessBalance: 0 });
  pass('Firestore rules reject business on legacy wallet, invalid balance kind, and disabling existing split');

  await navigate('transactions');
  await page.getByText('Pemasukan bisnis E2E', { exact: true }).first().click();
  await dialog().locator('.tx-amount-input input').fill('250000');
  await dialog().getByRole('button', { name: 'Simpan perubahan', exact: true }).click();
  await balance('Satu Dompet E2E', 1150000, 750000);
  const updatedIncome = (await documents('transactions')).find(tx => tx.id === income.id);
  assert.equal(updatedIncome.amount, 250000);
  pass('Edit transaction reverses previous amount and applies new amount');

  await page.getByText('Belanja pribadi E2E', { exact: true }).first().click();
  await dialog().getByRole('button', { name: 'Hapus transaksi', exact: true }).click();
  await page.getByRole('alertdialog').getByRole('button', { name: 'Hapus', exact: true }).click();
  await balance('Satu Dompet E2E', 1250000, 750000);
  assert(!(await documents('transactions')).some(tx => tx.id === expense.id));
  pass('Delete transaction restores correct personal balance');

  await page.getByRole('button', { name: /^Filter/ }).click();
  await choose(page, 'Filter saldo', 'Bisnis');
  await poll(async () => (await page.locator('.tx-results').textContent()).includes('Pemasukan bisnis E2E'), 'business history loaded');
  const businessHistory = await page.locator('.tx-results').textContent();
  assert(businessHistory.includes('Pindah saldo E2E'));
  assert(!businessHistory.includes('Belanja dompet lama E2E'));
  pass('History business filter includes destination leg and excludes legacy spending');
  await capture('08-history-business.png', 'Riwayat transaksi dengan filter Bisnis', 'Riwayat bisnis memasukkan transfer yang menuju bisnis, serta mengecualikan belanja dari dompet lama yang pribadi.', 'Isi riwayat yang termasuk dan dikecualikan sudah diperiksa.');

  await navigate('report');
  await page.locator('details.report-filters > summary').click();
  await chooseField(page, 'Saldo', 'Bisnis');
  const incomeKpi = page.locator('.report-kpi').filter({ has: page.getByText('Pemasukan', { exact: true }) }).first();
  const expenseKpi = page.locator('.report-kpi').filter({ has: page.getByText('Pengeluaran', { exact: true }) }).first();
  await poll(async () => compact(await incomeKpi.textContent()).includes('Rp250.000'), 'business income report');
  await poll(async () => compact(await expenseKpi.textContent()).includes('Rp0'), 'business expense report');
  pass('Report business filter: income 250000, spending 0, internal transfer excluded from income/expense');
  await capture('09-report-business.png', 'Laporan dengan filter saldo Bisnis', 'Laporan bisnis menunjukkan pemasukan Rp250.000 dan pengeluaran Rp0; pindah saldo internal tidak menambah pemasukan atau pengeluaran.', 'KPI pemasukan dan pengeluaran bisnis diperiksa di UI.');

  const originalWallet = await request(`${firestore}/users/${uid}/wallets/${split.id}`);
  await request(`${firestore}/users/${uid}/wallets/${split.id}`, { method: 'PATCH', body: JSON.stringify({ fields: { ...originalWallet.fields, cachedBalance: encode(999999), cachedBusinessBalance: encode(123456), updatedAt: { timestampValue: new Date().toISOString() } } }) });
  await navigate('wallets');
  await poll(async () => compact(await page.getByRole('button', { name: 'Buka dompet Satu Dompet E2E', exact: true }).textContent()).includes('Rp999.999'), 'tampered wallet cache synced to UI');
  await page.getByLabel('Pilihan untuk Satu Dompet E2E', { exact: true }).click();
  await page.getByRole('button', { name: 'Hitung ulang saldo', exact: true }).click();
  await poll(async () => compact(await dialog().textContent()).includes('Rp999.999') && compact(await dialog().textContent()).includes('Rp123.456'), 'tampered cached balances are visible in recalculation preview');
  await capture('10-recalculate-split-balances.png', 'Hitung ulang saldo total dan saldo bisnis', 'Preview membandingkan cache yang sengaja dirusak dengan saldo hasil perhitungan transaksi.', 'Preview total cache Rp999.999 dan bisnis Rp123.456 diperiksa; koreksi belum dikonfirmasi pada gambar ini.');
  await dialog().getByRole('button', { name: 'Samakan saldo', exact: true }).click();
  await dialog().getByRole('button', { name: 'Konfirmasi Penyamaan saldo', exact: true }).click();
  await balance('Satu Dompet E2E', 1250000, 750000);
  pass('Recalculate repairs both total and business cached balances from ledger');
  await page.getByRole('dialog').waitFor({ state: 'hidden' });

  await page.reload();
  await page.getByRole('button', { name: 'Catat transaksi', exact: true }).first().waitFor();
  await navigate('wallets');
  await balance('Satu Dompet E2E', 1250000, 750000);
  await balance('Dompet Lama E2E', 450000, 0);
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true, 'No desktop horizontal overflow');
  pass('Desktop wallet layout fits viewport');
  await page.getByRole('button', { name: 'Buka dompet Dompet Lama E2E', exact: true }).getByRole('button', { name: 'Ubah', exact: true }).click();
  await dialog().getByLabel('Pisahkan saldo pribadi & bisnis', { exact: false }).check();
  await dialog().getByLabel('Saldo awal bisnis', { exact: false }).fill('200000');
  await dialog().getByRole('button', { name: 'Simpan', exact: true }).click();
  await balance('Dompet Lama E2E', 450000, 200000);
  pass('Enable split on legacy wallet preserves total and applies old transactions to personal balance');
  await page.getByRole('radiogroup', { name: 'Tampilan dompet', exact: true }).getByRole('radio', { name: 'Ringkas', exact: true }).click();
  await poll(async () => compact(await page.getByRole('button', { name: 'Buka dompet Satu Dompet E2E', exact: true }).textContent()).includes('Rp750.000'), 'compact wallet displays business balance');
  await capture('11-wallet-compact.png', 'Tampilan ringkas: dua saldo dalam satu baris dompet', 'Tampilan ringkas tetap menunjukkan pribadi dan bisnis pada dompet yang sama.', 'Saldo bisnis Rp750.000 tampil pada baris dompet; saldo total telah diperiksa setelah reload.');
  await page.getByRole('radiogroup', { name: 'Tampilan dompet', exact: true }).getByRole('radio', { name: 'Kartu', exact: true }).click();
  await navigate('dashboard');
  const miniWallet = page.locator('.wallet-mini').filter({ hasText: 'Satu Dompet E2E' });
  await poll(async () => compact(await miniWallet.textContent()).includes('PribadiRp500.000') && compact(await miniWallet.textContent()).includes('BisnisRp750.000'), 'dashboard shows both balance parts');
  pass('Dashboard displays personal/business balance parts in one wallet item');
  await capture('12-dashboard-split-balances.png', 'Beranda: rincian saldo dompet pribadi dan bisnis', 'Kartu Saldo Dompet pada Beranda menampilkan kedua bagian tanpa menambah jumlah dompet.', 'Teks pribadi Rp500.000 dan bisnis Rp750.000 sudah diperiksa pada item dompet Beranda.');
  await navigate('wallets');
  await page.setViewportSize({ width: 390, height: 844 });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true, 'No mobile horizontal overflow');
  pass('Reload keeps persisted data; mobile wallet layout fits viewport');
  await capture('13-mobile-persistent-balances.png', 'Tampilan mobile: kartu dompet dan dua saldo', 'Dompet split dan dompet lama yang diaktifkan split tetap menampilkan alokasi setelah reload, pada lebar 390 piksel.', 'Persistensi nominal setelah reload dan tidak ada overflow horizontal pada halaman dompet mobile telah diperiksa.');
  await navigate('dashboard');
  await poll(async () => compact(await page.locator('.wallet-mini').filter({ hasText: 'Satu Dompet E2E' }).textContent()).includes('BisnisRp750.000'), 'mobile dashboard balance parts');
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true, 'No mobile dashboard horizontal overflow');
  pass('Mobile dashboard layout fits viewport and displays split balance');
  await capture('14-mobile-dashboard.png', 'Beranda mobile: saldo pribadi dan bisnis', 'Rincian saldo juga tampil di widget dompet pada layar mobile.', 'Bisnis Rp750.000 tampil dan halaman Beranda mobile tidak melampaui lebar viewport.');
  assert.deepEqual(browserErrors, [], 'No browser runtime errors');
  pass('No browser runtime exceptions');
  completed = true;
} catch (error) {
  results.push({ name: 'Harness completion', passed: false, error: error.message });
  await page.screenshot({ path: path.join(artifacts, 'failure.png'), fullPage: true }).catch(() => {});
  await fs.writeFile(path.join(artifacts, 'failure.txt'), `${error.stack}\n\nURL: ${page.url()}\n\n${await page.locator('body').innerText().catch(() => '')}`);
  throw error;
} finally {
  await fs.writeFile(path.join(artifacts, 'results.json'), JSON.stringify({ timestamp: new Date().toISOString(), project, appUrl: base, completed, passed: results.filter(result => result.passed).length, failed: results.filter(result => !result.passed).length, results, screenshots, browserErrors, consoleErrors }, null, 2));
  await writeCaptureManifest();
  await browser.close();
}
