/** Package only actual artifacts produced by the local demo run. No synthetic screenshots. */
import fs from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const artifacts = path.join(root, 'validation/artifacts');
await fs.mkdir(artifacts, { recursive: true });
async function optional(name, fallback) {
  try { return JSON.parse(await fs.readFile(path.join(artifacts, name), 'utf8')); }
  catch { return fallback; }
}
const [typecheck = 'not-run', unitTests = 'not-run', browser = 'not-run', exitCode = 'unknown'] = process.argv.slice(2);
const recorded = await optional('results.json', null);
const manifest = await optional('screenshots.json', []);
const entries = await fs.readdir(artifacts);
const screenshots = entries.filter(name => name.endsWith('.png')).sort();
const status = { generatedAt: new Date().toISOString(), project: 'demo-split', typecheck, unitTests, browser, exitCode, completed: recorded?.completed === true, screenshots, screenshotManifest: manifest, scope: 'Actual local demo app; no production Firebase or deployment.' };
await fs.writeFile(path.join(artifacts, 'cloud-shell-status.json'), JSON.stringify(status, null, 2));
const names = { passed: 'LOLOS', failed: 'GAGAL', 'not-run': 'BELUM DIJALANKAN' };
const report = [
  '# Hasil capture app DompetAjaib v5.4', '',
  `Waktu: ${status.generatedAt}`, '',
  'App dijalankan dengan project Firebase demo lokal. Screenshot diambil dari halaman app yang benar-benar dimuat; hasil ini tidak mencakup deployment produksi.', '',
  `- Typecheck: ${names[typecheck] || typecheck}.`,
  `- Tes fungsi: ${names[unitTests] || unitTests}; lihat unit-tests.tap.`,
  `- Alur browser: ${names[browser] || browser}.`,
  `- Rangkaian browser selesai: ${status.completed ? 'YA' : 'TIDAK'}.`,
  `- Gambar yang benar-benar dihasilkan: ${screenshots.length}.`, '',
  '## Hasil per poin', '',
];
if (recorded?.results?.length) {
  for (const result of recorded.results) {
    report.push(`- **${result.passed ? 'BERHASIL' : 'GAGAL'}**: ${String(result.name).replace(/[\r\n]/g, ' ')}${result.error ? ` — ${String(result.error).replace(/[\r\n]/g, ' ')}` : ''}.`);
    if (result.details) report.push(`  Rincian: ${JSON.stringify(result.details)}.`);
  }
} else {
  report.push('Belum ada hasil pemeriksaan UI. Lihat log setup/capture untuk penyebabnya.');
}
report.push('', '## Screenshot', '');
if (screenshots.length) {
  for (const file of screenshots) report.push(`- [${file}](${file})`);
  report.push('', 'Gambar failure.png, jika ada, adalah kondisi saat gagal; gambar tersebut tidak menandakan kelulusan alur. Keterangan gambar ada di screenshots.json.');
} else report.push('Belum ada screenshot aplikasi yang berhasil dibuat.');
report.push('', 'Build produksi dan deployment belum dilakukan oleh skrip capture. Ikuti DEPLOY_CLOUD_SHELL.md dari source ZIP untuk build dengan konfigurasi produksi dan deploy.', '');
await fs.writeFile(path.join(artifacts, 'LAPORAN_CAPTURE.md'), report.join('\n'));
const zip = path.join(root, 'CAPTURE_DompetAjaib_v5.4.zip');
const python = String.raw`
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import sys
source = Path(sys.argv[1])
target = Path(sys.argv[2])
with ZipFile(target, 'w', compression=ZIP_DEFLATED, compresslevel=9) as z:
    for item in sorted(source.rglob('*')):
        if item.is_file():
            z.write(item, str(Path('capture-app') / item.relative_to(source)))
with ZipFile(target) as z:
    assert z.testzip() is None
print(str(target))
`;
const packed = spawnSync('python3', ['-c', python, artifacts, zip], { stdio: 'inherit' });
if (packed.error) throw packed.error;
if (packed.status !== 0) process.exitCode = packed.status ?? 1;
