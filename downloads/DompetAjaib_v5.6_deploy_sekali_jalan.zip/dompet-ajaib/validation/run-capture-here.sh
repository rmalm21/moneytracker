#!/usr/bin/env bash
# Local demo validation only. Does not use production accounts, change proxy settings, or deploy.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p validation/artifacts
TOOL_DIR=/tmp/dompet-validation-tools
printf 'Installing only Firebase CLI into %s\n' "$TOOL_DIR"
npm install --prefix "$TOOL_DIR" --no-save --package-lock=false --no-audit --no-fund \
  --cache /tmp/dompet-npm-cache firebase-tools 2>&1 | tee validation/artifacts/install-tools.log
export PLAYWRIGHT_PACKAGE=/opt/codex/runtimes/cua/lib/node_modules/playwright
export CHROMIUM_PATH=/usr/bin/chromium
export FIREBASE_CLI="$TOOL_DIR/node_modules/firebase-tools/lib/bin/firebase.js"
export E2E_STATIC_EXPORT=1
export E2E_PERSISTENCE=1
node validation/run-local-validation.mjs 2>&1 | tee validation/artifacts/capture.log
