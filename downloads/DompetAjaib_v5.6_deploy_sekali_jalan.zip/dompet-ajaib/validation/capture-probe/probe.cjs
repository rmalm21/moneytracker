const { chromium } = require('/opt/codex/runtimes/cua/lib/node_modules/playwright');

// Browser capability probe only. This does not display or test the app.
(async () => {
  const browser = await chromium.launch({
    executablePath: '/usr/bin/chromium',
    headless: true,
    args: ['--no-sandbox', '--disable-dev-shm-usage'],
  });
  const page = await browser.newPage({ viewport: { width: 960, height: 540 } });
  await page.setContent('<!doctype html><html><body><h1>Local capture probe</h1><p>Capability probe only</p></body></html>');
  await page.screenshot({ path: '/tmp/dompet-local-capture-probe.png' });
  await browser.close();
  process.stdout.write('Local capture passed: /tmp/dompet-local-capture-probe.png\n');
})().catch(error => {
  process.stderr.write(String(error.stack || error) + '\n');
  process.exit(1);
});
