"""Render actual screenshot evidence and recorded checks into a readable PDF.

Requires Pillow and ReportLab. No app pages or mock screenshots are rendered here.
Run after browser validation: python validation/render-evidence-report.py
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from xml.sax.saxutils import escape

from PIL import Image
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph


ROOT = Path(__file__).resolve().parent.parent
INK = colors.HexColor('#16382e')
MUTED = colors.HexColor('#527369')
ACCENT = colors.HexColor('#136c52')
STYLE = ParagraphStyle('body', fontName='Helvetica', fontSize=10, leading=15,
                       textColor=INK, alignment=TA_LEFT)
CAPTION = ParagraphStyle('caption', parent=STYLE, fontSize=9, leading=12)
RESULT_LABELS = {
    'UI login with local Firebase Auth': 'Login melalui UI dan Firebase Auth lokal',
    'Wallet displays total + both balances without creating extra wallets': 'Satu kartu dompet menampilkan total, Pribadi, dan Bisnis tanpa membuat dompet tambahan',
    'Editing internal transfer with fee reverses both balance legs and retains fee on source': 'Edit pindah saldo dengan biaya membalik kedua alokasi dan membebankan biaya pada asal',
    'Deleting internal transfer with fee restores total and both balance parts': 'Hapus pindah saldo dengan biaya mengembalikan total dan kedua alokasi',
    'Firestore rules reject business on legacy wallet, invalid balance kind, and disabling existing split': 'Aturan Firestore menolak Bisnis pada dompet tanpa split, jenis saldo tidak valid, dan penonaktifan split yang sudah dipakai',
    'Edit transaction reverses previous amount and applies new amount': 'Edit transaksi membalik nominal lama dan menerapkan nominal baru',
    'Delete transaction restores correct personal balance': 'Hapus transaksi mengembalikan saldo Pribadi dengan tepat',
    'History business filter includes destination leg and excludes legacy spending': 'Filter riwayat Bisnis memasukkan sisi tujuan transfer dan mengecualikan belanja Pribadi',
    'Report business filter: income 250000, spending 0, internal transfer excluded from income/expense': 'Filter laporan Bisnis: pemasukan Rp250.000, pengeluaran Rp0; transfer internal tidak menambah keduanya',
    'Recalculate repairs both total and business cached balances from ledger': 'Hitung ulang memperbaiki saldo total dan Bisnis berdasarkan ledger',
    'Desktop wallet layout fits viewport': 'Halaman dompet desktop tidak melampaui lebar layar',
    'Enable split on legacy wallet preserves total and applies old transactions to personal balance': 'Aktifkan split pada dompet lama mempertahankan total dan mengalokasikan transaksi lama ke Pribadi',
    'Dashboard displays personal/business balance parts in one wallet item': 'Beranda menampilkan Pribadi dan Bisnis dalam item dompet yang sama',
    'Reload keeps persisted data; mobile wallet layout fits viewport': 'Saldo tetap tersimpan sesudah reload; halaman dompet mobile tidak melampaui lebar layar',
    'Mobile dashboard layout fits viewport and displays split balance': 'Beranda mobile menampilkan split dan tidak melampaui lebar layar',
    'No browser runtime exceptions': 'Tidak ada exception runtime pada browser',
}


def result_label(name):
    if name.startswith('Persisted balance: '):
        return 'Saldo tersimpan diperiksa: ' + name.removeprefix('Persisted balance: ')
    if name.startswith('UI transaction: '):
        return 'Transaksi melalui UI: ' + name.removeprefix('UI transaction: ')
    return RESULT_LABELS.get(name, name)


def load_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def paragraph(pdf, text, x, top, width, style=STYLE):
    block = Paragraph(escape(str(text)).replace('\n', '<br/>'), style)
    _, height = block.wrap(width, 1000)
    block.drawOn(pdf, x, top - height)
    return top - height


def page_start(pdf, title, page_size=A4):
    pdf.setPageSize(page_size)
    width, height = page_size
    pdf.setFillColor(ACCENT)
    pdf.rect(0, height - 12, width, 12, fill=1, stroke=0)
    pdf.setFillColor(INK)
    pdf.setFont('Helvetica-Bold', 20)
    pdf.drawString(36, height - 52, title)
    return width, height, height - 77


def page_end(pdf, page_no):
    width, _ = pdf._pagesize
    pdf.setFillColor(MUTED)
    pdf.setFont('Helvetica', 8)
    pdf.drawString(36, 21, 'Dompet Ajaib v5.4 | Data demo Firebase lokal | Capture UI asli')
    pdf.drawRightString(width - 36, 21, str(page_no))
    pdf.showPage()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--artifacts', type=Path, default=ROOT / 'validation/artifacts')
    parser.add_argument('--output', type=Path, default=ROOT.parent / 'Laporan_Capture_DompetAjaib_v5.4.pdf')
    parser.add_argument('--summary', type=Path, default=None,
                        help='Optional JSON of actually completed typecheck/build/unit checks')
    args = parser.parse_args()
    results = load_json(args.artifacts / 'results.json')
    manifest = load_json(args.artifacts / 'screenshots.json')
    screenshots = manifest.get('screenshots', [])
    if not screenshots:
        raise SystemExit('No screenshot files recorded; refusing to make a screenshot report.')
    for shot in screenshots:
        actual_path = args.artifacts / shot['filename']
        if not actual_path.is_file():
            raise SystemExit(f'Missing actual screenshot: {actual_path}')
    summary = load_json(args.summary) if args.summary else {}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    pdf = canvas.Canvas(str(args.output), pagesize=A4)
    pdf.setTitle('Laporan Capture Dompet Ajaib v5.4 - Split Saldo')
    pdf.setAuthor('Dompet Ajaib - verifikasi lokal')
    page_no = 1
    width, height, top = page_start(pdf, 'Split saldo dalam satu dompet')
    top = paragraph(pdf, 'Laporan perubahan dan bukti capture Dompet Ajaib v5.4', 36, top, width - 72)
    top -= 16
    top = paragraph(pdf, 'Satu dompet memiliki bagian Pribadi dan Bisnis. Total adalah penjumlahan keduanya. Screenshot pada laporan ini berasal langsung dari aplikasi yang berjalan dengan data demo Firebase lokal.', 36, top, width - 72)
    top -= 16
    rows = [
        ('Waktu pemeriksaan browser', results.get('timestamp', 'Tidak dicatat')),
        ('Project Firebase', results.get('project', 'Tidak dicatat')),
        ('Alur browser', f"{'SELESAI' if results.get('completed') else 'BELUM SELESAI'}; {results.get('passed', 0)} pemeriksaan lolos, {results.get('failed', 0)} gagal"),
        ('Screenshot asli', str(len(screenshots))),
    ]
    summary_labels = {'typecheck': 'Typecheck', 'build': 'Build', 'unitTests': 'Kasus tes', 'npmTest': 'npm test'}
    for label in ('typecheck', 'build', 'unitTests', 'npmTest'):
        if label in summary:
            item = summary[label]
            value = item if isinstance(item, str) else json.dumps(item, ensure_ascii=False)
            rows.append((summary_labels[label], value))
    for label, value in rows:
        top = paragraph(pdf, f'{label}: {value}', 36, top, width - 72)
        top -= 8
    top -= 15
    top = paragraph(pdf, 'Batas pemeriksaan: tidak mengubah akun atau data produksi dan tidak melakukan deployment. Form yang belum disimpan diberi keterangan pada caption. Kelulusan alur dibuktikan terpisah oleh hasil UI dan dokumen emulator, bukan oleh keberadaan gambar.', 36, top, width - 72)
    top -= 15
    paragraph(pdf, 'File bukti lengkap: results.json, screenshots.json, log tes, log typecheck/build, dan galeri screenshots.html pada paket capture.', 36, top, width - 72)
    page_end(pdf, page_no)
    page_no += 1

    width, height, top = page_start(pdf, 'Hasil pemeriksaan per poin')
    for index, result in enumerate(results.get('results', []), 1):
        label = f"{index}. {'LOLOS' if result.get('passed') else 'GAGAL'} - {result_label(result.get('name', 'Tanpa nama'))}"
        detail = result.get('details')
        if detail:
            label += '\n' + json.dumps(detail, ensure_ascii=False)
        if result.get('error'):
            label += '\n' + str(result['error'])
        block = Paragraph(escape(label).replace('\n', '<br/>'), STYLE)
        _, block_height = block.wrap(width - 72, 1000)
        if top - block_height < 50:
            page_end(pdf, page_no)
            page_no += 1
            width, height, top = page_start(pdf, 'Hasil pemeriksaan (lanjutan)')
        block.drawOn(pdf, 36, top - block_height)
        top -= block_height + 11
    page_end(pdf, page_no)
    page_no += 1

    for index, shot in enumerate(screenshots, 1):
        image_path = args.artifacts / shot['filename']
        with Image.open(image_path) as image:
            image_width, image_height = image.size
        viewport = shot.get('viewport', {})
        use_landscape = viewport.get('width', image_width) > viewport.get('height', image_height)
        page_size = landscape(A4) if use_landscape else A4
        width, height, top = page_start(pdf, f'Capture {index:02d} / {len(screenshots):02d}', page_size)
        top = paragraph(pdf, shot.get('title', shot['filename']), 36, top, width - 72)
        top -= 8
        top = paragraph(pdf, shot.get('purpose', ''), 36, top, width - 72, CAPTION)
        top -= 7
        top = paragraph(pdf, 'Kondisi saat capture: ' + shot.get('checkedStep', 'Tidak dicatat'), 36, top, width - 72, CAPTION)
        top -= 12
        available_width, available_height = width - 72, top - 55
        scale = min(available_width / image_width, available_height / image_height)
        draw_width, draw_height = image_width * scale, image_height * scale
        x = (width - draw_width) / 2
        y = top - draw_height
        pdf.drawImage(ImageReader(str(image_path)), x, y, draw_width, draw_height, preserveAspectRatio=True)
        pdf.setStrokeColor(colors.HexColor('#d3e4dc'))
        pdf.rect(x, y, draw_width, draw_height, stroke=1, fill=0)
        pdf.setFont('Helvetica', 7)
        pdf.setFillColor(MUTED)
        pdf.drawString(36, 39, f"{shot['filename']} | {image_width} x {image_height} px | {shot.get('capturedAt', '')}")
        page_end(pdf, page_no)
        page_no += 1
    pdf.save()
    print(json.dumps({'pdf': str(args.output), 'pages': page_no - 1,
                      'actualScreenshots': len(screenshots), 'completed': results.get('completed')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
