/** Starts only the local demo emulators and app, runs the browser test, then stops both.
 * FIREBASE_CLI can point to an isolated Firebase CLI executable.
 * Network/listen permissions are required by sandboxed environments.
 */
import { spawn } from 'node:child_process';
import { createWriteStream } from 'node:fs';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const artifacts = path.join(root, 'validation/artifacts');
await fs.mkdir(artifacts, { recursive: true });
const children = [];
const startedAt = new Date().toISOString();
let stage = 'emulators';
async function runStatus(state, error) {
  await fs.writeFile(path.join(artifacts, 'run-status.json'), JSON.stringify({ startedAt, updatedAt: new Date().toISOString(), project: 'demo-split', stage, state, completed: state === 'completed', ...(error ? { error: error.message, stack: error.stack } : {}) }, null, 2));
}
const env = { ...process.env, CI: 'true', FIREBASE_SKIP_AUTO_UPDATE_CHECK: 'true', XDG_CONFIG_HOME: path.join(os.tmpdir(), 'dompet-firebase-config'), XDG_CACHE_HOME: path.join(os.tmpdir(), 'dompet-firebase-cache'), FIREBASE_EMULATORS_PATH: process.env.FIREBASE_EMULATORS_PATH || path.join(os.tmpdir(), 'dompet-firebase-emulators'), NEXT_PUBLIC_FIREBASE_API_KEY: 'demo-key', NEXT_PUBLIC_FIREBASE_PROJECT_ID: 'demo-split', NEXT_PUBLIC_FIREBASE_APP_ID: 'demo-app', NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN: 'demo-split.firebaseapp.com', NEXT_PUBLIC_FIREBASE_EMULATOR_HOST: '127.0.0.1', E2E_APP_URL: 'http://127.0.0.1:3000' };
let startupError;
function service(command, args, logName) {
  const child = spawn(command, args, { cwd: root, env, detached: process.platform !== 'win32', stdio: ['ignore', 'pipe', 'pipe'] });
  const log = createWriteStream(path.join(artifacts, logName));
  child.stdout.pipe(log); child.stderr.pipe(log);
  child.on('error', error => { startupError = error; });
  children.push(child);
  return child;
}
async function ready(url, child, timeout = 120000) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    if (startupError) throw startupError;
    if (child.exitCode !== null) throw Error(`Service exited (${child.exitCode}); see logs in validation/artifacts`);
    try { const response = await fetch(url, { signal: AbortSignal.timeout(1500) }); if (response.status < 500) return; } catch {}
    await new Promise(resolve => setTimeout(resolve, 300));
  }
  throw Error(`Service did not become ready: ${url}; see logs in validation/artifacts`);
}
async function stop() {
  for (const child of children.reverse()) {
    if (!child.pid) continue;
    try { process.platform === 'win32' ? child.kill('SIGTERM') : process.kill(-child.pid, 'SIGTERM'); } catch {}
  }
}
process.on('SIGINT', async () => { await stop(); process.exit(130); });
process.on('SIGTERM', async () => { await stop(); process.exit(143); });
try {
  await runStatus('running');
  const firebaseCli = process.env.FIREBASE_CLI || 'firebase';
  const firebaseArgs = ['emulators:start', '--only', 'auth,firestore', '--project', 'demo-split', '--config', 'validation/firebase-emulator.json'];
  const firebase = /\.m?js$/i.test(firebaseCli) ? service(process.execPath, [firebaseCli, ...firebaseArgs], 'firebase.log') : service(firebaseCli, firebaseArgs, 'firebase.log');
  await Promise.all([ready('http://127.0.0.1:9099/', firebase, 300000), ready('http://127.0.0.1:8080/', firebase, 300000)]);
  console.log('Local Firebase demo emulators ready');
  stage = 'app';
  await runStatus('running');
  const appArgs = process.env.E2E_STATIC_EXPORT === '1' ? ['validation/serve-static.mjs'] : ['node_modules/next/dist/bin/next', 'dev', '--hostname', '127.0.0.1', '--port', '3000'];
  const app = service(process.execPath, appArgs, 'app.log');
  await ready('http://127.0.0.1:3000/login/', app);
  console.log('Local app ready');
  stage = 'browser';
  await runStatus('running');
  const test = spawn(process.execPath, ['validation/verify-split-saldo.mjs'], { cwd: root, env, stdio: 'inherit' });
  const code = await new Promise((resolve, reject) => { test.on('error', reject); test.on('exit', resolve); });
  if (code !== 0) throw Error(`Browser validation exited ${code}`);
  if (process.env.E2E_PERSISTENCE === '1') {
    stage = 'persistence';
    await runStatus('running');
    const persistence = spawn(process.execPath, ['validation/verify-persistence.mjs'], { cwd: root, env, stdio: 'inherit' });
    const persistenceCode = await new Promise((resolve, reject) => { persistence.on('error', reject); persistence.on('exit', resolve); });
    if (persistenceCode !== 0) throw Error(`Persistence validation exited ${persistenceCode}`);
  }
  await runStatus('completed');
  console.log('Browser verification completed. Actual app screenshots: validation/artifacts/screenshots.html');
} catch (error) {
  await runStatus('failed', error);
  throw error;
} finally {
  await stop();
}
