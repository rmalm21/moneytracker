# Verifikasi browser dan Firebase lokal

Status: harness sudah disiapkan dan diperiksa sintaksnya, tetapi **belum dijalankan** pada pengerjaan paket ini. Dependensi/tool emulator belum dapat dipasang karena izin jaringan lingkungan kerja belum tersedia. Belum ada hasil atau screenshot browser yang membuktikan kelulusan E2E.

Harness ini hanya memakai project demo Firebase `demo-split` di komputer lokal. Tidak membutuhkan akun Firebase asli, tidak mengubah data produksi, dan tidak melakukan deployment. Aturan Firestore aplikasi tetap aktif ketika browser melakukan transaksi. REST admin hanya dipakai untuk membuat profil/categories awal dan menyimulasikan cache rusak.

Prasyarat: dependency aplikasi (`npm ci`), Java 21, Firebase CLI, Playwright, dan Chromium. Package Playwright dari folder tool terpisah dipilih melalui `PLAYWRIGHT_PACKAGE`. Jika variabel ini tidak diberikan, harness mencoba package aplikasi lalu package bawaan Codex. Browser memakai `CHROMIUM_PATH`, `/usr/bin/chromium` jika ada, atau browser Chromium bawaan Playwright.

Di lingkungan sandbox, proses emulator, server aplikasi, dan browser membutuhkan izin jaringan lokal. Error `listen EPERM` menunjukkan izin untuk membuka port lokal belum diberikan.

Pasang tool pengujian di folder terpisah agar `npm ci` aplikasi tidak menghapusnya dan manifest/lockfile aplikasi tetap sama. Contoh untuk Linux/macOS; folder di `/tmp` bisa diganti folder lain di luar project:

```sh
npm ci
npm install --prefix /tmp/dompet-validation-tools --no-save --package-lock=false firebase-tools playwright
/tmp/dompet-validation-tools/node_modules/.bin/playwright install chromium
```

Pada Windows, gunakan folder tool terpisah yang sesuai. Set `PLAYWRIGHT_PACKAGE` ke folder `node_modules/playwright` dan `FIREBASE_CLI` ke berkas `node_modules/firebase-tools/lib/bin/firebase.js` melalui PowerShell atau pengaturan terminal; runner menjalankan entry JavaScript tersebut dengan Node.

Untuk menjalankan semuanya otomatis:

```sh
PLAYWRIGHT_PACKAGE=/tmp/dompet-validation-tools/node_modules/playwright FIREBASE_CLI=/tmp/dompet-validation-tools/node_modules/.bin/firebase node validation/run-local-validation.mjs
```

Runner menyalakan emulator dan Next dev dengan project demo, menjalankan browser, lalu menghentikan layanan. Gunakan port 3000, 8080, dan 9099 yang kosong. CLI dan JAR emulator dapat membutuhkan unduhan pertama saat dijalankan.

Jalankan emulator dari root project:

```sh
/tmp/dompet-validation-tools/node_modules/.bin/firebase emulators:start --only auth,firestore --project demo-split --config validation/firebase-emulator.json
```

Di terminal kedua, jalankan app dengan konfigurasi demo:

```sh
NEXT_PUBLIC_FIREBASE_API_KEY=demo-key NEXT_PUBLIC_FIREBASE_PROJECT_ID=demo-split NEXT_PUBLIC_FIREBASE_APP_ID=demo-app NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=demo-split.firebaseapp.com NEXT_PUBLIC_FIREBASE_EMULATOR_HOST=127.0.0.1 npm run dev -- --hostname 127.0.0.1
```

Di terminal ketiga:

```sh
PLAYWRIGHT_PACKAGE=/tmp/dompet-validation-tools/node_modules/playwright node validation/verify-split-saldo.mjs
```

Harness membuat user baru khusus pengujian, login melalui UI, membuat satu dompet split dan satu dompet lama, mencatat pemasukan/pengeluaran/pindah saldo internal, mengubah dan menghapus transaksi, memeriksa filter riwayat/laporan, merusak lalu menghitung ulang cache, dan memeriksa persistensi setelah reload serta tampilan mobile. Hasil tersimpan di `validation/artifacts/results.json` beserta screenshot. Semua nominal diperiksa pada dokumen Firestore emulator sesudah operasi UI.

## Capture perubahan dari aplikasi asli

Harness akan menghasilkan **14 screenshot aplikasi yang benar-benar berjalan**, bila semua langkah berhasil. Gambar tidak dibuat atau disertakan sebelum browser berhasil dijalankan. Data pada gambar berasal dari akun demo lokal yang baru dibuat, bukan data produksi pengguna.

| File | Perubahan yang ditampilkan |
|---|---|
| `01-wallet-split-form.png` | Checkbox pemisahan saldo dan pembagian saldo awal |
| `02-wallet-created.png` | Satu kartu dompet: total, pribadi, bisnis |
| `03-wallet-detail.png` | Detail dompet dan tombol Pindah saldo |
| `04-business-income-form.png` | Pilihan saldo bisnis pada pemasukan |
| `05-personal-expense-form.png` | Pilihan saldo pribadi pada pengeluaran |
| `06-internal-balance-transfer-form.png` | Asal dan tujuan saldo dalam satu dompet |
| `07-wallet-after-transactions.png` | Saldo setelah pemasukan, pengeluaran, dan transfer internal |
| `08-history-business.png` | Filter saldo bisnis pada riwayat |
| `09-report-business.png` | Filter saldo bisnis dan KPI laporan |
| `10-recalculate-split-balances.png` | Preview hitung ulang cache total dan bisnis |
| `11-wallet-compact.png` | Dua saldo pada tampilan dompet ringkas |
| `12-dashboard-split-balances.png` | Dua saldo pada widget Beranda |
| `13-mobile-persistent-balances.png` | Kartu dompet pada layar mobile |
| `14-mobile-dashboard.png` | Widget dompet pada Beranda mobile |

Buka `validation/artifacts/screenshots.html` untuk galeri dengan penjelasan per gambar. Manifest `screenshots.json` mencatat nama/path, waktu, viewport, tujuan gambar, dan pemeriksaan yang sudah lolos saat capture. Screenshot formulir sebelum Simpan diberi keterangan bahwa transaksi belum disimpan; keberhasilan penyimpanan diperiksa pada langkah sesudahnya di `results.json`.

`run-status.json` mencatat apakah runner berhasil menyalakan emulator, aplikasi, dan browser. Status `completed: true` pada `results.json` baru ditulis setelah seluruh pengujian selesai. Bila proses gagal, screenshot yang sudah ada adalah bukti langkah sebelumnya saja; baca `failure.txt`, `firebase.log`, dan `app.log` untuk penyebabnya. Jika gagal sebelum browser menyala, belum ada screenshot baru.

Untuk mengunduh seluruh capture dan hasilnya dari Google Cloud Shell setelah pengujian:

```sh
zip -r Capture_DompetAjaib_v5.4.zip validation/artifacts
cloudshell download Capture_DompetAjaib_v5.4.zip
```

Jangan mengaktifkan `NEXT_PUBLIC_FIREBASE_EMULATOR_HOST` pada deployment produksi.
