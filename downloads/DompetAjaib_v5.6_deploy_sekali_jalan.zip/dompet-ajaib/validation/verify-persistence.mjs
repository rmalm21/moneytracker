/** Exercise the actual persistence modules against local Firebase Auth/Firestore emulators.
 * Run after starting the Emulator Suite: node validation/verify-persistence.mjs
 * Uses separate temporary users, never clears emulator data, and never connects to production.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import ts from 'typescript';
import { connectAuthEmulator, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { connectFirestoreEmulator, getDocFromServer, getDocsFromServer, setDoc, terminate } from 'firebase/firestore';

const host = process.env.PERSISTENCE_EMULATOR_HOST || '127.0.0.1';
assert(['127.0.0.1', 'localhost'].includes(host), 'Only local emulators are allowed');
const project = process.env.PERSISTENCE_PROJECT_ID || 'demo-split';
assert(project.startsWith('demo-'), 'Only a Firebase demo project is allowed');
const authPort = Number(process.env.PERSISTENCE_AUTH_PORT || 9099);
const firestorePort = Number(process.env.PERSISTENCE_FIRESTORE_PORT || 8080);
assert(Number.isInteger(authPort) && Number.isInteger(firestorePort), 'Emulator ports must be integers');
const stamp = Date.now();
const root = path.resolve('.');
const runtime = path.join(root, 'validation', `.persistence-runtime-${stamp}`);
const artifacts = path.join(root, 'validation', 'artifacts');
const results = [];
let completed = false, db, auth;
const resultFile = path.join(artifacts, 'persistence-results.json');

async function record(name, run) {
  const started = Date.now();
  try {
    const details = await run();
    results.push({ name, passed: true, milliseconds: Date.now() - started, details });
    console.log(`PASS ${name}`);
  } catch (error) {
    results.push({ name, passed: false, milliseconds: Date.now() - started, error: error.stack || error.message });
    throw error;
  }
}

// Transpile application files, preserving their code and replacing only relative module file extensions.
// This provides a Node entry point without adding a test-only route to the app.
async function compile(directory) {
  const entries = await fs.readdir(directory, { withFileTypes: true });
  for (const entry of entries) {
    const source = path.join(directory, entry.name);
    if (entry.isDirectory()) { await compile(source); continue; }
    if (!/\.tsx?$/.test(entry.name)) continue;
    const target = path.join(runtime, path.relative(root, source)).replace(/\.tsx?$/, '.mjs');
    const changeModule = value => value.startsWith('.') && !/\.(?:json|mjs|js)$/.test(value)
      ? value.replace(/\.tsx?$/, '') + '.mjs' : value;
    const transformer = context => {
      const visit = node => {
        if (ts.isImportDeclaration(node) && ts.isStringLiteral(node.moduleSpecifier)) {
          return context.factory.updateImportDeclaration(node, node.modifiers, node.importClause,
            context.factory.createStringLiteral(changeModule(node.moduleSpecifier.text)), node.attributes);
        }
        if (ts.isExportDeclaration(node) && node.moduleSpecifier && ts.isStringLiteral(node.moduleSpecifier)) {
          return context.factory.updateExportDeclaration(node, node.modifiers, node.isTypeOnly, node.exportClause,
            context.factory.createStringLiteral(changeModule(node.moduleSpecifier.text)), node.attributes);
        }
        if (ts.isCallExpression(node) && node.expression.kind === ts.SyntaxKind.ImportKeyword
          && node.arguments.length === 1 && ts.isStringLiteral(node.arguments[0])) {
          return context.factory.updateCallExpression(node, node.expression, node.typeArguments,
            [context.factory.createStringLiteral(changeModule(node.arguments[0].text))]);
        }
        return ts.visitEachChild(node, visit, context);
      };
      return node => ts.visitNode(node, visit);
    };
    const output = ts.transpileModule(await fs.readFile(source, 'utf8'), {
      compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, jsx: ts.JsxEmit.ReactJSX },
      transformers: { before: [transformer] },
      fileName: source,
    }).outputText;
    await fs.mkdir(path.dirname(target), { recursive: true });
    await fs.writeFile(target, output);
  }
}

try {
  await fs.mkdir(artifacts, { recursive: true });
  await Promise.all([fetch(`http://${host}:${authPort}/`), fetch(`http://${host}:${firestorePort}/`)]);
  Object.assign(process.env, {
    NEXT_PUBLIC_FIREBASE_API_KEY: 'demo-key', NEXT_PUBLIC_FIREBASE_PROJECT_ID: project,
    NEXT_PUBLIC_FIREBASE_APP_ID: 'demo-persistence-app', NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN: `${project}.firebaseapp.com`,
    NEXT_PUBLIC_FIREBASE_EMULATOR_HOST: host,
  });
  // Node exposes navigator without onLine; give the app's online/offline helpers the browser's online value.
  if (typeof globalThis.navigator === 'undefined') globalThis.navigator = { onLine: true };
  else Object.defineProperty(globalThis.navigator, 'onLine', { value: true, configurable: true });
  await compile(path.join(root, 'lib'));
  const firebase = await import(pathToFileURL(path.join(runtime, 'lib/firebase.mjs')));
  ({ db, auth } = firebase);
  assert(db && auth, 'Local test Firebase must be configured');
  connectAuthEmulator(auth, `http://${host}:${authPort}`, { disableWarnings: true });
  connectFirestoreEmulator(db, host, firestorePort);
  const store = await import(pathToFileURL(path.join(runtime, 'lib/firestore.mjs')));
  const finance = await import(pathToFileURL(path.join(runtime, 'lib/finance-store.mjs')));
  const user = (await createUserWithEmailAndPassword(auth, `persist-${stamp}@example.test`, 'LocalTest123!')).user;
  let uid = user.uid;
  await setDoc(store.userRef(uid), { uid, onboardingDone: true });
  const wallet = await store.saveWallet(uid, { name: 'Persistence split', openingBalance: 1_000_000,
    balanceSplitEnabled: true, openingBusinessBalance: 400_000 });
  const legacy = await store.saveWallet(uid, { name: 'Persistence legacy', openingBalance: 50_000 });
  const row = async (collection, id) => {
    const snapshot = await getDocFromServer(store.ref(uid, collection, id));
    return snapshot.exists() ? { id: snapshot.id, ...snapshot.data() } : null;
  };
  const balances = async (id, total, business) => {
    const saved = await row('wallets', id);
    assert(saved, 'Wallet exists');
    assert.equal(saved.cachedBalance, total, 'Wallet total');
    assert.equal(saved.cachedBusinessBalance || 0, business, 'Business allocation');
    return saved;
  };
  const transaction = fields => store.newTx({ date: '2026-10-01', walletId: wallet, ...fields });

  await record('Same-wallet transfer create, edit and delete preserve both allocations and fees', async () => {
    const original = transaction({ type: 'transfer', amount: 100_000, balanceKind: 'personal', destinationWalletId: wallet,
      destinationBalanceKind: 'business', transferFee: 1_000, transferFeeCategoryId: 'fee-test' });
    const id = await store.upsertTransaction(uid, original);
    await balances(wallet, 999_000, 500_000);
    const edited = { ...original, amount: 50_000, balanceKind: 'business', destinationBalanceKind: 'personal', transferFee: 500 };
    await store.upsertTransaction(uid, edited, id);
    await balances(wallet, 999_500, 349_500);
    await store.deleteTransaction(uid, id);
    await balances(wallet, 1_000_000, 400_000);
    assert.equal(await row('transactions', id), null);
  });

  await record('Concurrent deletion reverses one business expense exactly once', async () => {
    const id = await store.upsertTransaction(uid, transaction({ type: 'expense', amount: 12_345,
      balanceKind: 'business', categoryId: 'expense-test' }));
    await balances(wallet, 987_655, 387_655);
    await Promise.all([store.deleteTransaction(uid, id), store.deleteTransaction(uid, id)]);
    await balances(wallet, 1_000_000, 400_000);
    assert.equal(await row('transactions', id), null);
  });

  await record('New draft uses the current schedule wallet, amount and balance kind together', async () => {
    const schedule = { name: 'Edited schedule', type: 'expense', amount: 1_000, walletId: wallet, balanceKind: 'business',
      destinationWalletId: null, categoryId: 'expense-test', frequency: 'weekly', nextDate: '2026-10-01', active: true, mode: 'draft' };
    const id = await store.saveRecord(uid, 'recurring', schedule);
    const stale = { id, ...schedule };
    await store.saveRecord(uid, 'recurring', { amount: 2_000, walletId: legacy, balanceKind: 'personal' }, id);
    await store.createDueDrafts(uid, [stale], '2026-10-01');
    const draft = await row('drafts', `${id}_2026-10-01`);
    assert.equal(draft.amount, 2_000);
    assert.equal(draft.walletId, legacy);
    assert.equal(draft.balanceKind, 'personal');
    assert.equal((await row('recurring', id)).nextDate, '2026-10-08');
  });

  await record('Automatic posting uses the committed draft, despite a stale subscription snapshot', async () => {
    const id = `auto_${stamp}`;
    const stale = { id, recurringId: 'local-auto', plannedDate: '2026-10-01', type: 'expense', amount: 1_000,
      walletId: wallet, balanceKind: 'business', destinationWalletId: null, destinationBalanceKind: 'personal',
      categoryId: 'expense-test', name: 'Stale automatic draft', status: 'pending', mode: 'auto' };
    const { id: _id, ...current } = { ...stale, amount: 2_000, walletId: legacy, balanceKind: 'personal' };
    await setDoc(store.ref(uid, 'drafts', id), current);
    await store.postAutoDrafts(uid, [stale]);
    const posted = (await getDocsFromServer(store.coll(uid, 'transactions'))).docs.map(doc => doc.data()).filter(tx => tx.draftId === id);
    assert.equal(posted.length, 1);
    assert.equal(posted[0].walletId, legacy);
    assert.equal(posted[0].balanceKind, 'personal');
    assert.equal(posted[0].amount, 2_000);
    await balances(wallet, 1_000_000, 400_000);
    await balances(legacy, 48_000, 0);
    await store.postAutoDrafts(uid, [stale]);
    await balances(legacy, 48_000, 0);
    assert.equal((await row('drafts', id)).status, 'posted');
  });

  await record('Concurrent rebuilds and new business income cannot overwrite cache increments', async () => {
    let total = 1_000_000, business = 400_000, refused = 0;
    for (let attempt = 0; attempt < 5; attempt++) {
      const before = await row('wallets', wallet);
      const outcomes = await Promise.allSettled([store.recalculateBalance(uid, before),
        ...Array.from({ length: 4 }, () => store.upsertTransaction(uid, transaction({ type: 'income', amount: 3, balanceKind: 'business' })))]);
      for (let i = 1; i < outcomes.length; i++) assert.equal(outcomes[i].status, 'fulfilled', 'Income is saved');
      if (outcomes[0].status === 'rejected') { assert.match(outcomes[0].reason.message, /Saldo berubah/); refused++; }
      total += 12; business += 12;
      await balances(wallet, total, business);
    }
    // Deliberately damaged allocations are repaired from the actual ledger, including same-wallet history.
    const saved = await row('wallets', wallet);
    const { id: _id, ...damaged } = { ...saved, cachedBalance: 123_456, cachedBusinessBalance: 1_234 };
    await setDoc(store.ref(uid, 'wallets', wallet), damaged);
    await finance.repairWalletCache(uid, wallet, 123_456);
    await balances(wallet, total, business);
    return { attempted: 5, concurrentRebuildsRefused: refused };
  });

  await record('Restore across 12 distinct business wallets stays within rule read limits', async () => {
    const ids = [];
    for (let index = 0; index < 12; index++) {
      const id = await store.saveWallet(uid, { name: `Restore business ${index}`, openingBalance: 200,
        balanceSplitEnabled: true, openingBusinessBalance: 100 });
      await store.upsertTransaction(uid, transaction({ type: 'expense', amount: 10, walletId: id,
        balanceKind: 'business', categoryId: 'expense-test' }));
      ids.push(id);
    }
    const backup = await store.exportData(uid);
    await signOut(auth);
    const restored = (await createUserWithEmailAndPassword(auth, `restore-${stamp}@example.test`, 'LocalTest123!')).user;
    uid = restored.uid;
    await setDoc(store.userRef(uid), { uid, onboardingDone: true });
    await store.importData(uid, backup, 'merge', true);
    for (const id of ids) await balances(id, 190, 90);
    await balances(wallet, 1_000_060, 400_060);
    await balances(legacy, 48_000, 0);
    return { restoredBusinessWallets: ids.length };
  });
  completed = true;
} catch (error) {
  if (!results.some(result => result.passed === false)) results.push({ name: 'Harness setup/completion', passed: false, error: error.stack || error.message });
  console.error(error);
  process.exitCode = 1;
} finally {
  await fs.mkdir(artifacts, { recursive: true });
  await fs.writeFile(resultFile, JSON.stringify({ timestamp: new Date().toISOString(), project, host, authPort, firestorePort,
    completed, passed: results.filter(result => result.passed).length, failed: results.filter(result => !result.passed).length, results }, null, 2));
  if (auth) await signOut(auth).catch(() => {});
  if (db) await terminate(db).catch(() => {});
  await fs.rm(runtime, { recursive: true, force: true });
}
