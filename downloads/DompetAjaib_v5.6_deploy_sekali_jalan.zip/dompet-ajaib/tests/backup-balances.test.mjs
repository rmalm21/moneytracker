import test from 'node:test';
import assert from 'node:assert/strict';
import { mergeWalletSplitBalances, validateBackupBalances } from '../lib/backup-balances.ts';

const wallet = (id = 'A', extra = {}) => ({
  id, openingBalance: 1_000_000, cachedBalance: 1_000_000,
  balanceSplitEnabled: true, openingBusinessBalance: 600_000, cachedBusinessBalance: 600_000,
  ...extra,
});
const backup = extra => ({ wallets: [wallet()], ...extra });

test('legacy backups without split fields retain their values and need no migration', () => {
  const data = {
    wallets: [{ id: 'old', openingBalance: 100, cachedBalance: 80 }],
    transactions: [{ id: 'expense', type: 'expense', walletId: 'old' }],
    recurring: [{ id: 'schedule', walletId: 'old' }],
    claims: [{ id: 'claim', sourceWalletId: 'old' }],
  };
  const before = structuredClone(data);
  assert.doesNotThrow(() => validateBackupBalances(data));
  assert.deepEqual(data, before);
});

test('valid split wallets allow negative personal/business parts and preserve stored allocation', () => {
  const data = backup({ wallets: [wallet('A', {
    openingBalance: 100, openingBusinessBalance: 150, cachedBalance: -100, cachedBusinessBalance: -50,
  })] });
  const before = structuredClone(data);
  assert.doesNotThrow(() => validateBackupBalances(data));
  assert.deepEqual(data, before);
});

test('backup rejects malformed and unsafe balances before any restore', () => {
  for (const extra of [
    { balanceSplitEnabled: 'true' }, { openingBusinessBalance: null },
    { openingBusinessBalance: 0.5 }, { cachedBusinessBalance: Infinity },
    { openingBalance: Number.MAX_SAFE_INTEGER, openingBusinessBalance: -1 },
    { cachedBalance: Number.MAX_SAFE_INTEGER, cachedBusinessBalance: -1 },
    { balanceSplitEnabled: false }, { balanceSplitEnabled: undefined },
  ]) assert.throws(() => validateBackupBalances(backup({ wallets: [wallet('A', extra)] })));
  assert.doesNotThrow(() => validateBackupBalances(backup({ wallets: [wallet('A', {
    balanceSplitEnabled: false, openingBusinessBalance: 0, cachedBusinessBalance: 0,
  })] })));
});

test('legacy wallets still validate total balances when business fields are absent', () => {
  for (const total of [undefined, null, NaN, Infinity, 1.5, Number.MAX_SAFE_INTEGER + 1]) {
    assert.throws(() => validateBackupBalances({ wallets: [{ id: 'old', openingBalance: total, cachedBalance: 80 }] }), /Rupiah bulat/);
    assert.throws(() => validateBackupBalances({ wallets: [{ id: 'old', openingBalance: 100, cachedBalance: total }] }), /Rupiah bulat/);
  }
});

test('each money path must point explicit business balances at an enabled wallet', () => {
  for (const name of ['transactions', 'recurring', 'drafts', 'plannedTransactions', 'splitBills']) {
    const row = { id: name, type: 'expense', walletId: 'A', balanceKind: 'business', payer: 'me', status: 'active' };
    assert.doesNotThrow(() => validateBackupBalances(backup({ [name]: [row] })));
    assert.throws(() => validateBackupBalances(backup({ [name]: [{ ...row, walletId: 'missing' }] })), /split saldo aktif/);
    assert.throws(() => validateBackupBalances(backup({ [name]: [{ ...row, balanceKind: 'invalid' }] })), /Jenis saldo/);
    assert.throws(() => validateBackupBalances(backup({ wallets: [wallet('A', {
      balanceSplitEnabled: false, openingBusinessBalance: 0, cachedBusinessBalance: 0,
    })], [name]: [row] })), /split saldo aktif/);
  }
});

test('transfers validate both wallets independently, including moves inside one wallet', () => {
  const row = { id: 'move', type: 'transfer', walletId: 'A', balanceKind: 'personal',
    destinationWalletId: 'A', destinationBalanceKind: 'business' };
  assert.doesNotThrow(() => validateBackupBalances(backup({ transactions: [row] })));
  for (const name of ['transactions', 'recurring', 'drafts']) {
    assert.throws(() => validateBackupBalances(backup({ [name]: [{ ...row, destinationWalletId: 'missing' }] })), /split saldo aktif/);
    assert.throws(() => validateBackupBalances(backup({ [name]: [{ ...row, destinationBalanceKind: null }] })), /Jenis saldo/);
  }
});

test('claims, receivables and owed balance additions retain their source allocation', () => {
  for (const name of ['claims', 'receivables']) {
    const row = { id: name, sourceWalletId: 'A', sourceBalanceKind: 'business' };
    assert.doesNotThrow(() => validateBackupBalances(backup({ [name]: [row] })));
    assert.throws(() => validateBackupBalances(backup({ [name]: [{ ...row, sourceWalletId: 'missing' }] })), /split saldo aktif/);
    assert.throws(() => validateBackupBalances(backup({ [name]: [{ ...row, sourceBalanceKind: 'invalid' }] })), /Jenis saldo/);
  }
  for (const name of ['receivables', 'debts']) {
    const update = { id: 'add', balanceKind: 'business', walletId: 'A' };
    const row = { id: name, balanceUpdates: [update] };
    assert.doesNotThrow(() => validateBackupBalances(backup({ [name]: [row] })));
    assert.throws(() => validateBackupBalances(backup({ [name]: [{ ...row,
      balanceUpdates: [{ ...update, walletId: 'missing' }],
    }] })), /split saldo aktif/);
    assert.throws(() => validateBackupBalances(backup({ [name]: [{ id: name, balanceUpdates: [null] }] })), /Riwayat perubahan/);
  }
});

test('someone else paying a split bill does not require a money-moving wallet', () => {
  assert.doesNotThrow(() => validateBackupBalances(backup({ splitBills: [{
    id: 'other-pays', payer: 'other', walletId: '', balanceKind: 'business',
  }] })));
  assert.throws(() => validateBackupBalances(backup({ splitBills: [{
    id: 'other-pays', payer: 'other', walletId: '', balanceKind: 'invalid',
  }] })), /Jenis saldo/);
});

test('split bill history and non-cash shares survive backup without inventing a wallet reference', () => {
  const data = backup({
    splitBills: ['draft', 'cancelled'].map(status => ({
      id: status, status, payer: 'me', walletId: '', balanceKind: 'business',
    })),
    receivables: [{ id: 'owed', sourceType: 'split_bill', sourceWalletId: '', sourceBalanceKind: 'business' }],
    transactions: [{ id: 'share', type: 'expense', walletId: '', splitBillId: 'bill', balanceKind: 'business' }],
  });
  assert.doesNotThrow(() => validateBackupBalances(data));
  assert.throws(() => validateBackupBalances(backup({ transactions: [{
    id: 'missing-wallet', type: 'expense', walletId: '', balanceKind: 'business',
  }] })), /split saldo aktif/);
});

test('merging older wallet backups keeps existing business openings and retained ledger allocation', () => {
  const existing = [wallet('A', { cachedBusinessBalance: 725_000 })];
  const incoming = [
    { id: 'A', name: 'Older name', openingBalance: 900_000, cachedBalance: 950_000 },
    { id: 'B', openingBalance: 0, cachedBalance: 0 },
  ];
  const before = structuredClone(incoming);
  const merged = mergeWalletSplitBalances(incoming, existing);
  assert.deepEqual(merged[0], { ...incoming[0], balanceSplitEnabled: true,
    openingBusinessBalance: 600_000, cachedBusinessBalance: 725_000 });
  assert.deepEqual(merged[1], incoming[1]);
  assert.deepEqual(incoming, before);
  assert.doesNotThrow(() => validateBackupBalances({ wallets: merged }));
  const newer = [wallet('A', { openingBusinessBalance: 100_000 })];
  assert.deepEqual(mergeWalletSplitBalances(newer, existing), newer);
});

test('merging an unsplit wallet backup cannot disable a split wallet already in use', () => {
  const incoming = [wallet('A', { balanceSplitEnabled: false, openingBusinessBalance: 0, cachedBusinessBalance: 0 })];
  const merged = mergeWalletSplitBalances(incoming, [wallet()]);
  assert.equal(merged[0].balanceSplitEnabled, true);
  assert.equal(merged[0].openingBusinessBalance, 600_000);
});
