import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { cliResult, webApps, chooseWebApp, productionEnv } from '../scripts/cloud-shell-config.mjs';

const project = 'money-manage-32467';
const sdk = { apiKey: 'fixture-api-key', projectId: project, appId: '1:123:web:fixture', authDomain: `${project}.firebaseapp.com`, messagingSenderId: '123' };
test('CLI JSON handles an authentication warning, but rejects failed or incomplete responses', () => {
  assert.deepEqual(cliResult('Warning: token authentication is deprecated.\n'+JSON.stringify({ status: 'success', result: { sdkConfig: sdk } })), { sdkConfig: sdk });
  assert.throws(() => cliResult('{"status":"error","error":"denied"}'), /belum berhasil/);
  assert.throws(() => cliResult('not JSON'), /JSON/);
});
test('multiple web apps prefer the existing deployed app within the same project', () => {
  const apps = [{ platform: 'WEB', appId: 'other', displayName: 'Other' }, { platform: 'WEB', appId: sdk.appId, displayName: 'Dompet Ajaib' }];
  assert.equal(chooseWebApp(apps, project, 'dompetajaib', sdk), sdk.appId);
  assert.equal(chooseWebApp(apps, project, 'dompetajaib', { ...sdk, projectId: 'another-project', appId: 'other' }), sdk.appId);
  assert.deepEqual(webApps([...apps, { platform: 'ANDROID', appId: 'android' }, { platform: 'WEB', appId: 'deleted', state: 'DELETED' }]), apps);
});
test('production config replaces demo settings and preserves optional keys without duplication', () => {
  const previous = 'NEXT_PUBLIC_FIREBASE_PROJECT_ID=demo-split\nNEXT_PUBLIC_FIREBASE_API_KEY=old\nNEXT_PUBLIC_FIREBASE_EMULATOR_HOST=127.0.0.1\nNEXT_PUBLIC_AUTH_EMAIL_DOMAIN=example.com\nNEXT_PUBLIC_GEMINI_API_KEY=optional-fixture-key\n';
  const result = productionEnv({ sdkConfig: sdk }, project, previous);
  assert.match(result, new RegExp(`NEXT_PUBLIC_FIREBASE_PROJECT_ID=${project}`));
  assert.match(result, /^NEXT_PUBLIC_FIREBASE_EMULATOR_HOST=$/m);
  assert.match(result, /NEXT_PUBLIC_AUTH_EMAIL_DOMAIN=example.com/);
  assert.match(result, /NEXT_PUBLIC_GEMINI_API_KEY=optional-fixture-key/);
  assert.equal((result.match(/NEXT_PUBLIC_FIREBASE_API_KEY=/g) || []).length, 1);
  assert.doesNotMatch(result, /demo-split|127\.0\.0\.1/);
});
test('invalid or wrong-project SDK config cannot be written as production settings', () => {
  assert.throws(() => productionEnv({ sdkConfig: { ...sdk, projectId: 'another-project' } }, project), /bukan/);
  assert.throws(() => productionEnv({ sdkConfig: { ...sdk, apiKey: '' } }, project), /tidak lengkap/);
  assert.throws(() => productionEnv({ sdkConfig: { ...sdk, apiKey: 'key\nINJECTED=1' } }, project), /tidak valid/);
});

// Run the actual shell script and config helper. Only gcloud/npm/Firebase API commands
// are replaced with local fixtures, so these tests never access or deploy to an account.
function simulate(scenario = 'success') {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'dompet-cloudshell-test-'));
  const bin = path.join(directory, 'bin');
  const log = path.join(directory, 'commands.jsonl');
  fs.mkdirSync(bin);
  fs.mkdirSync(path.join(directory, 'scripts'));
  fs.copyFileSync(fileURLToPath(new URL('../DEPLOY_SEKALI_JALAN.sh', import.meta.url)), path.join(directory, 'DEPLOY_SEKALI_JALAN.sh'));
  fs.copyFileSync(fileURLToPath(new URL('../scripts/cloud-shell-config.mjs', import.meta.url)), path.join(directory, 'scripts/cloud-shell-config.mjs'));
  const cli = path.join(directory, 'fake-firebase.cjs');
  fs.writeFileSync(cli, `
const fs = require('node:fs');
const args = process.argv.slice(2);
if (process.env.FIREBASE_TOKEN !== 'fixture-access-token-do-not-print') process.exit(9);
if (!args.includes('--non-interactive') || args[args.indexOf('--project') + 1] !== '${project}') process.exit(10);
fs.appendFileSync(process.env.DA_TEST_LOG, JSON.stringify(['firebase', ...args])+'\\n');
if (args[0] === 'apps:list') {
  const created = fs.readFileSync(process.env.DA_TEST_LOG, 'utf8').includes('apps:create');
  const apps = process.env.DA_TEST_SCENARIO === 'no-web-app' && !created ? [] : [{ platform: 'WEB', appId: '${sdk.appId}', displayName: 'Dompet Ajaib' }];
  console.log(JSON.stringify({ status: 'success', result: apps }));
}
else if (args[0] === 'apps:create') console.log(JSON.stringify({ status: 'success', result: { platform: 'WEB', appId: '${sdk.appId}' } }));
else if (args[0] === 'apps:sdkconfig') console.log(JSON.stringify({ status: 'success', result: { sdkConfig: { ...${JSON.stringify(sdk)}, projectId: process.env.DA_TEST_SCENARIO === 'wrong-sdk' ? 'wrong-project' : '${project}' } } }));
else if (args[0] === 'deploy') {
  if (args[args.indexOf('--only') + 1] !== 'firestore:rules,hosting') process.exit(11);
  console.log('Deploy complete!');
} else process.exit(12);
`);
  fs.writeFileSync(path.join(directory, 'fake-gcloud.cjs'), `
const fs = require('node:fs');
const args = process.argv.slice(2);
fs.appendFileSync(process.env.DA_TEST_LOG, JSON.stringify(['gcloud', ...args])+'\\n');
if (args[0] === 'config') console.log(process.env.DA_TEST_SCENARIO === 'wrong-project' ? 'wrong-project' : '${project}');
else if (args.join(' ') === 'auth print-access-token') console.log('fixture-access-token-do-not-print');
else process.exit(13);
`);
  fs.writeFileSync(path.join(directory, 'fake-npm.cjs'), `
const fs = require('node:fs');
const path = require('node:path');
const args = process.argv.slice(2);
fs.appendFileSync(process.env.DA_TEST_LOG, JSON.stringify(['npm', ...args])+'\\n');
if (args[0] === 'install') {
  const prefix = args[args.indexOf('--prefix') + 1];
  const target = path.join(prefix, 'node_modules/firebase-tools/lib/bin/firebase.js');
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.copyFileSync(process.env.DA_TEST_CLI, target);
} else if (args.join(' ') === 'run build') {
  if (process.env.DA_TEST_SCENARIO === 'build-failed') process.exit(42);
  fs.mkdirSync('out', { recursive: true });
  fs.writeFileSync('out/index.html', 'fixture-only');
  fs.writeFileSync('out/sw.js', 'fixture-only');
}
`);
  for (const command of ['gcloud', 'npm']) {
    fs.writeFileSync(path.join(bin, command), `#!/usr/bin/env bash\nnode "${directory}/fake-${command}.cjs" "$@"\n`, { mode: 0o755 });
  }
  try {
    const result = spawnSync('bash', [path.join(directory, 'DEPLOY_SEKALI_JALAN.sh')], {
      cwd: directory, encoding: 'utf8', timeout: 20_000,
      env: { ...process.env, PATH: bin+path.delimiter+process.env.PATH, DA_TEST_LOG: log, DA_TEST_SCENARIO: scenario, DA_TEST_CLI: cli },
    });
    const commands = fs.existsSync(log) ? fs.readFileSync(log, 'utf8').trim().split('\n').map(line => JSON.parse(line)) : [];
    const envFile = path.join(directory, '.env.local');
    return { ...result, commands, env: fs.existsSync(envFile) ? fs.readFileSync(envFile, 'utf8') : null };
  } finally { fs.rmSync(directory, { recursive: true, force: true }); }
}
test('one-run script gets config, checks/builds, and deploys exactly once using fresh Cloud Shell tokens', () => {
  const result = simulate();
  assert.equal(result.status, 0, result.stderr);
  assert.match(result.stdout, /SELESAI — https:\/\/dompetajaib\.web\.app/);
  assert.doesNotMatch(result.stdout+result.stderr, /fixture-access-token-do-not-print/);
  assert.match(result.env, /NEXT_PUBLIC_FIREBASE_PROJECT_ID=money-manage-32467/);
  assert.equal(result.commands.filter(args => args[0] === 'firebase' && args[1] === 'deploy').length, 1);
  assert.equal(result.commands.filter(args => args[0] === 'gcloud' && args[1] === 'auth').length, 3);
  const npm = result.commands.filter(args => args[0] === 'npm').map(args => args.slice(1));
  assert(npm.some(args => args[0] === 'ci'));
  assert.deepEqual(npm.slice(-3), [['run', 'typecheck'], ['test'], ['run', 'build']]);
});
test('one-run script registers a web app automatically only when the project has none', () => {
  const result = simulate('no-web-app');
  assert.equal(result.status, 0, result.stderr);
  assert.equal(result.commands.filter(args => args[0] === 'firebase' && args[1] === 'apps:create').length, 1);
  assert.equal(result.commands.filter(args => args[0] === 'firebase' && args[1] === 'deploy').length, 1);
  assert.match(result.env, /NEXT_PUBLIC_FIREBASE_PROJECT_ID=money-manage-32467/);
});
for (const scenario of ['wrong-project', 'wrong-sdk', 'build-failed']) {
  test(`one-run script never deploys when ${scenario}`, () => {
    const result = simulate(scenario);
    assert.notEqual(result.status, 0);
    assert.equal(result.commands.filter(args => args[0] === 'firebase' && args[1] === 'deploy').length, 0);
    assert.doesNotMatch(result.stdout, /SELESAI —/);
  });
}
