import test from 'node:test';
import assert from 'node:assert/strict';
import { effects, walletBalance } from '../lib/accounting.ts';
import {
  balanceCacheDeltas, balanceEffects, balanceLabel, combineBalanceCacheDeltas,
  transactionMatchesBalance, validateBalanceKind, validateWalletBalanceKind,
  walletBalanceParts, walletBalances, walletOpeningBalances, sameWalletBalanceState,
} from '../lib/wallet-balances.ts';

const wallet = (id = 'A', extra = {}) => ({
  id, name: id, openingBalance: 1_000_000, cachedBalance: 1_000_000,
  balanceSplitEnabled: true, openingBusinessBalance: 600_000, cachedBusinessBalance: 600_000,
  ...extra,
});
const tx = (type, amount, extra = {}) => ({
  id: type, type, amount, walletId: 'A', destinationWalletId: null,
  date: '2026-10-04', adjustmentDirection: 'in', ...extra,
});
const parts = (personal, business) => ({ personal, business, total: personal + business });

test('old wallets and unclassified transactions remain entirely personal', () => {
  const oldWallet = wallet('A', { balanceSplitEnabled: undefined, openingBusinessBalance: undefined, cachedBusinessBalance: undefined });
  assert.deepEqual(walletBalances(oldWallet), parts(1_000_000, 0));
  assert.deepEqual(walletOpeningBalances(oldWallet), parts(1_000_000, 0));
  assert.deepEqual(walletBalanceParts(oldWallet, [tx('income', 100_000), tx('expense', 75_000)]), parts(1_025_000, 0));
  assert.equal(validateBalanceKind(undefined), 'personal');
  assert.equal(balanceLabel(undefined), 'Pribadi');
});

test('income and expense change only the selected balance and its wallet total', () => {
  const transactions = [
    tx('income', 250_000, { balanceKind: 'business' }),
    tx('expense', 100_000, { balanceKind: 'personal' }),
    tx('expense', 50_000, { balanceKind: 'business' }),
  ];
  assert.deepEqual(walletBalanceParts(wallet(), transactions), parts(300_000, 800_000));
  assert.deepEqual(balanceEffects(transactions[0]), { A: parts(0, 250_000) });
  assert.deepEqual(balanceEffects(transactions[1]), { A: parts(-100_000, 0) });
});

test('cross-wallet transfers choose each side independently and charge the source fee', () => {
  const transfer = tx('transfer', 150_000, {
    balanceKind: 'business', destinationWalletId: 'B', destinationBalanceKind: 'personal', transferFee: 2_500,
  });
  assert.deepEqual(balanceEffects(transfer), { A: parts(0, -152_500), B: parts(150_000, 0) });
  assert.deepEqual(balanceCacheDeltas(transfer), {
    A: { cachedBalance: -152_500, cachedBusinessBalance: -152_500 },
    B: { cachedBalance: 150_000, cachedBusinessBalance: 0 },
  });
  assert.deepEqual(walletBalanceParts(wallet(), [transfer]), parts(400_000, 447_500));
  assert.deepEqual(walletBalanceParts(wallet('B', { openingBalance: 0, openingBusinessBalance: 0 }), [transfer]), parts(150_000, 0));
});

test('a transfer inside one wallet reallocates balances without duplicating money', () => {
  const internal = tx('transfer', 200_000, { destinationWalletId: 'A', destinationBalanceKind: 'business' });
  assert.deepEqual(balanceEffects(internal), { A: parts(-200_000, 200_000) });
  assert.deepEqual(balanceCacheDeltas(internal), { A: { cachedBalance: 0, cachedBusinessBalance: 200_000 } });
  assert.deepEqual(walletBalanceParts(wallet(), [internal]), parts(200_000, 800_000));
  assert.deepEqual(balanceEffects({ ...internal, transferFee: 1_000 }), { A: parts(-201_000, 200_000) });
  const reverse = { ...internal, balanceKind: 'business', destinationBalanceKind: 'personal', transferFee: 1_000 };
  assert.deepEqual(balanceEffects(reverse), { A: parts(200_000, -201_000) });
  assert.equal(walletBalance(wallet(), [reverse]), 999_000);
});

test('changing the kind of an existing transaction adjusts both caches without changing its total', () => {
  const original = tx('expense', 50_000);
  const edited = { ...original, balanceKind: 'business' };
  assert.deepEqual(combineBalanceCacheDeltas(edited, original), { A: { cachedBalance: 0, cachedBusinessBalance: -50_000 } });
  assert.deepEqual(balanceCacheDeltas(edited, -1), { A: { cachedBalance: 50_000, cachedBusinessBalance: 50_000 } });
  assert.deepEqual(combineBalanceCacheDeltas(edited, edited), {});
  const moved = { ...edited, walletId: 'B', amount: 20_000 };
  assert.deepEqual(combineBalanceCacheDeltas(moved, edited), {
    A: { cachedBalance: 50_000, cachedBusinessBalance: 50_000 },
    B: { cachedBalance: -20_000, cachedBusinessBalance: -20_000 },
  });
});

test('create, edit and delete cache deltas always match rebuilding both ledger balances', () => {
  const initial = wallet();
  let cached = { ...initial };
  const apply = deltas => {
    const delta = deltas.A;
    if (delta) cached = {
      ...cached, cachedBalance: cached.cachedBalance + delta.cachedBalance,
      cachedBusinessBalance: cached.cachedBusinessBalance + delta.cachedBusinessBalance,
    };
  };
  const original = tx('transfer', 250_000, { destinationWalletId: 'A', destinationBalanceKind: 'business' });
  apply(balanceCacheDeltas(original));
  assert.deepEqual(walletBalances(cached), walletBalanceParts(initial, [original]));
  const edited = { ...original, amount: 100_000, balanceKind: 'business', destinationBalanceKind: 'personal', transferFee: 2_000 };
  apply(combineBalanceCacheDeltas(edited, original));
  assert.deepEqual(walletBalances(cached), walletBalanceParts(initial, [edited]));
  apply(balanceCacheDeltas(edited, -1));
  assert.deepEqual(walletBalances(cached), walletOpeningBalances(initial));
});

test('every existing transaction type keeps its total effect and routes the selected balance', () => {
  const cases = [
    ['expense', -100], ['income', 100], ['borrowing', 100], ['debt_payment', -100],
    ['claim_advance', -100], ['claim_payment', 100], ['receivable_issue', -100],
    ['receivable_payment', 100], ['adjustment', 100], ['claim_writeoff', 0],
    ['transfer', -100], ['fund_contribution', -100],
  ];
  for (const [type, amount] of cases) {
    const transaction = tx(type, 100, { balanceKind: 'business', destinationWalletId: 'B', destinationBalanceKind: 'business' });
    const calculated = balanceEffects(transaction);
    assert.equal(calculated.A?.business ?? 0, amount, type);
    assert.deepEqual(Object.fromEntries(Object.entries(calculated).map(([id, value]) => [id, value.total])), effects(transaction), type);
    for (const value of Object.values(calculated)) assert.equal(value.total, value.personal + value.business, type);
    assert.equal(walletBalanceParts(wallet(), [transaction]).total, walletBalance(wallet(), [transaction]), type);
  }
  assert.deepEqual(balanceEffects(tx('adjustment', 100, { balanceKind: 'business', adjustmentDirection: 'out' })), { A: parts(0, -100) });
  // Savings contributions do not invent admin fees, matching existing accounting.
  assert.deepEqual(balanceEffects(tx('fund_contribution', 100, { destinationWalletId: 'B', balanceKind: 'business', transferFee: 25 })), {
    A: parts(0, -100), B: parts(100, 0),
  });
});

test('opening and cached parts retain negative balances and never lose stored business values', () => {
  const negative = wallet('A', { openingBalance: 100, openingBusinessBalance: 150, cachedBalance: -25, cachedBusinessBalance: 10, balanceSplitEnabled: false });
  assert.deepEqual(walletOpeningBalances(negative), parts(-50, 150));
  assert.deepEqual(walletBalances(negative), parts(-35, 10));
  assert.deepEqual(walletBalanceParts(negative, [tx('expense', 200, { balanceKind: 'business' })]), parts(-50, -50));
  assert.throws(() => walletOpeningBalances({ openingBalance: 10, openingBusinessBalance: 0.5 }), /Rupiah bulat/);
  assert.throws(() => walletOpeningBalances({ openingBalance: Infinity }), /Rupiah bulat/);
  assert.throws(() => walletOpeningBalances({ openingBalance: Number.MAX_SAFE_INTEGER, openingBusinessBalance: -1 }), /Rupiah bulat/);
});

test('kind validation requires an enabled wallet for new business operations', () => {
  assert.equal(validateWalletBalanceKind({ balanceSplitEnabled: true }, 'business'), 'business');
  assert.equal(validateWalletBalanceKind({}, undefined), 'personal');
  assert.throws(() => validateWalletBalanceKind({}, 'business'), /Aktifkan split saldo/);
  assert.throws(() => validateBalanceKind('other'), /Jenis saldo/);
  assert.throws(() => validateBalanceKind(null), /Jenis saldo/);
  assert.equal(balanceLabel('business'), 'Bisnis');
});

test('a ledger rebuild detects a concurrent move even when wallet totals stayed equal', () => {
  const before = wallet('A', { updatedAt: { seconds: 100, nanoseconds: 0 } });
  // A personal-to-business move keeps the wallet total, but changes its allocation.
  assert.equal(sameWalletBalanceState(before, { ...before, cachedBusinessBalance: 700_000 }), false);
  // Two later operations can cancel each other's cache deltas; the write timestamp still guards the rebuild.
  assert.equal(sameWalletBalanceState(before, { ...before, updatedAt: { seconds: 101, nanoseconds: 0 } }), false);
  assert.equal(sameWalletBalanceState(before, { ...before, openingBusinessBalance: 500_000 }), false);
  assert.equal(sameWalletBalanceState(before, structuredClone(before)), true);
  assert.equal(sameWalletBalanceState(wallet('old', { openingBusinessBalance: undefined, cachedBusinessBalance: undefined }),
    wallet('old', { openingBusinessBalance: 0, cachedBusinessBalance: 0 })), true);
});

test('filters match the selected side of transfers and legacy records', () => {
  const transfer = tx('transfer', 100, { balanceKind: 'business', destinationWalletId: 'B', destinationBalanceKind: 'personal' });
  assert.equal(transactionMatchesBalance(transfer, 'business'), true);
  assert.equal(transactionMatchesBalance(transfer, 'personal'), true);
  assert.equal(transactionMatchesBalance(transfer, 'business', 'A'), true);
  assert.equal(transactionMatchesBalance(transfer, 'personal', 'A'), false);
  assert.equal(transactionMatchesBalance(transfer, 'personal', 'B'), true);
  assert.equal(transactionMatchesBalance(transfer, 'business', 'B'), false);
  assert.equal(transactionMatchesBalance(transfer, 'personal', 'C'), false);
  assert.equal(transactionMatchesBalance({ ...transfer, destinationWalletId: 'A' }, 'personal', 'A'), true);
  assert.equal(transactionMatchesBalance(tx('expense', 100), 'personal'), true);
  assert.equal(transactionMatchesBalance(tx('expense', 100), 'business'), false);
  assert.equal(transactionMatchesBalance(tx('claim_writeoff', 100, { balanceKind: 'business' }), 'business'), true);
});
