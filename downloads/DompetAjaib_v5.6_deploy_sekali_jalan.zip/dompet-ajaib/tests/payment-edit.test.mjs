import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import ts from 'typescript';
import * as accounting from '../lib/accounting.ts';
import * as balances from '../lib/wallet-balances.ts';
import * as capabilities from '../lib/wallet-capabilities.ts';
import * as period from '../lib/period.ts';
import * as finance from '../lib/finance-control.ts';
import { billProgress } from '../lib/split-bill.ts';

// Exercise the real form, custom select, and persistence function offline. Only unrelated
// controls and the Firebase transport are replaced; this is not a browser/emulator test.
const require = createRequire(import.meta.url);
function load(source, dependencies) {
  const output = ts.transpileModule(readFileSync(new URL(source, import.meta.url), 'utf8'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX },
    fileName: source,
  }).outputText;
  const module = { exports: {} };
  new Function('require', 'module', 'exports', output)(
    name => Object.hasOwn(dependencies, name) ? dependencies[name] : require(name), module, module.exports);
  return module.exports;
}
const EmojiText = ({ text }) => text;
const { AppSelect } = load('../components/ui/app-select.tsx', { '../emoji': { EmojiText } });
const Field = ({ label, children }) => React.createElement('label', null, label, children);
const Input = props => React.createElement('input', props);
const empty = () => null;
const wallet = { id: 'mandiri', name: 'Mandiri', cachedBalance: 21_142, openingBalance: 0,
  cachedBusinessBalance: 21_142, balanceSplitEnabled: true, isArchived: false, isSpendable: true };
const payment = { id: 'repayment', type: 'receivable_payment', amount: 21_142, date: '2026-10-07', time: '',
  walletId: wallet.id, balanceKind: 'business', destinationWalletId: null, categoryId: null,
  subcategoryId: null, merchant: '', description: '', notes: '', tags: [],
  claimId: null, debtId: null, receivableId: 'linked', fundId: null,
  recurringTransactionId: null, draftId: null, adjustmentDirection: 'in', splitBillId: 'bill' };
const receivable = { id: 'linked', person: 'Peserta Split Bill', originalAmount: 21_142,
  remainingAmount: 0, status: 'paid', splitBillId: 'bill', sourceType: 'split_bill' };
const cases = [
  { type: 'receivable_payment', collection: 'receivables', link: 'receivableId', remaining: 'remainingAmount', label: 'Piutang', name: 'person' },
  { type: 'debt_payment', collection: 'debts', link: 'debtId', remaining: 'outstandingAmount', label: 'Utang', name: 'name' },
  { type: 'claim_payment', collection: 'claims', link: 'claimId', remaining: 'remainingAmount', label: 'Klaim kantor', name: 'name' },
];
function find(element, predicate) {
  if (!React.isValidElement(element)) return null;
  if (predicate(element)) return element;
  for (const child of React.Children.toArray(element.props.children)) {
    const result = find(child, predicate);
    if (result) return result;
  }
  return null;
}
function setupForm({ editing, preset, kind = cases[0], persist = async () => {} }) {
  const state = []; let cursor = 0; const messages = [];
  const data = { wallets: [wallet], transactions: [], categories: [], funds: [],
    debts: [], claims: [], receivables: [], cycleSnapshots: [] };
  data[kind.collection] = [
    { id: 'linked', [kind.name]: 'Peserta Split Bill', [kind.remaining]: 0 },
    { id: 'other-paid', [kind.name]: 'Lunas lainnya', [kind.remaining]: 0 },
    { id: 'open', [kind.name]: 'Belum lunas', [kind.remaining]: 10_000 },
  ];
  const hooks = { ...React, useState(initial) {
    const index = cursor++;
    if (!(index in state)) state[index] = typeof initial === 'function' ? initial() : initial;
    return [state[index], next => { state[index] = typeof next === 'function' ? next(state[index]) : next; }];
  }, useEffect() {}, useMemo: run => run() };
  const { TransactionForm } = load('../components/transaction-form.tsx', {
    react: hooks,
    './app-provider': { useApp: () => ({ data, user: { uid: 'test-user' }, profile: { timeZone: 'Asia/Jakarta' } }) },
    './visual-identity': { AppIcon: empty, emojiOrFallback: () => '' }, './emoji': { EmojiText },
    './suggest-input': { SuggestInput: empty, useTypedSuggestions: () => [], rememberTyped() {}, forgetTyped() {} },
    './category-picker': { CategoryPicker: empty }, './quick-entry': { QuickEntryBox: empty },
    './receipt-detail': { ReceiptDetail: empty }, './balance-selector': { BalanceSelector: empty },
    './fields': { Field, Input, Select: AppSelect, Money: empty },
    '@/lib/accounting': accounting, '@/lib/finance-control': finance, '@/lib/period': period,
    '@/lib/categorize': { suggestCategory: () => null }, '@/lib/wallet-capabilities': capabilities,
    '@/lib/wallet-balances': balances,
    '@/lib/firestore': { newTx: input => input, upsertTransaction: persist, validateTx() {} },
  });
  const render = () => { cursor = 0; return TransactionForm({ editing, preset, onDone: message => messages.push(message), onCancel() {} }); };
  return { render, messages };
}
function relationSelect(tree, label) {
  return find(find(tree, element => element.type === Field && element.props.label === label),
    element => element.type === AppSelect);
}
for (const kind of cases) {
  test(`editing a settled ${kind.type} keeps its original record selected in the real required select`, () => {
    const editing = { ...payment, type: kind.type, [kind.link]: 'linked' };
    const { render } = setupForm({ editing, kind });
    const select = relationSelect(render(), kind.label);
    const html = renderToStaticMarkup(select);
    assert.equal(select.props.value, 'linked');
    assert.match(html, /value="linked" selected=""/);
    assert.match(html, /Peserta Split Bill.*Lunas/);
    assert.match(html, /value="open"/);
    assert.doesNotMatch(html, /other-paid|Pilih opsi/);
  });
  test(`a new ${kind.type}, including a preset, excludes already settled records`, () => {
    const { render } = setupForm({ preset: { type: kind.type, [kind.link]: 'linked' }, kind });
    const html = renderToStaticMarkup(relationSelect(render(), kind.label));
    assert.doesNotMatch(html, /<option[^>]*value="linked"|other-paid/);
    assert.match(html, /<option[^>]*value="open"/);
  });
}

function persistence() {
  const docs = new Map([
    ['users/test-user/wallets/mandiri', { ...wallet }],
    ['users/test-user/transactions/repayment', { ...payment }],
    ['users/test-user/receivables/linked', { ...receivable }],
  ]);
  const refreshes = [];
  const pointer = (_db, ...parts) => ({ path: parts.join('/'), id: parts.at(-1) });
  const firebase = { doc: pointer, collection: pointer,
    increment: amount => ({ increment: amount }), serverTimestamp: () => 'test-timestamp' };
  const offline = { isOffline: () => true, whenOnline: key => refreshes.push(key),
    async runTx(_db, run) {
      const staged = new Map([...docs].map(([key, value]) => [key, structuredClone(value)]));
      await run({
        async get(ref) { const value = staged.get(ref.path); return { id: ref.id, exists: () => Boolean(value), data: () => structuredClone(value) }; },
        update(ref, fields) {
          assert(staged.has(ref.path), 'updated document must exist');
          const current = staged.get(ref.path);
          for (const [key, value] of Object.entries(fields)) {
            current[key] = value && typeof value === 'object' && 'increment' in value
              ? (current[key] || 0) + value.increment : value;
          }
        },
      });
      docs.clear(); for (const [key, value] of staged) docs.set(key, value);
    },
  };
  const store = load('../lib/firestore.ts', {
    'firebase/firestore': firebase, './firebase': { db: {} }, './offline': offline,
    './sync': {}, './tombstones': {}, './wallet-groups': {}, './accounting': accounting,
    './wallet-capabilities': capabilities, './recurring': {}, './wallet-balances': balances, './backup-balances': {},
  });
  return { docs, store, refreshes };
}
test('changing a fully settled Split Bill repayment to yesterday saves its date, keeps the bill settled, and never credits the wallet twice', async () => {
  const { docs, store, refreshes } = persistence();
  const { render, messages } = setupForm({ editing: payment,
    persist: (uid, input, id) => store.upsertTransaction(uid, store.newTx(input), id) });
  const dateInput = find(render(), element => element.type === Input && element.props.type === 'date');
  dateInput.props.onChange({ target: { value: '2026-10-06' } });
  await find(render(), element => element.type === 'form').props.onSubmit({ preventDefault() {} });
  assert.deepEqual(messages, ['Transaksi diperbarui.']);
  const saved = docs.get('users/test-user/transactions/repayment');
  assert.equal(saved.date, '2026-10-06');
  assert.equal(saved.receivableId, 'linked');
  assert.equal(saved.splitBillId, 'bill');
  assert.equal(saved.categoryId, null);
  assert.equal(saved.amount, 21_142);
  assert.deepEqual(docs.get('users/test-user/wallets/mandiri'), wallet);
  const settled = docs.get('users/test-user/receivables/linked');
  assert.equal(settled.remainingAmount, 0);
  assert.equal(settled.status, 'paid');
  const bill = { id: 'bill', status: 'active', payer: 'me', shares: { me: 21_142, other: 21_142 },
    participants: [{ id: 'me', isMe: true, name: 'Saya' }, { id: 'other', name: 'Peserta Split Bill', receivableId: 'linked' }] };
  assert.equal(billProgress(bill, [settled], []).status, 'settled');
  assert.equal(docs.size, 3, 'editing updates the existing payment');
  assert.deepEqual(refreshes, ['snapshot:test-user:2026-10-06']);
});
test('editing a settled repayment still rejects an amount above the original receivable without committing any changes', async () => {
  const { docs, store } = persistence();
  const before = structuredClone(docs);
  await assert.rejects(store.upsertTransaction('test-user', { ...payment, amount: 21_143 }, payment.id), /Pembayaran melebihi sisa tagihan/);
  assert.deepEqual(docs, before);
});
test('reducing a settled repayment reopens only its unpaid remainder and adjusts the wallet by the difference', async () => {
  const { docs, store } = persistence();
  await store.upsertTransaction('test-user', { ...payment, amount: 20_000 }, payment.id);
  const row = docs.get('users/test-user/receivables/linked');
  assert.equal(row.remainingAmount, 1_142);
  assert.equal(row.status, 'partial');
  const savedWallet = docs.get('users/test-user/wallets/mandiri');
  assert.equal(savedWallet.cachedBalance, 20_000);
  assert.equal(savedWallet.cachedBusinessBalance, 20_000);
});
