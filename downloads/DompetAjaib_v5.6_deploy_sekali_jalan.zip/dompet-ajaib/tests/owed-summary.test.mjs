import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import ts from 'typescript';
import * as accounting from '../lib/accounting.ts';
import * as period from '../lib/period.ts';
import * as balances from '../lib/wallet-balances.ts';
import * as capabilities from '../lib/wallet-capabilities.ts';

// Render the actual debt/receivable pages and GlassHero. Unrelated controls and app
// subscriptions are stubbed; no browser, Firebase transport, or production account is used.
const require = createRequire(import.meta.url);
function load(source, dependencies) {
  const output = ts.transpileModule(readFileSync(new URL(source, import.meta.url), 'utf8'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX },
    fileName: source,
  }).outputText;
  const module = { exports: {} };
  new Function('require', 'module', 'exports', output)(
    name => Object.hasOwn(dependencies, name) ? dependencies[name] : require(name), module, module.exports);
  return module.exports;
}
const empty = () => null;
const children = props => props.children;
const { GlassHero, GlassRing, closeMenu, dueText } = load('../components/glass.tsx', {});
const base = {
  './wallet-interest': { InterestInbox: empty }, '@/lib/pockets': {}, './pockets': { PocketSheet: empty },
  './emoji': { Emoji: ({ e }) => e, EmojiText: ({ text }) => text },
  './glass': { GlassHero, GlassRing, closeMenu, dueText },
  './notifications': { useNotify: () => ({ track() {} }) },
  './fields': { Empty: ({ message }) => message, Field: children, FormActions: empty, Input: empty, Money: empty, Select: empty },
  '@/lib/category-analytics': {}, './ui/button': { Button: props => React.createElement('button', props) },
  './ui/dialog': { Dialog: empty, DialogContent: empty }, './ui/alert-dialog': { Confirm: children },
  './dashboard': { TxList: empty }, './balance-selector': { BalanceSelector: empty },
  '@/lib/wallet-balances': balances, './visual-identity': { emojiOrFallback: () => '' },
  './context-notes': { ContextNotes: empty }, './settle-dialog': { SettleDialog: empty, ManualPayments: empty },
  './owed-tools': { BalanceDialog: empty, CompactRow: children, CompactSwitch: empty, OwedHistory: empty, useCompactOwed: () => [false, () => {}] },
  '@/lib/wallet-capabilities': capabilities, './period-selector': {}, '@/lib/period': period,
  '@/lib/firestore': {}, '@/lib/accounting': accounting, '@/lib/savings': {},
};
const pages = [
  { source: '../components/manage-views.tsx', exportName: 'DebtsView', collection: 'debts', remaining: 'outstandingAmount', progress: 'Sudah dibayar', emptyDetail: 'Semua utang sudah lunas.' },
  { source: '../components/receivables-refined.tsx', exportName: 'ReceivablesView', collection: 'receivables', remaining: 'remainingAmount', progress: 'Sudah kembali', emptyDetail: 'Semua piutang sudah kembali.' },
];
function record(id, original, remaining, page, extra = {}) {
  return { id, name: id, person: id, provider: '', originalAmount: original, [page.remaining]: remaining,
    installmentAmount: 0, interestRate: 0, notes: '', dueDate: '', date: '2026-10-01',
    description: '', sourceWalletId: '', status: remaining ? 'open' : 'paid', ...extra };
}
function render(page, records) {
  const data = { wallets: [], transactions: [], categories: [], debts: [], receivables: [], funds: [], [page.collection]: records };
  const dependencies = { ...base, './app-provider': { useApp: () => ({ data, user: null, profile: { timeZone: 'Asia/Jakarta' } }) } };
  const Component = load(page.source, dependencies)[page.exportName];
  const html = renderToStaticMarkup(React.createElement(Component, { notify() {}, openTx() {}, navigate() {} }));
  const hero = html.match(/<section class="gl-hero[\s\S]*?<\/section>/)?.[0];
  assert(hero, 'the page renders its real summary hero');
  return { html, hero };
}
for (const page of pages) {
  test(`${page.collection}: completed records cannot inflate the active principal or amount already paid`, () => {
    const active = [record('partial', 1_000_000, 400_000, page), record('unpaid', 500_000, 500_000, page)];
    const before = render(page, active);
    const after = render(page, [...active, record('closed-million', 99_000_000, 0, page)]);
    assert.match(after.hero, /gl-hero-value">Rp900\.000/);
    assert.match(after.hero, new RegExp(`${page.progress} Rp600\\.000 dari Rp1\\.500\\.000`));
    assert.match(after.hero, /aria-valuenow="40"/);
    assert.equal(after.hero, before.hero, 'adding an archived record leaves the active summary unchanged');
    assert.doesNotMatch(after.html, /closed-million/);
    assert.match(after.html, /1 lunas di Arsip/, 'completed records remain available in the archive');
  });
  test(`${page.collection}: a page with only completed records shows zero and no historical progress`, () => {
    const { html, hero } = render(page, [record('closed-a', 99_000_000, 0, page), record('closed-b', 2_000_000, 0, page)]);
    assert.match(hero, /gl-hero-value">Rp0/);
    assert(hero.includes(page.emptyDetail));
    assert.doesNotMatch(hero, /progressbar|Sudah dibayar|Sudah kembali Rp/);
    assert.match(html, /2 lunas di Arsip/);
    assert.doesNotMatch(html, /closed-a|closed-b/);
  });
  test(`${page.collection}: settling one active record immediately removes its principal and repayments from the summary`, () => {
    const records = [record('first', 1_000_000, 400_000, page), record('second', 500_000, 100_000, page)];
    const before = render(page, records);
    assert.match(before.hero, new RegExp(`${page.progress} Rp1\\.000\\.000 dari Rp1\\.500\\.000`));
    const after = render(page, [{ ...records[0], [page.remaining]: 0, status: 'paid' }, records[1]]);
    assert.match(after.hero, /gl-hero-value">Rp100\.000/);
    assert.match(after.hero, new RegExp(`${page.progress} Rp400\\.000 dari Rp500\\.000`));
    assert.match(after.hero, /aria-valuenow="80"/);
    assert.match(after.html, /1 lunas di Arsip/);
  });
}
test('receivable people and record counts use only active records and still group the same person', () => {
  const page = pages[1];
  const records = [
    record('active-a', 100_000, 50_000, page, { person: ' Budi ' }),
    record('active-b', 200_000, 100_000, page, { person: 'budi' }),
    record('closed-a', 99_000_000, 0, page, { person: 'Orang lain' }),
  ];
  const { hero } = render(page, records);
  assert.match(hero, /Dipinjam 1 orang · 2 catatan aktif/);
  assert.match(hero, /Sudah kembali Rp150\.000 dari Rp300\.000/);
});
